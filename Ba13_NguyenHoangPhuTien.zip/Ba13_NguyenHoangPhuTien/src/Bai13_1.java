import java.time.LocalDate;
import java.util.Calendar;

public class Bai13_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LocalDate local = LocalDate.now();
		Calendar cal = Calendar.getInstance();
		
		System.out.println("Ngày tháng năm hiện tại: "+local);
		System.out.println("Đang là thứ: "+local.getDayOfWeek());
		System.out.println("Đang là tuần thứ "+cal.get(Calendar.WEEK_OF_YEAR)+" trong năm");
		
		Calendar temp = (Calendar) cal.clone();
		temp.add(Calendar.WEEK_OF_YEAR, 1);
		long ngay = temp.get(Calendar.DAY_OF_MONTH);
		long thang = temp.get(Calendar.MONTH);
		long nam = temp.get(Calendar.YEAR);
		
		System.out.println("Tuần sau là ngày "+ngay+" tháng "+thang+" năm "+nam);
	}

}
