import java.util.Calendar;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Bai13_2 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		System.out.println("Hãy nhập ngày tháng năm sinh: ");
		String birthday = scan.nextLine();
		
		String regex = "([0]?[1-9]|[12][0-9]|3[01])/([0]?[0-9]|1[0-2])/[0-9]{4}";
		Pattern pattern = Pattern.compile(regex);
		Matcher mathcher = pattern.matcher(birthday);
		if(!(mathcher.matches()))
			System.out.println("Ngày nhập không hợp lệ");
		else{
			String[] ngaySN = birthday.split("/");
			Calendar cal = Calendar.getInstance();
			int ngay = cal.get(Calendar.DATE);
			int thang = cal.get(Calendar.MONTH);
			thang++;
			int ngaySinh = Integer.parseInt(ngaySN[0]);
			int thangSinh = Integer.parseInt(ngaySN[1]);
			if(thang == thangSinh){
				if(ngay == ngaySinh)
					System.out.println("Chúc mừng sinh nhật");
				else if(ngay > ngaySinh)
					System.out.println("Sinh nhật qua rùi");
				else
					System.out.println("Sinh nhật chưa tới");
			}
			else if(thang > thangSinh)
				System.out.println("Sinh nhật qua rùi");
			else
				System.out.println("Sinh nhật chưa tới");
		}
	}
}
