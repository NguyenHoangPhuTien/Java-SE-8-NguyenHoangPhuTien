import java.util.Calendar;
import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scan = new Scanner(System.in);
		System.out.println("Hãy nhập ngày tháng năm sinh: ");
		String birthday = scan.nextLine();
		String[] ngaySN = birthday.split("/");
		
		Calendar cal = Calendar.getInstance();
		int ngay = cal.get(Calendar.DATE);
		int thang = cal.get(Calendar.MONTH);
		thang++;
		int ngaySinh = Integer.parseInt(ngaySN[1]);
		int thangSinh = Integer.parseInt(ngaySN[0]);
		System.out.println(ngay);
		System.out.println(thang);
		System.out.println(ngaySinh);
		System.out.println(thangSinh);
	}

}
