/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai10_nguyenhoangphutien;

import com.sun.xml.internal.ws.policy.spi.AssertionCreationException;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai10_1 {

    /**
     * @param args the command line arguments
     */
    enum phepTinh {
        CONG, TRU, NHAN, CHIA;

        double tinh(double x, double y) {
            
            switch (this) {
                case CONG:
                    return x + y;
                case TRU:
                    return x - y;
                case NHAN:
                    return x * y;
                case CHIA:
                    if(y == 0)
                        throw new ArithmeticException("không được chia cho 0");
                    
                    return x / y;
                default:
                    throw new AssertionError("Phép toán không đúng");
            }
        }
    }

    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Hãy nhập x: ");
        try {
            double x = scan.nextDouble();
            System.out.println("Hãy nhập y: ");
            double y = scan.nextDouble();
            
            double ketQua = phepTinh.CONG.tinh(x, y);
            System.out.println("Kết quả cộng là: "+ketQua);
            
            ketQua = phepTinh.TRU.tinh(x, y);
            System.out.println("Kết quả trừ là: "+ketQua);
            
            ketQua = phepTinh.NHAN.tinh(x, y);
            System.out.println("Kết quả nhân là: "+ketQua);
            
            ketQua = phepTinh.CHIA.tinh(x, y);
            System.out.println("Kết quả chia là: "+ketQua);
        } catch (InputMismatchException e) {
            System.out.println("Định dạng nhập vào không đúng");
        } catch (ArithmeticException e){
            System.out.println(e.getMessage());
        }
        
        
    }

}
