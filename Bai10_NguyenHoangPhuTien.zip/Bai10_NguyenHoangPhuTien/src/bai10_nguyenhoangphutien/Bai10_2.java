/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai10_nguyenhoangphutien;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai10_2 {

    /**
     * @param args the command line arguments
     */
    enum OanTuTi{
        BAO(2),
        BUA(3),
        KEO(1);
        private int ketQua;

        private OanTuTi(int ketQua) {
            this.ketQua = ketQua;
        }

        public int getKetQua() {
            return ketQua;
        }
        
    }
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Bạn có mún chơi không(y/n)");
        String choi = scan.nextLine();
        if(choi.equalsIgnoreCase("y")){
            boolean tiepTuc = true;
            int tongLanChoi = 0;
            int diemNguoi = 0;
            int diemMay = 0;
            int mayChon = 0;
            int nguoiChon = 0;
            while(tiepTuc){
                System.out.println("Xin hãy chọn(bao/bua/keo): ");
                String chon = scan.nextLine();
                switch(chon){
                    case "bao":
                        nguoiChon = OanTuTi.BAO.getKetQua();
                        break;
                    case "bua":
                        nguoiChon = OanTuTi.BUA.getKetQua();
                        break;
                    case "keo":
                        nguoiChon = OanTuTi.KEO.getKetQua();
                }
                mayChon = new Random().nextInt(3);
                if(mayChon == nguoiChon)
                    System.out.println("Ngang tài ngang sức");
                else{
                        if(nguoiChon == 1){
                            if(mayChon == 2){
                                System.out.println("Bạn thắng ván này");
                                diemNguoi++;
                            }
                            else if(mayChon == 3){
                                System.out.println("Bạn thua ván này");
                                diemMay++;
                            }
                        }
                        else if(nguoiChon == 2){
                            if(mayChon == 3){
                                System.out.println("Bạn thắng ván này");
                                diemNguoi++;
                            }
                            else if(mayChon == 1){
                                System.out.println("Bạn thua ván này");
                                diemMay++;
                            }
                        }
                        else{
                            if(mayChon == 1){
                                System.out.println("Bạn thắng ván này");
                                diemNguoi++;
                            }
                            else if(mayChon == 2){
                                System.out.println("Bạn thua ván này");
                                diemMay++;
                            }
                        }
                }
                tongLanChoi++;
                if(diemNguoi == 5 || diemMay == 5){
                    tiepTuc = false;
                }
                
            }
            System.out.println("Tổng lượt chơi: "+tongLanChoi);
            if(diemNguoi > diemMay)
                System.out.println("Bạn là người chiến thắng");
            else
                System.out.println("Bạn thua rùi");
        }
        else
            System.out.println("Cảm ơn bạn");
    }
    
}
