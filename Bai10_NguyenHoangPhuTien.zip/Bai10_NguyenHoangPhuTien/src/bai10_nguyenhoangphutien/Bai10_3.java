/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai10_nguyenhoangphutien;

/**
 *
 * @author hocvien
 */
public class Bai10_3 {

    /**
     * @param args the command line arguments
     */
    enum DenGiaoThong{
        DO(30) {
            @Override
            public DenGiaoThong chuyenden() {
                return XANH;
            }
        },
        XANH(30) {
            @Override
            public DenGiaoThong chuyenden() {
                return VANG;
            }
        },
        VANG(10) {
            @Override
            public DenGiaoThong chuyenden() {
                return DO;
            }
        };
        
        private int soGiay;

        private DenGiaoThong(int soGiay) {
            this.soGiay = soGiay;
        }

        public int getSoGiay() {
            return soGiay;
        }
        public abstract DenGiaoThong chuyenden();
    }
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println(String.format("đèn xanh chuyễn sang %s trong %d giây",DenGiaoThong.VANG,DenGiaoThong.VANG.getSoGiay()));
        System.out.println(String.format("đèn vàng chuyễn sang %s trong %d giây",DenGiaoThong.DO,DenGiaoThong.DO.getSoGiay()));
        System.out.println(String.format("đèn đỏ chuyễn sang %s trong %d giây",DenGiaoThong.XANH,DenGiaoThong.XANH.getSoGiay()));
    }
    
}
