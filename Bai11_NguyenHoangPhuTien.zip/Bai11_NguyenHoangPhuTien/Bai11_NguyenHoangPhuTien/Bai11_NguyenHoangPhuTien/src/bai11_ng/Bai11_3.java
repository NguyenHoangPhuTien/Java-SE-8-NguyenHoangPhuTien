/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11_ng;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.StringTokenizer;

/**
 *
 * @author hocvien
 */
public class Bai11_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader read = new BufferedReader(new InputStreamReader(System.in));

        try {
            System.out.println("Hãy nhập ngày tháng: ");
            String ngayThang = read.readLine();

            StringTokenizer stk = new StringTokenizer(ngayThang, "/");
            String ngay = stk.nextToken();
            String thang = stk.nextToken();
            String nam = stk.nextToken();

            System.out.println("-------------------");
            System.out.println("Ngày: " + ngay);
            System.out.println("Tháng: " + thang);
            System.out.println("Năm: " + nam);
            
        } catch (NumberFormatException | NoSuchElementException e) {
            System.out.println(e.getMessage());
        }

    }

}
