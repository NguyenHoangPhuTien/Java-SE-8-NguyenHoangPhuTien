/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11_ng;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

/**
 *
 * @author hocvien
 */
public class Bai11_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
         BufferedReader read = new BufferedReader(new InputStreamReader(System.in));

        try {
            System.out.println("Hãy nhập họ tên: ");
            String hoTen = read.readLine();

            StringTokenizer stk = new StringTokenizer(hoTen);
            String ho = "";
            String ten= "";
            String tenDem = "";
            int i = 1;
            int j = stk.countTokens();
            while(stk.hasMoreTokens()){
                if(i == 1)
                    ho = stk.nextToken();
                else if(i == j)
                    ten = stk.nextToken();
                else
                    tenDem += stk.nextToken()+" ";
                i++;
            }

            System.out.println("-------------------");
            System.out.println("Họ: " + ho);
            System.out.println("Tên đệm: " + tenDem);
            System.out.println("Tên: " + ten);
            
        } catch (NumberFormatException e) {
            System.out.println(e.getMessage());
        }
    }
    
}
