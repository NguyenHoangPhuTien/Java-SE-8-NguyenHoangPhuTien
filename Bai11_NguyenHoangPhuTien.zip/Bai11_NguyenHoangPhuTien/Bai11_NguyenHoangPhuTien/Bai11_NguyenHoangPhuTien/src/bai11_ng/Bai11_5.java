/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11_ng;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author hocvien
 */
public class Bai11_5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
       
        System.out.println("Hãy nhập ngày giờ: ");
        String chuoi = reader.readLine();
        
        Pattern pattern =  Pattern.compile("([01]?[0-9]|2[0-3]):[0-5][0-9]");
        Matcher matcher = pattern.matcher(chuoi);
        
        if(matcher.matches())
            System.out.println("Ngày giờ hợp lệ");
        else
            System.out.println("Ngày giờ không hợp lệ");
        
    }
    
}
