/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11_ng;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author hocvien
 */
public class Bai11_6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
         BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
       
        System.out.println("Hãy nhập username : ");
        String chuoi = reader.readLine();
        
        Pattern pattern =  Pattern.compile("^[\\da-z_-]{6,20}$");
        Matcher matcher = pattern.matcher(chuoi);
        
        if(matcher.matches())
            System.out.println("username hợp lệ");
        else
            System.out.println("username không hợp lệ");
    }
    
}
