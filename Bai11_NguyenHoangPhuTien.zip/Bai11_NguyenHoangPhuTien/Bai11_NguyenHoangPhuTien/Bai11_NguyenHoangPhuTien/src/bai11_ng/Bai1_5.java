/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11_ng;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai1_5 {

    /**
     * @param args the command line arguments
     */
    private static void taoHinhA(int chieuDai) {

        String s = "";
        for (int i = 1; i <= chieuDai; i++) {
            for (int j = 1; j <= i; j++) {
                s += "*";
            }

            System.out.println(s);
            s = "";
        }
    }

    private static void taoHinhB(int chieuDai) {
        String s = "";
        for (int i = chieuDai; i >= 1; i--) {
            for (int j = 1; j <= i; j++) {
                s += "*";
            }

            System.out.println(s);
            s = "";
        }
    }

    private static void taoHinhC(int chieuDai) {
        String s = "";
        for (int i = 1; i <= chieuDai; i++) {

            for (int j = 1; j <= chieuDai; j++) {
                if (i != 1) {
                    if (j < i) {
                        s += " ";
                    } else {
                        s += "*";
                    }
                } else {
                    s += "*";
                }
            }
            System.out.println(s);
            s = "";
        }
    }

    private static void taoHinhD(int chieuDai) {
        String[][] mang = new String[chieuDai][chieuDai];
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if (j < mang.length - i - 1) {
                    System.out.print("  ");
                } else {
                    System.out.print("* ");
                }
            }
            System.out.println("");
        }
    }

    private static void taoHinhE(int chieuDai) {
        String[][] mang = new String[chieuDai][chieuDai];
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if (i == 0 || i == mang.length - 1) {
                    System.out.print("* ");
                }
               else{
                    if(j == 0 || j == mang.length - 1)
                        System.out.print("* ");
                    else
                        System.out.print("  ");
                }

            }
            System.out.println("");
        }
    }

    private static void taoHinhF(int chieuDai) {
        String[][] mang = new String[chieuDai][chieuDai];
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if (i == 0 || i == mang.length - 1) {
                    System.out.print("* ");
                } else {
                    if(i == j)
                        System.out.print("* ");
                    else
                       System.out.print("  "); 
                }
            }
            System.out.println("");
        }
        
    }
    private static void taoHinhG(int chieuDai) {
        String[][] mang = new String[chieuDai][chieuDai];
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if (i == 0 || i == mang.length - 1) {
                    System.out.print("* ");
                } else {
                    if(j == mang.length - 1 -i)
                        System.out.print("* ");
                    else
                       System.out.print("  "); 
                }
            }
            System.out.println("");
        }
        
    }
    private static void taoHinhH(int chieuDai) {
        String[][] mang = new String[chieuDai][chieuDai];
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if (i == 0 || i == mang.length - 1) {
                    System.out.print("* ");
                } else {
                    if(j == mang.length - 1 -i || j == i)
                        System.out.print("* ");
                    else
                       System.out.print("  "); 
                }
            }
            System.out.println("");
        }
        
    }
    private static void taoHinhI(int chieuDai) {
        String[][] mang = new String[chieuDai][chieuDai];
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if (i == 0 || i == mang.length - 1) {
                    System.out.print("* ");
                } else {
                    if(j == mang.length - 1 -i || j == i || j == 0 || j == mang.length - 1)
                        System.out.print("* ");
                    else
                       System.out.print("  "); 
                }
            }
            System.out.println("");
        }
        
    }
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        System.out.println("Hãy nhập chiều dài của hình: ");
        int chieuDai = scan.nextInt();
        
        taoHinhA(chieuDai);
        System.out.println("===========================");
        taoHinhB(chieuDai);
        System.out.println("===========================");
        taoHinhC(chieuDai);
        System.out.println("===========================");
        taoHinhD(chieuDai);
        System.out.println("===========================");
        taoHinhE(chieuDai);
        System.out.println("===========================");
        taoHinhF(chieuDai);
        System.out.println("===========================");
        taoHinhG(chieuDai);
        System.out.println("===========================");
        taoHinhH(chieuDai);
        System.out.println("===========================");
        taoHinhI(chieuDai);
    }

}
