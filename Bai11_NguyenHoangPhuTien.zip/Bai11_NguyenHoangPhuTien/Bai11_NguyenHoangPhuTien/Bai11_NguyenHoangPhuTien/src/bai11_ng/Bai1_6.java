/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11_ng;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

/**
 *
 * @author hocvien
 */
public class Bai1_6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
         BufferedReader read = new BufferedReader(new InputStreamReader(System.in));

        try {
            System.out.println("Hãy nhập chuỗi cần tách: ");
            String chuoi = read.readLine();
            
            System.out.println("Nhập kí tự cần phân tách: ");
            String kiTu = read.readLine();
            
            StringTokenizer stk = new StringTokenizer(chuoi,kiTu);
            System.out.println("-------------------");
            
            while(stk.hasMoreTokens()){
                 System.out.println(stk.nextToken());
            }
         
        } catch (NumberFormatException e) {
            System.out.println(e.getMessage());
        }
    }
    
}
