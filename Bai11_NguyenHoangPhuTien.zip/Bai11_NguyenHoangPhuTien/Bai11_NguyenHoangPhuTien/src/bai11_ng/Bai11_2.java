/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11_ng;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai11_2 {

    /**
     * @param args the command line arguments
     */
    private static StringBuilder xoaTheoViTri(StringBuilder sb,int dau, int cuoi){
        
        if(dau < 0 || cuoi < 0 || dau > sb.length() || cuoi > sb.length())
            throw new ArithmeticException("Vị trí không hợp lệ");
        
        sb = sb.delete(dau, cuoi);
        return sb;
    }
    private static StringBuilder chenTheoViTri(StringBuilder sb, int viTri, StringBuilder sb2){
        
        if(viTri < 0 || viTri > sb.length())
            throw new ArithmeticException("Vị trí chèn không hợp lệ");
        return sb.insert(viTri, sb2);
    }
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        
        try{
            System.out.println("Nhập chuỗi sb: ");
            StringBuilder sb = new StringBuilder(scan.nextLine());
            
            System.out.println("Nhập chuỗi sb1");
            StringBuilder sb1 = new StringBuilder(scan.nextLine());
            
            System.out.println("Nhập chuỗi sb2");
            StringBuilder sb2 = new StringBuilder(scan.nextLine());
            
            System.out.println("Chiều dài chuỗi sb: "+sb.length());
            System.out.println("Chiều dài chuỗi sb1: "+sb1.length());
            System.out.println("Chiều dài chuỗi sb2: "+sb2.length());
            
            System.out.println("Nhập vị trí chèn: ");
            int viTri = scan.nextInt();
            
            System.out.println("Nhập vị trí đầu: ");
            int viTriDau = scan.nextInt();
            
            System.out.println("Nhập vị trí cuối: ");
            int viTriCuoi = scan.nextInt();
            
            sb = sb.append(sb1);
            System.out.println("Chuỗi sb sau khi nối sb1 vào sb: "+sb);
            
            sb = chenTheoViTri(sb, viTri, sb2);
            System.out.println("Chuỗi sb sau khi thêm sb2 vào vị trí: "+sb);
            
            sb = xoaTheoViTri(sb, viTriDau, viTri);
            System.out.println("Chuỗi sb sau khi xóa vị trí đầu và cuối: "+sb);
            
            sb = sb.reverse();
            System.out.println("Chuỗi sb sau khi đão ngược: "+sb);
        }catch (InputMismatchException e){
            System.out.println("Định dạng nhập vào không đúng");
        }
    }
    
}
