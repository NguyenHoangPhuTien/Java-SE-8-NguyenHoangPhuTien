/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11_ng;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai11_Ng {

    /**
     * @param args the command line arguments
     */
    private static void taoHinhE(int chieuDai) {
        String[][] mang = new String[chieuDai][chieuDai];
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if (i == 0 || i == mang.length - 1) {
                    System.out.print("* ");
                }
                else{
                    if(j == 0 || j == mang.length - 1)
                        System.out.print("* ");
                    else
                        System.out.print("  ");
                }

            }
            System.out.println("");
        }
    }
    public static void main(String[] args) {
        // TODO code application logic here
        taoHinhE(8);

    }

}
