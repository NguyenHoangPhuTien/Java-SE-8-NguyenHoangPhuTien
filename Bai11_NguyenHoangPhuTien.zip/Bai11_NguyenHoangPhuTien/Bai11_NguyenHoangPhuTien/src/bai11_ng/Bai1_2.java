/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11_ng;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai1_2 {

    /**
     * @param args the command line arguments
     */
    private static void kiemTra(StringBuilder sb, String kt) {

        String s = "";
        if(sb.indexOf(kt) >= 0)
            System.out.println("Vị trí xuất hiện là: "+sb.indexOf(kt));
        else
            System.out.println("chuỗi kiểm tra không có trong chuỗi sb");
    }

    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);

        try {
            System.out.println("Nhập chuỗi sb: ");
            StringBuilder sb = new StringBuilder(scan.nextLine());

            System.out.println("Nhập chuỗi kiểm tra: ");
            String kt = scan.nextLine();
            
            System.out.println("Chuỗi vừa nhập là: ");
            for (int i = 0; i < sb.length(); i++) {
                System.out.println(sb.charAt(i));
            }
            kiemTra(sb, kt);
        } catch (InputMismatchException e) {
            System.out.println("Định dạng nhập vào không đúng");
        } catch (NumberFormatException e){
            System.out.println(e.getMessage());
        }

    }

}
