/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11_ng;

/**
 *
 * @author hocvien
 */
public class Bai1_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        StringBuilder sb1 = new StringBuilder();
        StringBuilder sb2 = new StringBuilder();
        
        long t1 = System.currentTimeMillis();
        for(int i = 1; i <= 1000000; i++){
            sb1.append('A');
        }
        long t2 = System.currentTimeMillis();
        
        long t3 = System.currentTimeMillis();
        for(int i = 1; i <= 1000000; i++){
            sb2.append("A");
        }
        long t4 = System.currentTimeMillis();
        
        long kt1 = t2 - t1;
        long kt2 = t4 - t3;
        
        System.out.println("Chiều dài chuỗi sb1: "+sb1.length());
        System.out.println("Chiều dài chuỗi sb2: "+sb2.length());
        System.out.println("Thời gian tạo chuỗi s1: "+kt1);
        System.out.println("Thời gian tạo chuỗi s2: "+kt2);
        if(kt1 > kt2)
            System.out.println("thời gian tạo sb1 dài hơn sb2");
        else
            System.out.println("thời gian tạo sb1 ngắn hơn sb2");
    }
    
}
