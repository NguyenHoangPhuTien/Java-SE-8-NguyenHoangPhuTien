/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11_ng;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai11_Ng {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);

        try {
            System.out.println("Nhập chuỗi s1: ");
            String s1 = scan.nextLine();

            System.out.println("Nhập chuỗi s2: ");
            String s2 = scan.nextLine();

            System.out.println("Nhập chuỗi s3: ");
            String s3 = scan.nextLine();

            System.out.println("Nhập vị trí v: ");
            int v = scan.nextInt();
            
            System.out.println("Chiều dài chuỗi s1: "+s1.length());
            
            System.out.println("Chiều dài chuỗi s2: "+s2.length());
            
            System.out.println("Chiều dài chuỗi s3: "+s3.length());
            
            int soSanh = s1.compareTo(s2);
            System.out.println("Kết quả so sánh s1 & s2: "+soSanh);
            
            soSanh = s1.indexOf(s3);
            System.out.println("Vị trí xuất hiện của chuỗi s3 trong s1: "+soSanh);
            
            String s4 = s1.substring(v);
            System.out.println("Chuỗi s4: "+s4);
            
        } catch (InputMismatchException e) {
            System.out.println("Định dạng nhập vào không đúng");
        }

    }

}
