/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11_ng;

import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai1_1 {

    /**
     * @param args the command line arguments
     */
    private static String[] taoMang(String[] mangTen) {

        Scanner scan = new Scanner(System.in);

        if (mangTen == null) {
            throw new NullPointerException("Mảng đang có giá trị null");
        }
        for (int i = 0; i < mangTen.length; i++) {
            System.out.println("Nhập tên: ");
            mangTen[i] = scan.nextLine();
        }
        return mangTen;
    }

    private static void xuatMang(String[] mangTen) {

        if (mangTen == null) {
            throw new NullPointerException("Mảng đang có giá trị null");
        }

        String s = "";
        for (int i = 0; i < mangTen.length; i++) {

            s += mangTen[i] + " ";
        }
        System.out.println("Mãng vừa tạo là: " + s);
    }

    private static void kiemTraTen(String[] mangTen, String ten) {

        if (mangTen == null) {
            throw new NullPointerException("Mảng đang có giá trị null");
        }

        String s = "Tên không có trong mãng";
        for (int i = 0; i < mangTen.length; i++) {
            if (mangTen[i].equals(ten)) {
                s = ten + " xuất hiện đầu tiên ở vị trí " + i;
                break;
            }
        }
        System.out.println(s);

    }

    private static void layTenTheoDK(String[] mangTen, String kiTu) {

        if (mangTen == null) {
            throw new NullPointerException("Mảng đang có giá trị null");
        }

        String s = "";
        for (int i = 0; i < mangTen.length; i++) {
            if (mangTen[i].indexOf(kiTu) >= 0) {

                s += mangTen[i] + " ";
            }
        }
        if (s.equals("")) {
            System.out.println("Không có tên nào thõa điều kiện");
        } else {
            System.out.println("Các tên thỏa điều kiện: " + s);
        }
    }

    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);

        System.out.println("Nhập tên cần kiểm tra: ");
        try {
            String ten = scan.nextLine();

            System.out.println("Nhập kí tự cần kiểm tra: ");
            String kiTu = scan.nextLine();

            System.out.println("Nhâp chiều dài mảng: ");
            int n = scan.nextInt();

            String[] mangTen = new String[n];

            mangTen = taoMang(mangTen);

            xuatMang(mangTen);

            kiemTraTen(mangTen, ten);
            layTenTheoDK(mangTen, kiTu);

            Arrays.sort(mangTen);
            System.out.println("Danh sách tên sau khi sắp xếp: ");
            xuatMang(mangTen);
        } catch (InputMismatchException e) {
            System.out.println("Định dạng nhâp vào không đúng");
        } catch (NullPointerException e){
            System.out.println(e.getMessage());
        }

    }

}
