/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11_ng;

/**
 *
 * @author hocvien
 */
public class Bai1_3 {

    /**
     * @param args the command line arguments
     */
    private static String taoChuoiString(){
        
        String s = "";
        for(int i = 0; i <= 10000; i++){
            s += i + " ";
        }
        return s;
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        long t1 = System.currentTimeMillis();
        String s = taoChuoiString();
        long t2 = System.currentTimeMillis();
        
        long t3 = System.currentTimeMillis();
        StringBuilder s1 = new StringBuilder();
         for(int i = 0; i <= 10000; i++){
            s1.append(i + " ");
        }
        long t4 = System.currentTimeMillis();
        long kt1 = t2 - t1;
        long kt2 = t4 - t3;
        System.out.println("Chiều dài chuỗi s: "+s.length());
        System.out.println("Chiều dài chuỗi s1: "+s1.length());
        System.out.println("Thời gian tạo chuỗi s là: "+kt1);
        System.out.println("Thời gian tạo chuỗi s1 là: "+kt2);
        if(kt1 > kt2)
            System.out.println("thời gian s dài hơn s1");
        else
            System.out.println("thời gian s1 dài hơn s2");
    }
    
}
