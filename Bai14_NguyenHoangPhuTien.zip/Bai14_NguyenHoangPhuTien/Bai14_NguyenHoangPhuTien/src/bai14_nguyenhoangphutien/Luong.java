/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai14_nguyenhoangphutien;

/**
 *
 * @author hocvien
 */
public class Luong {

    public double tinhLuong(double heSoLuong, double luongCoBan, double troCap, double thuong) {

        double kq = heSoLuong * luongCoBan + troCap + thuong;
        return kq;
    }
}
