/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai14_nguyenhoangphutien;

import jdk.nashorn.internal.objects.Global;

/**
 *
 * @author hocvien
 */
public class PhuongTrinhBac2 {

    public double[] giaiPhuongTrinh(double a, double b, double c) {

        double[] kq = null;
        double x1, x2;
        double delta;

        if (a == 0) {
            if (b == 0) {
                if (c == 0) {
                    kq = new double[1];
                    kq[0] = Global.Infinity;
                } else {
                    kq = null;
                }
            } else {
                x1 = (-c) / b;
                kq = new double[1];
                kq[0] = x1; 
            }
        }
        else {
            delta= Math.pow(b, 2)-(4*a*c);  
            if(delta<0){
                kq = new double[1];
                kq[0] = Global.Infinity;
               
            }
            else 
            {
              if(delta==0)
              {
               x1= -b/(2*a);
               kq = new double[1];
               kq[0] = x1; 
               
              }
              else 
              {
                if(delta>0)
                {
                    x1=(-b+Math.sqrt(delta))/(2*a);
                    x2=(-b-Math.sqrt(delta))/(2*a);
                    kq = new double[2];
                    kq[0] = x1;
                    kq[1] = x2;
                }
              }   
            }
        }
        return kq;
    }
}
