/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TestUnit;

import bai14_nguyenhoangphutien.PhuongTrinhBac2;
import jdk.nashorn.internal.objects.Global;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Asus
 */
public class TestPhuongTrinhBac2 {
    
    PhuongTrinhBac2 pt = new PhuongTrinhBac2();
    
    public TestPhuongTrinhBac2() {
    }
    
   @Test
   public void testPhuongTrinhBac2_1(){
       
       double[] ac = pt.giaiPhuongTrinh(0, 0, 0);
       double[] ex = {Global.Infinity};
       assertArrayEquals(ex, ac, 0);
   }
   
   @Test
   public void testPhuongTrinhBac2_2(){
       
       double[] ac = pt.giaiPhuongTrinh(0, 0, 2);
       assertNull(ac);
   }
   
   @Test
   public void testPhuongTrinhBac2_3(){
       
       double[] ac = pt.giaiPhuongTrinh(0, 2, 4);
       double[] ex = {-2};
       assertArrayEquals(ex, ac, 0);
   }
   
   @Test
   public void testPhuongTrinhBac2_4(){
       
       double[] ac = pt.giaiPhuongTrinh(1, 5, 6);
       double[] ex = {-2,-3};
       assertArrayEquals(ex, ac, 0);
   }
   
   @Test
   public void testPhuongTrinhBac2_5(){
       
       double[] ac = pt.giaiPhuongTrinh(1, 6, 6);
       double[] ex = {-1.2679491924311228,-4.732050807568877};

       assertArrayEquals(ex, ac, 0);
   }
   
    @Test
   public void testPhuongTrinhBac2_6(){
       
       double[] ac = pt.giaiPhuongTrinh(0, 0, 0);
       double[] ex = {3};
       assertArrayEquals(ex, ac, 0);
   }
   
   @Test
   public void testPhuongTrinhBac2_7(){
       
       double[] ac = pt.giaiPhuongTrinh(0, 0, 2);
       assertNotNull(ac);
   }
   
   @Test
   public void testPhuongTrinhBac2_8(){
       
       double[] ac = pt.giaiPhuongTrinh(0, 2, 4);
       double[] ex = {-3};
       assertArrayEquals(ex, ac, 0);
   }
   
   @Test
   public void testPhuongTrinhBac2_9(){
       
       double[] ac = pt.giaiPhuongTrinh(1, 5, 6);
       double[] ex = {-3,-3};
       assertArrayEquals(ex, ac, 0);
   }
   
   @Test
   public void testPhuongTrinhBac2_10(){
       
       double[] ac = pt.giaiPhuongTrinh(1, 6, 6);
       double[] ex = {-1.267949192431138,-4.7320508075683377};

       assertArrayEquals(ex, ac, 0);
   }
}
