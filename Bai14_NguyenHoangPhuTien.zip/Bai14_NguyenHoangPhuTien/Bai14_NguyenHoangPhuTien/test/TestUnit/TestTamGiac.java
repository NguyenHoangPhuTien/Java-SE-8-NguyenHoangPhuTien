/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TestUnit;

import bai14_nguyenhoangphutien.TamGiac;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hocvien
 */
public class TestTamGiac {
    
    TamGiac tamGiac = new TamGiac();
    public TestTamGiac() {
    }

    @Test
    public void testTamGiac_1(){
        
        boolean kq = tamGiac.ktTamGiac(1, 2, 4);
        assertTrue(kq);
    }
    @Test
    public void testTamGiac_2(){
        
        boolean kq = tamGiac.ktTamGiac(2, 3, 4);
        assertTrue(kq);
    }
    @Test
    public void testTamGiac_3(){
        
        boolean kq = tamGiac.ktTamGiac(3, 1, 5);
        assertTrue(kq);
    }
    @Test
    public void testTamGiac_4(){
        
        boolean kq = tamGiac.ktTamGiac(4, 5, 6);
        assertTrue(kq);
    }
    @Test
    public void testTamGiac_5(){
        
        boolean kq = tamGiac.ktTamGiac(10, 5, 20);
        assertTrue(kq);
    }@Test
    public void testTamGiac_6(){
        
        boolean kq = tamGiac.ktTamGiac(1, 1, 1);
        assertTrue(kq);
    }
    @Test
    public void testTamGiac_7(){
        
        boolean kq = tamGiac.ktTamGiac(2, 1, 4);
        assertTrue(kq);
    }
    @Test
    public void testTamGiac_8(){
        
        boolean kq = tamGiac.ktTamGiac(5, 10, 8);
        assertTrue(kq);
    }
    @Test
    public void testTamGiac_9(){
        
        boolean kq = tamGiac.ktTamGiac(6, 3, 10);
        assertTrue(kq);
    }@Test
    public void testTamGiac_10(){
        
        boolean kq = tamGiac.ktTamGiac(2, 4, 5);
        assertTrue(kq);
    }
    
}
