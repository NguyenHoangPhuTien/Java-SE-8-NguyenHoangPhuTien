/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TestUnit;

import bai14_nguyenhoangphutien.PhuongTrinhBac2;
import jdk.nashorn.internal.objects.Global;

/**
 *
 * @author Asus
 */
public class test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        PhuongTrinhBac2 pt = new PhuongTrinhBac2();
        double[] kq = pt.giaiPhuongTrinh(0, 0, 0);
        System.out.println(kq[0]);
        double[] kq1 = {Global.Infinity};
        System.out.println(kq1[0] == kq[0]);
    }
    
}
