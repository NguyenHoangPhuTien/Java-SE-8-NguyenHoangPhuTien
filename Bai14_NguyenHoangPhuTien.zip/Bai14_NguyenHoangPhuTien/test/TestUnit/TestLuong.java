/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TestUnit;

import bai14_nguyenhoangphutien.Luong;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hocvien
 */
public class TestLuong {
    
    Luong luong = new Luong();
    
    public TestLuong() {
    }

    @Test
    public void testLuong_1(){
        
        double ac = luong.tinhLuong(2.34, 1150000, 100000, 250000);
        double ex = 3041000;
        assertEquals(ex, ac, 0);
        
    }
    
    @Test
    public void testLuong_2(){
        
        double ac = luong.tinhLuong(3, 1150000, 150000, 250000);
        double ex = 3800000;
        assertEquals(ex, ac, 0);
        
    }
    @Test
    public void testLuong_3(){
        
        double ac = luong.tinhLuong(3.33, 1150000, 200000, 300000);
        double ex = 4329500;
        assertEquals(ex, ac, 0);
        
    }
    @Test
    public void testLuong_4(){
        
        double ac = luong.tinhLuong(3.66, 1150000, 300000, 300000);
        double ex = 4800000;
        assertEquals(ex, ac, 0);
        
    }
    @Test
    public void testLuong_5(){
        
        double ac = luong.tinhLuong(3.99, 1150000, 400000, 350000);
        double ex = 5338500;
        assertEquals(ex, ac, 0);
        
    }
    @Test
    public void testLuong_6(){
        
        double ac = luong.tinhLuong(2.22, 1150000, 100000, 150000);
        double ex = 2800000;
        assertEquals(ex, ac, 0);
        
    }
    @Test
    public void testLuong_7(){
        
        double ac = luong.tinhLuong(2.04, 1150000, 150000, 150000);
        double ex = 2646000;
        assertEquals(ex, ac, 0);
        
    }
    @Test
    public void testLuong_8(){
        
        double ac = luong.tinhLuong(2.67, 1150000, 200000, 250000);
        double ex = 3500000;
        assertEquals(ex, ac, 0);
        
    }
    @Test
    public void testLuong_9(){
        
        double ac = luong.tinhLuong(4.22, 1150000, 500000, 450000);
        double ex = 5803000;
        assertEquals(ex, ac, 0);
        
    }
    @Test
    public void testLuong_10(){
        
        double ac = luong.tinhLuong(4.55, 1150000, 300000, 500000);
        double ex = 6000000;
        assertEquals(ex, ac, 0);
        
    }
    
}
