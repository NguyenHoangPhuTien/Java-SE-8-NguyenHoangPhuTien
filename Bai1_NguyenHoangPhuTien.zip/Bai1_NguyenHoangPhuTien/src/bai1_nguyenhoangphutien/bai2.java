/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai1_nguyenhoangphutien;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class bai2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String hoten ="" , email="";
        Scanner scan = new Scanner(System.in);
        System.out.println("Xin hay nhap ho ten:");
        hoten = scan.nextLine();
        System.out.println("Xin hay nhap email: ");
        email = scan.nextLine();
        System.out.println("********************************");
        System.out.println("Dang ki thong tien hoc vien");
        System.out.println("********************************");
        System.out.println("");
        System.out.println("");
        System.out.println("Ho ten: "+hoten);
        System.out.println("Email: "+email);
        System.out.println("---------------------------------");
        System.out.println("----Xin chao ban "+hoten);
        System.out.println("----Thong tin cua ban duoc ghi nhan");
        
        
    }
    
}
