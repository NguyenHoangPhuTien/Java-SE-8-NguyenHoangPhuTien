/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai2_nguyenhoangphutien;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class DienTichvaChuViHT {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
    
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Nhập bán kính: ");
        double banKinh = Double.parseDouble(input.readLine());
        double chuVi = 2*banKinh*Math.PI;
        double dienTich = Math.PI*banKinh*banKinh;
        System.out.println(String.format("Chu vi là: %.2f", chuVi));
        System.out.println(String.format("Diện tích là: %.2f", dienTich));
        
    }
    
}
