/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai2_nguyenhoangphutien;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class DoiTien {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        System.out.println("Tên ngoại tệ:");
        String ngoaiLe = scan.nextLine();
        System.out.println("Tỹ giá:");
        int tyGia = scan.nextInt();
        System.out.println("Số ngoại tệ:");
        int soNgoaiTe = scan.nextInt();
        int thanhTien = tyGia*soNgoaiTe;
        System.out.println("Bạn đang đổi từ: "+ngoaiLe+" sang VND");
        System.out.println("Thành tiền: "+thanhTien);
        
    }
    
}
