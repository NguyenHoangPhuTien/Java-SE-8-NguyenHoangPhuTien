/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai2_nguyenhoangphutien;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class TinhBKHT {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        System.out.println("Hãy nhập diện tích hình tròn:");
        double dienTich = scan.nextDouble();
        double banKinh = Math.sqrt(dienTich/Math.PI);
        System.out.println(String.format("Bán kính hình tròn là: %.2f", banKinh));
    }
    
}
