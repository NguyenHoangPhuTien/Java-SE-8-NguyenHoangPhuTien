/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai2_nguyenhoangphutien;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class TinhDTHinhChuNhat {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        System.out.println("Hãy nhập chiều rộng: ");
        double chieuRong = scan.nextDouble();
        System.out.println("Hãy nhập chiều dài: ");
        double chieuDai = scan.nextDouble();
        double chuVi = (chieuDai+chieuRong)*2;
        double dienTich = chieuDai * chieuRong;
        System.out.println(String.format("Chu vi hình chữ nhật là: %.2f", chuVi));
        System.out.println(String.format("Diện tích hình chữ nhật là: %.2f", dienTich));
    }
    
}
