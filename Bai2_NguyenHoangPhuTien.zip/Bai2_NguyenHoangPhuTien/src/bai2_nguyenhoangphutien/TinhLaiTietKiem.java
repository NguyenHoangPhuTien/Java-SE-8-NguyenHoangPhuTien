/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai2_nguyenhoangphutien;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class TinhLaiTietKiem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        System.out.println("Lãi suất một tháng:");
        double laiSuat = scan.nextDouble();
        System.out.println("Số tiền gữi:");
        int tienGui = scan.nextInt();
        System.out.println("Số tháng:");
        int soThang = scan.nextInt();
        double tienLai = (tienGui*soThang)*(laiSuat/12/100);
        double tongTien = tienGui+tienLai;
        System.out.println(String.format("Tiền lãi: %.2f", tienLai));
        System.out.println(String.format("Tổng vốn và lãi l:à %.2f", tongTien));
    }
    
}
