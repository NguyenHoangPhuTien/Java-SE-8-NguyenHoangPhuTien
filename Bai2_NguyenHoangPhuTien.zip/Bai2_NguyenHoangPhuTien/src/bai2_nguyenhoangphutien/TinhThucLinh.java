/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai2_nguyenhoangphutien;

import java.util.Scanner;
import javax.sound.midi.SysexMessage;

/**
 *
 * @author hocvien
 */
public class TinhThucLinh {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        System.out.println("Nhập số sản phẩm:");
        int sanPham = scan.nextInt();
        System.out.println("Nhập tiền công một sản phẩm:");
        int tienCong = scan.nextInt();
        System.out.println("Nhập tiền thưởng:");
        int tienThuong = scan.nextInt();
        System.out.println("Nhập số con:");
        int soCon = scan.nextInt();
        int tienLuong = sanPham*tienCong;
        int phuCap = soCon*200000;
        int thucLinh = tienLuong+tienThuong+phuCap;
        System.out.println("Tiền lương: "+tienLuong);
        System.out.println("Phụ cấp: "+phuCap);
        System.out.println("Thực lĩnh: "+thucLinh);
        
    }
    
}
