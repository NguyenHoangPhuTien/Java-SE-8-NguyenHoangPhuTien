/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai3_nguyenhoangphutien;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai3_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner scan = new Scanner(System.in);
        System.out.println("Nhập x:");
        int x = scan.nextInt();
        double s = 1 + x + x*x*x/3 + x*x*x*x*x/5;
        System.out.println("S = "+s);
    }
    
}
