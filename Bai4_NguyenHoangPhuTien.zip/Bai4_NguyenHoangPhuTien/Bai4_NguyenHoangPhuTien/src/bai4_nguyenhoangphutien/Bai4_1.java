/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai4_nguyenhoangphutien;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai4_1 {

    /**
     * @param args the command line arguments
     */
    private static int[] changeArrInt(String[] s){
        int[] arr = new int[s.length] ;
        int i;
        for(i=0;i<s.length;i++){
            arr[i] = Integer.parseInt(s[i]);
        }
        return arr;
    }
    public static void main(String[] args) {
        // TODO code application logic here
         
        Scanner scan = new Scanner(System.in);
        System.out.println("Xin hãy nhập dãy số cách nhau bằng dấu spacebar: ");
        String input = scan.nextLine();
       
        String[] s = input.split(" ");
        int arr[] = changeArrInt(s);
        int i , max = arr[0] , min = arr[0];
        for(i=0;i<arr.length-1;i++){
            max = Math.max(max,arr[i+1]);
            min = Math.min(min, arr[i+1]);
                
        }
       
        System.out.println("Số lớn nhất là : "+max);
        System.out.println("Số nhỏ nhất là : "+min);
    }
    
}
