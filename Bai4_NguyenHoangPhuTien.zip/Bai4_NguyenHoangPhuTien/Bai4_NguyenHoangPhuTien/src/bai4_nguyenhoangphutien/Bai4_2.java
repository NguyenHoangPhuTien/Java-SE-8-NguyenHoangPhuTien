/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai4_nguyenhoangphutien;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai4_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      Scanner scan = new Scanner(System.in);
      
      System.out.println("Nhập loại xe ( 4 hay 7 chỗ):");
      int xe = scan.nextInt();
      
      System.out.println("Nhập số km:");
      double soKM = scan.nextDouble();
      double soTien =0;
      if(xe==4){
          if(soKM <= 0.8)
              soTien = 11000 * soKM ;
          else if(soKM > 30)
              soTien = 11000 + (30-0.8)*124000 + (soKM - 30)*12400 ;
          else
              soTien = 16500 * (soKM-0.8)+11000 ;
      }else if(xe==7){
          if(soKM <= 0.8)           
              soTien = 11000 * soKM ;
          else if(soKM >= 31)
              soTien = 11000 + (30-0.8)*124000 + (soKM - 30)*14400;
          else
              soTien = 17000 *(soKM-0.8)+11000 ;
      }
        System.out.println("Thành tiền: "+soTien);
    }
    
}
