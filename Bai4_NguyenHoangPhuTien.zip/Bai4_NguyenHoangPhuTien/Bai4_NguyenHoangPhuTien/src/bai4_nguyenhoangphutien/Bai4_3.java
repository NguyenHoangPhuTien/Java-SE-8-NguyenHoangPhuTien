/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai4_nguyenhoangphutien;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai4_3 {

    /**
     * @param args the command line arguments
     */
   
    
     static final int tienBac1 = 1388 ;
     static final int tienBac2 = 1433 ;
     static final int tienBac3 = 1660 ;
     static final int tienBac4 = 2082 ;
     static final int tienBac5 = 2324 ;
     static final int tienBac6 = 2399 ;
     static final int dinhMuc1 = 50 ;
     static final int dinhMuc2 = 100 ;
     
    
    public static void main(String[] args) {
        // TODO code application logic here
         Scanner scan = new Scanner(System.in);
        System.out.println("Xin nhập số điện tiêu thụ:");
        double soDien = scan.nextDouble();
        double soTien = 0 ;
        if(soDien <= 50)
            soTien = soDien*tienBac1;
        else if(soDien <= 100)
            soTien = (soDien - dinhMuc1)*tienBac2 + tienBac1*dinhMuc1;
        else if(soDien <= 200)
            soTien = (soDien- dinhMuc2)*tienBac3 + tienBac2*dinhMuc1 + tienBac1*dinhMuc1;
        else if(soDien <= 300)
            soTien = (soDien - dinhMuc2*2)*tienBac4 + tienBac3*dinhMuc2 + tienBac2*dinhMuc1 + tienBac1*dinhMuc1;
        else if(soDien <= 400)
            soTien = (soDien - dinhMuc2*3)*tienBac5 + tienBac4*dinhMuc2 + tienBac3*dinhMuc2 + tienBac2*dinhMuc1 + tienBac1*dinhMuc1;
        else if(soDien > 400)
            soTien = (soDien - dinhMuc2*4)*tienBac6 + tienBac5*dinhMuc2 + tienBac4*dinhMuc2 + tienBac3*dinhMuc2 + tienBac2*dinhMuc1 + tienBac1*dinhMuc1;
        double tien = soTien;
        System.out.println("Thành tiền là: "+soTien);
    }
    
}
    
