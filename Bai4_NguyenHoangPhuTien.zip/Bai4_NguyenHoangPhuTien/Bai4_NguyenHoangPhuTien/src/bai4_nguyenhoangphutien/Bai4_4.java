/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai4_nguyenhoangphutien;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai4_4 {

    /**
     * @param args the command line arguments
     */
    static final int tienPhongLoai1 = 1260000;
    static final int tienPhongLoai2 = 1550000;
    static final int tienPhongLoai3 = 1830000;
    static final int tienPhongLoai4 = 1830000;
    static final int tienPhongLoai5 = 2120000;
    static final int tienPhongLoai6 = 2120000;
    static final int tienPhongLoai7 = 2540000;
    static final int tienPhongLoai8 = 4800000;
    
    private static int tinhTien(int tienLoaiPhong , int soDem){
        int tien = 0;
        if(soDem == 1)
            tien = tienPhongLoai1;
        else if(soDem >= 4)
            tien = tienLoaiPhong/100*70*soDem;
        else
            tien = tienLoaiPhong/100*75*soDem;
        return tien;
    }
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Nhập loại phòng:");
        int loaiPhong = scan.nextInt();
        
        System.out.println("Nhập số đêm:");
        int soDem = scan.nextInt();
        
        int tien = 0;
        
        switch(loaiPhong){
            case 1:
                tien = tinhTien(tienPhongLoai1, soDem);
                break;
                
            case 2:
                tien = tinhTien(tienPhongLoai2, soDem);
                break;
            
            case 3:
                tien = tinhTien(tienPhongLoai3, soDem);
                break;
                
            case 4:
                tien = tinhTien(tienPhongLoai4, soDem);
                break;
                
            case 5:
                tien = tinhTien(tienPhongLoai5, soDem);
                break;
                
            case 6:
                tien = tinhTien(tienPhongLoai6, soDem);
                break;
                
             case 7:
                 tien = tinhTien(tienPhongLoai7, soDem);
                break;
                
            case  8:
                tien = tinhTien(tienPhongLoai8, soDem);
                break;
             
        }
        System.out.println("Thành tiền: "+tien);
    }
    
}
