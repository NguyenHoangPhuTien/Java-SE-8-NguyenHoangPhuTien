/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai4_nguyenhoangphutien;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai4_5 {

    /**
     * @param args the command line arguments
     */
    
    
    private static int laySoNgayTrongThang(int thang){
        
        int ngay = 0;
        switch(thang){
            
            case 1:
                ngay = 31;
                break;
                
            case 2:
                ngay = 28;
                break;
                
            case 3:
                ngay = 31;
                break;
                
            case 4:
                ngay = 30;
                break;
                
            case 5:
                ngay = 31;
                break;
                
            case 6:
                ngay = 30;
                break;
                
            case 7:
                ngay = 31;
                break;
                
            case 8:
                ngay = 31;
                break;
                
            case 9:
                ngay = 30;
                break;
                
            case 10:
                ngay = 31;
                break;
                
            case 11:
                ngay = 30;
                break;
                
            case 12:
                ngay = 31;
                break;
            
        }
        return ngay ;
    }
    
    private static void layNgayHomSau(int thang , int ngay , int nam){
        
        int soNgayCuaThang = laySoNgayTrongThang(thang);
       
        if(ngay <= 0 || ngay > soNgayCuaThang)
            System.out.println("Ngày nhập không hợp lệ:");
        else if(ngay < soNgayCuaThang){
             
             if(ngay == 1){
                 if(thang == 1)
                     System.out.println("Đây là ngày 31 tháng 12 của năm "+(nam - 1));
                 else{
                     System.out.println("Ngày hôm trước là ngày "+soNgayCuaThang+" của tháng "+(thang - 1));
                     System.out.println("Ngày hôm sau là ngày "+(ngay+1)+" của tháng "+thang);
                 }
                     
             }
             else
                System.out.println("Ngày hôm sau là ngày "+(ngay+1)+" của tháng "+thang); 
                System.out.println("Ngày hôm trước là ngày "+(ngay - 1)+" của tháng "+(thang));
                
        }   
        else{
            
            if(thang == 12)
                System.out.println("Đây là ngày 1 của tháng 1 năm "+(nam + 1));
            else
                System.out.println("Đây là ngày 1 của thang  "+(thang+1));
                System.out.println("Ngày hôm trước là ngày "+(ngay - 1)+" của tháng "+(thang));
        }
            
    }
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Hãy nhập tháng: ");
        int thang = scan.nextInt();
        
        System.out.println("Hãy nhập ngày: ");
        int ngay = scan.nextInt();
        
        System.out.println("Hãy nhập năm: ");
        int nam = scan.nextInt();
        
        if(thang > 12 || thang < 1)
            System.out.println("Tháng Không Hợp lệ:");
        else {
            System.out.println("Số ngày trong tháng: "+laySoNgayTrongThang(thang));
            layNgayHomSau(thang, ngay, nam);
        }
    }
    
}
