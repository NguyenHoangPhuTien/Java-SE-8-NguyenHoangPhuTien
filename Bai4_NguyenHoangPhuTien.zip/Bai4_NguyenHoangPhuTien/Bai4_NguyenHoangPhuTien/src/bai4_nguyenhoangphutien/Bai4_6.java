/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai4_nguyenhoangphutien;

import java.util.Scanner;

/**
 *
 * @author Asus
 */
public class Bai4_6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Scanner scan = new Scanner(System.in);
       
        System.out.println("Hãy chọn loại độ mún xem:");
        String loaiDo = scan.nextLine();
        
        System.out.println("Hãy nhập nhiệt độ");
        double nhietDo = scan.nextDouble();
        
        switch(loaiDo){
            
            case "F": case "f":
                nhietDo = (nhietDo*1.8)+32;
                break;
            
            case "C": case "c":
                nhietDo = 5*(nhietDo-32)/9;
                break;
        }
        System.out.println(String.format("Nhiệt độ là %.2f", nhietDo));
                
    }
    
}
