/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai4_nguyenhoangphutien;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai4_4 {

    /**
     * @param args the command line arguments
     */
    private static int tinhTien(int tienLoaiPhong , int soDem){
        int tien = 0;
        if(soDem == 1)
            tien = 1260000;
        else if(soDem >= 4)
            tien = tienLoaiPhong/100*70*soDem;
        else
            tien = tienLoaiPhong/100*75*soDem;
        return tien;
    }
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Nhập loại phòng:");
        int loaiPhong = scan.nextInt();
        
        System.out.println("Nhập số đêm:");
        int soDem = scan.nextInt();
        
        int tien = 0;
        
        switch(loaiPhong){
            case 1:
                tien = tinhTien(1260000, soDem);
                break;
                
            case 2:
                tien = tinhTien(1550000, soDem);
                break;
            
            case 3:
                tien = tinhTien(1830000, soDem);
                break;
                
            case 4:
                tien = tinhTien(1830000, soDem);
                break;
                
            case 5:
                tien = tinhTien(2120000, soDem);
                break;
                
            case 6:
                tien = tinhTien(2120000, soDem);
                break;
                
             case 7:
                 tien = tinhTien(2540000, soDem);
                break;
                
            case  8:
                tien = tinhTien(4800000, soDem);
                break;
             
        }
        System.out.println("Thành tiền: "+tien);
    }
    
}
