/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai4_nguyenhoangphutien;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai4_NguyenHoangPhuTien {

    /**
     * @param args the command line arguments
     */
    private static int[] changeArrInt(String[] s){
        int[] arr = new int[s.length] ;
        int i;
        for(i=0;i<s.length;i++){
            arr[i] = Integer.parseInt(s[i]);
        }
        return arr;
    }
    public static void main(String[] args) {
        
        Scanner scan = new Scanner(System.in);
        System.out.println("Xin hãy nhập dãy số cách nhau bằng dấu spacebar: ");
        String input = scan.nextLine();
        String[] s = input.split(" ");
        int arr[] = changeArrInt(s);
        int i , max = 0;
        for(i=0;i<arr.length-1;i++){
            if(arr[i]>arr[i+1])
                max = arr[i];
        }
        System.out.println("Số lớn nhất là : "+max);
    }
    
}
