/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai5_nguyenhoangphutien;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai5_3_while {

    /**
     * @param args the command line arguments
     */
    private static void kiemTraNguyenTo(int soNguyenTo){
        
        String s="Đây là số nguyên tố";
        if(soNguyenTo < 2)
            s = "Không phải là số nguyên tố";
        else if(soNguyenTo > 2){
            int i = 2;
            int temp = (int) Math.sqrt(soNguyenTo);
            while (i <= temp){
                if(soNguyenTo % i == 0)
                    s = "Không phải là số nguyên tố";
                i++;
            } 
        }
        System.out.println(s);
    }
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Nhâp số nguyên cần kiểm tra: ");
        int soNguyen= scan.nextInt();
        
        kiemTraNguyenTo(soNguyen);
    }
    
}
