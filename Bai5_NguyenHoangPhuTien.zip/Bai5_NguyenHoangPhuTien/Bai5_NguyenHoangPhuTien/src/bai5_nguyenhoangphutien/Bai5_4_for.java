/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai5_nguyenhoangphutien;

import java.util.Scanner;

/**
 *
 * @author Asus
 */
public class Bai5_4_for {

    /**
     * @param args the command line arguments
     */
    private static int tinhTongChan(int n){
        
        
        int iSum = 0, i;
        for(i = 1; i <= n; i++){
            if(i % 2 == 0)
                iSum += i;
        }
        return iSum;
    }
    private static int tinhTongLe(int n){
        
       
        int iSum = 0, i;
        for(i = 1; i <= n; i++){
            if(i % 2 != 0)
                iSum += i;
        }
        return iSum;
    }
    private static int tinhTich(int n){
        int iTich = 1, i;
        if(n == 0)
            iTich = 0;
        for(i = 1; i <= n; i++){
            iTich *= i;
        }
        return iTich;
    }
    private static int tinhTongTich(int n){
        int iTich = 1,i;
        if(n == 0)
            iTich = 0;
        for(i = 1;i <= n; i++){
            if(i % 3 == 0)
                iTich *= i;
        }
        return iTich;
    } 
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Hãy nhập vào số nguyên: ");
        int n = scan.nextInt();
        
        System.out.println("Tổng các số chẵn là: "+tinhTongChan(n));
        System.out.println("Tổng các số le là: "+tinhTongLe(n));
        System.out.println("Tích các số là: "+tinhTich(n));
        System.out.println("Tích các số chia hết cho 3: "+tinhTongTich(n));
    }
    
}
