/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai5_nguyenhoangphutien;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai5_5_for {

    /**
     * @param args the command line arguments
     */
    private static boolean kiemTraNguyenTo(int soNguyenTo){
        
        boolean kiemTra = true;
        if(soNguyenTo < 2)
            kiemTra = false;
        else if(soNguyenTo > 2){
            int i;
            int temp = (int) Math.sqrt(soNguyenTo);
            for(i = 2;i <= temp;i += 2){
                if(soNguyenTo % i == 0)
                    kiemTra = false;
               
            } 
        }
        return kiemTra;
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Hãy nhập số nguyên: ");
        int so = scan.nextInt();
        
        int i, tong = 0;
        for (i = 1; i <= so; i++){
            if (kiemTraNguyenTo(i)){
                tong += i;
            }
        }
        System.out.println("Tổng các số nguyên tố: "+tong);
    }
    
}
