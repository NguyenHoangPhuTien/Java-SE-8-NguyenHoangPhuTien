/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai5_nguyenhoangphutien;

import java.util.Scanner;

/**
 *
 * @author Asus
 */
public class Bai5_9_while {

    /**
     * @param args the command line arguments
     */
    private static void tinhGiaiThuaBac1(int so){
        String chuoi = so+"! = ";
        int i = 1, tich = 1;
        if(so == 0)
            chuoi = "0! = 1";
        else{
           while (i <= so){
               if (i == 1)
                   chuoi += "1";
               else
                   chuoi += " x "+i;
               tich *= i;
               i++;
           } 
        }
        System.out.println(chuoi + " = "+tich);
    }
    private static void tinhGiaiThuaBac2(int so){
        String chuoi = so+"!! = ";
        int i = 1, tich = 1;
        if(so == 0)
            chuoi = "0!! = 0 ";
        else{
               if (so % 2 == 0){
                   while (i <= so){
                       if(i % 2 == 0){
                           chuoi += i+" x ";
                           tich *= i;
                       }
                       i++;
                   } 
                }
               else{
                   while (i <= so){
                       if(i % 2 != 0){
                           chuoi += i+" x ";
                           tich *= i;
                       }
                       i++;
                   } 
               }
          
        }
        chuoi = chuoi.substring(0,chuoi.length()-2);
        System.out.println(chuoi + " = "+tich);
    }
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Nhập số nguyên: ");
        int so = scan.nextInt();
        
        tinhGiaiThuaBac1(so);
        tinhGiaiThuaBac2(so);
    }
    
}
