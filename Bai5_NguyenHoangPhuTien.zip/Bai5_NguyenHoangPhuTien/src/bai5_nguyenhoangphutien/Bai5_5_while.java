/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai5_nguyenhoangphutien;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai5_5_while {

    /**
     * @param args the command line arguments
     */
    private static boolean kiemTraNguyenTo(int soNguyenTo){
        
        boolean kiemTra = true;
        if(soNguyenTo < 2)
            kiemTra = false;
        else if(soNguyenTo > 2){
            int i = 2;
            int temp = (int) Math.sqrt(soNguyenTo);
            while (i <= temp){
                if(soNguyenTo % i == 0)
                    kiemTra = false;
                i += 2;
            } 
        }
        return kiemTra;
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
         Scanner scan = new Scanner(System.in);
        
        System.out.println("Hãy nhập số nguyên: ");
        int so = scan.nextInt();
        
        int i = 1, tong = 0;
        while (i <= so){
            if (kiemTraNguyenTo(i)){
                tong += i;
            }
            i++;
        }
        System.out.println("Tổng các số nguyên tố: "+tong);
    }
    
}
