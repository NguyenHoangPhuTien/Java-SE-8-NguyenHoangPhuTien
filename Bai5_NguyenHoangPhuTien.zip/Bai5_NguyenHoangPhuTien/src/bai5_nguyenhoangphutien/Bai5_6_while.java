/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai5_nguyenhoangphutien;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai5_6_while {

    /**
     * @param args the command line arguments
     */
    private static String doiSangNhiPhan(int n){
        String s = "";
        for (int i= n; i > 0; i /= 2){
            String temp = String.valueOf(n % 2);
            s += temp;
            n = n / 2;
        }
        String reBuffer = new StringBuffer(s).reverse().toString();
        return reBuffer;
    }
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        System.out.println("Hãy nhập số cần đổi: ");
        int so = scan.nextInt();
  
        System.out.println(doiSangNhiPhan(so));
    }
    
}
