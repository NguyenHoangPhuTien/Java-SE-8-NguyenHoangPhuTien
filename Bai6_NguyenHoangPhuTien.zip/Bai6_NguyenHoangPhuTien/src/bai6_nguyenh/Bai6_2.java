/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai6_nguyenh;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai6_2 {

    /**
     * @param args the command line arguments
     */
    public static String xuatMang(int[] mang) {

        String chuoi = "";
        for (int value : mang) {
            chuoi += String.format(" %d ", value);
        }

        return chuoi;
    }

    private static String kiemTra(int x, int[] mang) {

        String chuoi = "Phần tử không xuất hiện trong mảng";
        for (int i = 0; i < mang.length; i++) {
            if (mang[i] == x) {
                chuoi = String.format("%d xuất hiện trong mảng ở vị trí %d", x, i + 1);
                break;
            }

        }
        return chuoi;
    }

    private static String kiemTraLonHon(int x, int[] mang) {

        String chuoi = x + " lớn hơn tất cả phần tử trong mảng";
        for (int value : mang) {
            if (value > x) {
                chuoi = x + " không lớn hơn tất cả phần tử trong mảng";
            }
        }
        return chuoi;
    }

    private static String timSoLonHon(int x, int[] mang) {

        String chuoi = "";
        for (int value : mang) {
            if (value > x) {
                chuoi += value + " ";
            }
        }
        chuoi = "Tất cả các số lớn hơn " + x + ": " + chuoi;
        return chuoi;
    }

    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);

        System.out.println("Hãy nhập n: ");
        int n = scan.nextInt();

        System.out.println("Hãy nhập giá trị phần tử mảng: ");
        int[] mang = new int[n];

        for (int i = 0; i < n; i++) {
            mang[i] = scan.nextInt();
        }

        System.out.println("Hãy nhập x: ");
        int x = scan.nextInt();

        System.out.println("Mảng là: " + xuatMang(mang));
        System.out.println(kiemTra(x, mang));
        System.out.println(kiemTraLonHon(x, mang));
        if (kiemTraLonHon(x, mang).equals(x + " không lớn hơn tất cả phần tử trong mảng")) {
            System.out.println(timSoLonHon(x, mang));
        }
    }

}
