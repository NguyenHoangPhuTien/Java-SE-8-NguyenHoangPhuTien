/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai6_nguyenh;

import static bai6_nguyenh.Bai6_2.xuatMang;
import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai6_3 {

    /**
     * @param args the command line arguments
     */
    public static String xuatMang(int[] mang) {
        
        String chuoi = "";
        for (int value : mang) {
            chuoi += String.format(" %d ", value);
        }
        
        return chuoi;
    }

    private static boolean kiemTraTangDan(int[] mang) {
        
        for (int i = 0; i < mang.length - 1; i++) {
            if (mang[i] > mang[i + 1]) {
                return false;
            }
        }
        return true;
    }

    private static boolean kiemTraGiamDan(int[] mang) {
        
        for (int i = 0; i < mang.length - 1; i++) {
            if (mang[i] < mang[i + 1]) {
                return false;
            }
        }
        return true;
    }

    private static int timSoDauTienTheoDieuKien(int so, int[] mang) {
        
        for (int value : mang) {
            if (value % 10 == so) {
                return value;
            }
        }
        return 0;
    }

    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Hãy nhập n: ");
        int n = scan.nextInt();
        
        System.out.println("Hãy nhập giá trị phần tử mảng: ");
        int[] mang = new int[n];
        
        for (int i = 0; i < n; i++) {
            mang[i] = scan.nextInt();
        }
        System.out.println("Hãy nhập số cần tìm: ");
        int so = scan.nextInt();
        System.out.println("Mảng là: " + xuatMang(mang));
        if (kiemTraTangDan(mang)) {
            System.out.println("Mảng có tăng dần");
        } else {
            System.out.println("Mảng không có tăng dần");
        }
        if (kiemTraGiamDan(mang)) {
            System.out.println("Mảng có giảm dần");
        } else {
            System.out.println("Mảng không có giảm dần");
        }
        if (timSoDauTienTheoDieuKien(so, mang) == 0) {
            System.out.println("Không có phần tử cần tìm");
        } else {
            System.out.println("phần tử cần tìm: " + timSoDauTienTheoDieuKien(so, mang));
        }
    }
    
}
