/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai6_nguyenh;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai6_5 {

    /**
     * @param args the command line arguments
     */
    private static void xuatMang2Chieu(int[][] mang) {

        String chuoi = "";
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                chuoi += mang[i][j] + " ";
            }
            System.out.println(chuoi);
            chuoi = "";
        }

    }

    private static int demSoPhanTuChan(int[][] mang) {

        int dem = 0;
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if (mang[i][j] % 2 == 0) {
                    dem++;
                }
            }
        }
        return dem;
    }

    private static int demSoPhanTuLe(int[][] mang) {

        int dem = 0;
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if (!(mang[i][j] % 2 == 0)) {
                    dem++;
                }
            }
        }
        return dem;
    }

    private static int tinhTrungBinhSoPhanTuLe(int[][] mang) {

        int trungBinh = 0;
        int dem = 0;
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if (!(mang[i][j] % 2 == 0)) {
                    trungBinh += mang[i][j];
                    dem++;
                }
            }
        }
        trungBinh = (dem == 0) ? 0 : (trungBinh / dem);
        return trungBinh;
    }

    private static int tinhTrungBinhSoPhanTuChan(int[][] mang) {

        int trungBinh = 0;
        int dem = 0;
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if (mang[i][j] % 2 == 0) {
                    trungBinh += mang[i][j];
                    dem++;
                }
            }
        }
        trungBinh = (dem == 0) ? 0 : (trungBinh / dem);
        return trungBinh;
    }

    private static int timPhanTuLonNhat(int[][] mang) {
        int soLonNhat = 0;
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if (mang[i][j] > soLonNhat) {
                    soLonNhat = mang[i][j];
                }
            }
        }
        return soLonNhat;
    }

    private static int timPhanTuNhoNhat(int[][] mang) {
        int soNhoNhat = mang[0][0];
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if (mang[i][j] < soNhoNhat) {
                    soNhoNhat = mang[i][j];
                }
            }
        }
        return soNhoNhat;
    }

    private static String timViTriPhanTuLonNhat(int[][] mang) {
        String chuoi = "Vị trí của số lớn nhất là: dòng 0 cột 0";
        int soLonNhat = mang[0][0];
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if (mang[i][j] > soLonNhat) {
                    soLonNhat = mang[i][j];
                    chuoi = String.format("Vị trí của số lớn nhất là: dòng %d cột %d", i, j);
                }
            }
        }
        return chuoi;
    }

    private static String timViTriPhanTuNhoNhat(int[][] mang) {
        String chuoi = "Vị trí của số nhỏ nhất là: dòng 0 cột 0";
        int soNhoNhat = mang[0][0];
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if (mang[i][j] < soNhoNhat) {
                    soNhoNhat = mang[i][j];
                    chuoi = String.format("Vị trí của số nhỏ nhất là: dòng %d cột %d", i, j);
                }
            }
        }
        return chuoi;
    }
    private static int tinhSoLanPhanTuTrungLap(int[][] mang, int phanTu){
        
        int dem = 0;
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if(mang[i][j] == phanTu)
                    dem++;
            }
        }
        return dem;
    }
    private static String timSoCoSoLanTrungLapNhieuNhat(int[][] mang){
       
        String mangTam = "";
        int dem = 0;
        int tam = 0;
        int tam1 = 0;
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                dem = tinhSoLanPhanTuTrungLap(mang, mang[i][j]);
                if(dem >= tam){
                    tam = dem;
                    tam1 = mang[i][j];
                    if(!mangTam.contains(mang[i][j]+""))
                         mangTam += tam1 +" "; 
                }
                    
            }
        }
        return mangTam;
    }
    private static String timViTriPhanTu(int[][] mang, int so){
     
        String chuoi = "";
        for (int i = 0; i < mang.length; i++) {
           for (int j = 0; j < mang[i].length; j++) {
               if(mang[i][j] == so)
                   chuoi += String.format("dòng %d cột %d ", i, j);
           }
        }
        return chuoi;
    }
    private static String kiemTraPhanTuAm(int[][] mang){
        
        String chuoi = "Không có phần tử âm";
        for (int i = 0; i < mang.length; i++) {
           for (int j = 0; j < mang[i].length; j++) {
               if(mang[i][j] < 0)
                   chuoi = "Có phần tử âm";
           }
        }
        return chuoi;
    }
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);

        System.out.println("Hãy nhập số dòng: ");
        int dong = scan.nextInt();

        System.out.println("Hãy nhập số cột: ");
        int cot = scan.nextInt();

        System.out.println("Hãy nhập giá trị phần tử mảng: ");
        int[][] mang = new int[dong][cot];

        for (int i = 0; i < dong; i++) {
            for (int j = 0; j < cot; j++) {
                mang[i][j] = scan.nextInt();
            }
        }
        System.out.println("Mảng 2 chiều là: ");
        xuatMang2Chieu(mang);
        System.out.println("Số phần tữ chẵn là: " + demSoPhanTuChan(mang));
        System.out.println("Số phần tữ lẽ là: " + demSoPhanTuLe(mang));
        System.out.println("Trung bình của các phần tử chẵn là: " + tinhTrungBinhSoPhanTuChan(mang));
        System.out.println("Trung bình của các phần tữ lẽ là: " + tinhTrungBinhSoPhanTuLe(mang));
        System.out.println("Số lớn nhất của mãng là: " + timPhanTuLonNhat(mang));
        System.out.println(timViTriPhanTuLonNhat(mang));
        System.out.println("Số nhỏ nhất của mãng là: " + timPhanTuNhoNhat(mang));
        System.out.println("Giá trị xuất hiện nhiều nhất là: "+timSoCoSoLanTrungLapNhieuNhat(mang));
       
        String[] mangTam = timSoCoSoLanTrungLapNhieuNhat(mang).split(" ");
        for(String value : mangTam){
            System.out.println("Vị trí xuất hiện của "+value+" :"+timViTriPhanTu(mang, Integer.parseInt(value)));
        }
        System.out.println(kiemTraPhanTuAm(mang));
        
    }

}
