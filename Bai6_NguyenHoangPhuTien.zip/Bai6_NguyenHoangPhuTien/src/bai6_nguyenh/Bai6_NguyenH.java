/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai6_nguyenh;

/**
 *
 * @author hocvien
 */
public class Bai6_NguyenH {

    /**
     * @param args the command line arguments
     */
     private static void kiemTraCotGiamDan(int[][] mang, int cot){
       String chuoi = "ma trận có cột giảm dần";
        for(int i = 0; i < mang.length - 1; i++){
            if(mang[i][cot] < mang[i + 1][cot])
                chuoi = "ma trận không có cột giảm dần";
        }
        System.out.println(chuoi); 
    }
     private static void kiemTraCotTangDan(int[][] mang, int cot){
        String chuoi = "ma trận có cột tăng dần";
        for(int i = 0; i < mang.length - 1; i++){
            if(mang[i][cot] > mang[i + 1][cot])
                chuoi = "ma trận không có cột tăng dần";
        }
        System.out.println(chuoi);
    }
    public static void main(String[] args) {
        // TODO code application logic here
        int[][] mang = {{4,1,1},{5,1,1},{6,1,1}};
        kiemTraCotGiamDan(mang, 0);
        kiemTraCotTangDan(mang, 0);
    }
    
}
