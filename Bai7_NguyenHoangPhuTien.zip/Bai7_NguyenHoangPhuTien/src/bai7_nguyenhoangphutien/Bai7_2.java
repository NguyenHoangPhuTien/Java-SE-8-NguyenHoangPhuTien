/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7_nguyenhoangphutien;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai7_2 {

    /**
     * @param args the command line arguments
     */
    
    private static float tinhToan(float x, int n){
        float s1 = 1,s2 = 1;
        
        int i;
        for(i = 1;i <= n;i++){
            s1 *= (Math.pow(x, 2) + x + 1);
            s2 *= (Math.pow(x, 2) - x + 1);
        }
        return s1+s2;
    }
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Nhập n: ");
        int n = scan.nextInt();
        System.out.println("Nhập x: ");
        float x = scan.nextFloat();
        
        System.out.println("Kết quả của S=(x^2 + x +1)^n + (x^2 - x +1)^n = "+tinhToan(x, n));
    }
    
}
