/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7_nguyenhoangphutien;

import java.util.Scanner;

/**
 *
 * @author Asus
 */
public class Bai7_5 {

    /**
     * @param args the command line arguments
     */
    private static String tinhBMI(double canNang, double chieuCao){
        
        String chuoi = "";
        double bmi = canNang / (chieuCao * chieuCao);
        
        if(bmi < 18.5)
            chuoi = String.format("BMI = %.1f - Kết luận: Bạn gầy", bmi);
        else if(bmi <= 24.99)
            chuoi = String.format("BMI = %.1f - Kết luận: Bạn bình thường", bmi);
        else
            chuoi = String.format("BMI = %.1f - Kết luận: Bạn thừa cân", bmi);
        
        return chuoi;
    }
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Hãy nhập chiều cao: ");
        double chieuCao = scan.nextDouble();
        
        System.out.println("Hãy nhập cân nặng: ");
        double canNang = scan.nextDouble();
        
        System.out.println(tinhBMI(canNang, chieuCao));
    }
    
}
