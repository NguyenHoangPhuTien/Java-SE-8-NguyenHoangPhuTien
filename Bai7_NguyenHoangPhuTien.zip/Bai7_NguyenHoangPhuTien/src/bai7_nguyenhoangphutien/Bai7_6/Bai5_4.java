/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7_nguyenhoangphutien.Bai7_6;

import java.util.Scanner;

/**
 *
 * @author Asus
 */
public class Bai5_4 {

    /**
     * @param args the command line arguments
     */
    private static int tinhTongChan(int n) {

        int iSum = 0, i;
        for (i = 1; i <= n; i++) {
            if (i % 2 == 0) {
                iSum += i;
            }
        }
        return iSum;
    }

    private static int tinhTongLe(int so) {

        int iSum = 0, i;
        for (i = 1; i <= so; i++) {
            if (i % 2 != 0) {
                iSum += i;
            }
        }
        return iSum;
    }

    private static int tinhTich(int so) {
        int iTich = 1, i;
        if (so == 0) {
            iTich = 0;
        }
        for (i = 1; i <= so; i++) {
            iTich *= i;
        }
        return iTich;
    }

    private static int tinhTongTich(int so) {
        int iTich = 1, i;
        if (so == 0) {
            iTich = 0;
        }
        for (i = 1; i <= so; i++) {
            if (i % 3 == 0) {
                iTich *= i;
            }
        }
        return iTich;
    }

    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);

        System.out.println("Hãy nhập vào số nguyên: ");
        int so = scan.nextInt();

        System.out.println("Tổng các số chẵn là: " + tinhTongChan(so));
        System.out.println("Tổng các số le là: " + tinhTongLe(so));
        System.out.println("Tích các số là: " + tinhTich(so));
        System.out.println("Tích các số chia hết cho 3: " + tinhTongTich(so));
    }

}
