/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7_nguyenhoangphutien.Bai7_8;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai5_7 {

    /**
     * @param args the command line arguments
     */
    private static int doiSangThapPhan(int so){
        
        String chuoi = new StringBuffer(String.valueOf(so)).reverse().toString();
        
        int tong = 0, i;
        for (i = 0; i < chuoi.length(); i++){
            if (chuoi.charAt(i) == '1')
                tong += (int) Math.pow(2, i);
        }
        return tong;
    }
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Xin nhãy nhập số mún đổi: ");
        int so = scan.nextInt();
        
        System.out.println("Kết quả là: "+doiSangThapPhan(so));
    }
    
}
