/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7_nguyenhoangphutien.Bai7_8;

import java.util.Scanner;

/**
 *
 * @author Asus
 */
public class Bai5_8 {

    /**
     * @param args the command line arguments
     */
    private static void inBangCuuChuong(int tuSo, int denSo){
        
        String chuoi = "";
        int i, j;
        for (i = 1; i <= 9; i++){
            for (j = tuSo ; j <= denSo; j++){
                chuoi += String.format("%d x %d = %d\t", j, i, (j * i));
            }
            System.out.println(chuoi);
            chuoi = "";
        }
    }
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Từ số: ");
        int tuSo = scan.nextInt();
        System.out.println("Đến số: ");
        int denSo = scan.nextInt();
        
        System.out.println("************************************");
        System.out.println("Bảng cửu chương");
        System.out.println("************************************");
        System.out.println("");
        System.out.println("");
        System.out.println("-------------------------------------");
        inBangCuuChuong(tuSo, denSo);
    }
    
}
