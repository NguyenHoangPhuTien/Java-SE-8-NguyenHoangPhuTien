/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7_nguyenhoangphutien.Bai7_9;

import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai6_6 {

    /**
     * @param args the command line arguments
     */
    private static void xuatMang2Chieu(int[][] mang) {

        String chuoi = "";
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                chuoi += mang[i][j] + " ";
            }
            System.out.println(chuoi);
            chuoi = "";
        }

    }

    private static int tinhTongDuongCheoChinh(int[][] mang) {

        int tong = 0;
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if (i == j) {
                    tong += mang[i][j];
                }
            }
        }
        return tong;
    }

    private static int timSoLonNhatTrenDuongCheoChinh(int[][] mang) {

        int soLonNhat = mang[0][0];
        for (int i = 1; i < mang.length; i++) {
            for (int j = 1; j < mang[i].length; j++) {
                if (i == j) {
                    if (mang[i][j] > soLonNhat) {
                        soLonNhat = mang[i][j];
                    }
                }
            }
        }
        return soLonNhat;
    }

    private static int timSoNhoNhatTrenDuongCheoChinh(int[][] mang) {

        int soNhoNhat = mang[0][0];
        for (int i = 1; i < mang.length; i++) {
            for (int j = 1; j < mang[i].length; j++) {
                if (i == j) {
                    if (mang[i][j] < soNhoNhat) {
                        soNhoNhat = mang[i][j];
                    }
                }
            }
        }
        return soNhoNhat;
    }

    private static boolean kiemTraSNT(int so) {

        if (so < 2) {
            return false;
        } else if (so == 2) {
            return true;
        } else {
            int tam = (int) Math.sqrt(so);
            for (int i = 2; i <= tam; i++) {
                if (so % i == 0) {
                    return false;
                }
            }
        }
        return true;
    }

    private static void timSoNguyenTo(int[][] mang) {

        String chuoi = "";
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if (kiemTraSNT(mang[i][j])) {
                    chuoi = String.format("Số %d là số nguyên tố xuất hiện ở dòng %d cột %d", mang[i][j], i, j);
                    System.out.println(chuoi);
                }
            }
        }
    }

    private static void kiemTraDoiXung(int[][] mang) {

        int flag = 1;
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if (mang[i][j] != mang[j][i]) {
                    flag = 0;
                }
                break;
            }
        }
        if (flag == 0) {
            System.out.println("Ma trận không đối xứng");
        } else {
            System.out.println("Ma trận đối xứng");
        }
    }

    private static void kiemTraCotTangDan(int[][] mang, int cot) {
        String chuoi = "ma trận có cột tăng dần";
        for (int i = 0; i < mang.length - 1; i++) {
            if (mang[i][cot] > mang[i + 1][cot]) {
                chuoi = "ma trận không có cột tăng dần";
            }
        }
        System.out.println(chuoi);
    }

    private static void kiemTraCotGiamDan(int[][] mang, int cot) {
        String chuoi = "ma trận có cột giảm dần";
        for (int i = 0; i < mang.length - 1; i++) {
            if (mang[i][cot] < mang[i + 1][cot]) {
                chuoi = "ma trận không có cột giảm dần";
            }
        }
        System.out.println(chuoi);
    }

    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);

        System.out.println("Hãy nhập chiều dài cạnh: ");
        int dong = scan.nextInt();

        if (dong < 3) {
            System.out.println("Đây không phải ma trận hình vuông");
        } else {

            System.out.println("Hãy nhập giá trị phần tử mảng: ");
            int[][] mang = new int[dong][dong];

            for (int i = 0; i < dong; i++) {
                for (int j = 0; j < dong; j++) {
                    System.out.println(String.format("Nhập giá trị của số ở dòng %d côt %d", i, j));
                    mang[i][j] = scan.nextInt();
                }
            }
            System.out.println("Mảng 2 chiều là: ");
            xuatMang2Chieu(mang);
            System.out.println("Tổng đường chéo chính: " + tinhTongDuongCheoChinh(mang));
            System.out.println("Số lớn nhất trên đường chéo chính là: " + timSoLonNhatTrenDuongCheoChinh(mang));
            System.out.println("Số nhỏ nhất trên đường chéo chính là: " + timSoNhoNhatTrenDuongCheoChinh(mang));
            timSoNguyenTo(mang);

            System.out.println("Hãy nhập chiều dài cạnh vuông B: ");
            int dong1 = scan.nextInt();
            if (dong < 3) {
                System.out.println("Đây không phải ma trận hình vuông");
            } else {

                System.out.println("Hãy nhập giá trị phần tử mảng: ");
                int[][] mangB = new int[dong][dong];

                for (int i = 0; i < dong; i++) {
                    for (int j = 0; j < dong; j++) {
                        System.out.println(String.format("Nhập giá trị của số ở dòng %d côt %d", i, j));
                        mangB[i][j] = scan.nextInt();
                    }
                }
                System.out.println("Mảng 2 chiều là: ");
                xuatMang2Chieu(mangB);
                kiemTraDoiXung(mangB);

                int[][] mangC = new int[dong][dong];
                for (int i = 0; i < dong; i++) {
                    for (int j = 0; j < dong; j++) {
                        mangC[i][j] = mang[i][j] + mangB[i][j];
                    }
                }
                System.out.println("Mãng 2 chiều là: ");
                xuatMang2Chieu(mangC);
                System.out.println("Nhập cột cần kiểm tra: ");
                int cot = scan.nextInt();

                kiemTraCotTangDan(mangC, cot);
                kiemTraCotGiamDan(mangC, cot);
            }
        }

    }

}
