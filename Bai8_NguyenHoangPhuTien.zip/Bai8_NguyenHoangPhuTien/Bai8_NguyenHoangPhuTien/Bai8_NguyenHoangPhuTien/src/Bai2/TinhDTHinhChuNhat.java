/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai2;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class TinhDTHinhChuNhat {

    /**
     * @param args the command line arguments
     */
    private static double tinhChuVi(double chieuDai, double chieuRong) {

        if (chieuDai < 0 || chieuRong < 0) {
            System.out.println("Chiều dài và chiều Rộng phải la số dương");
        }
        double chuVi = 0;
        chuVi = (chieuDai + chieuRong) * 2;
        return chuVi;
    }

    private static double tinhDienTich(double chieuDai, double chieuRong) {

        if (chieuDai < 0 || chieuRong < 0) {
            System.out.println("Chiều dài và chiều Rộng phải la số dương");
        }
        double dienTich = 0;
        dienTich = chieuDai * chieuRong;
        return dienTich;
    }

    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        System.out.println("Hãy nhập chiều rộng: ");
        try {
            double chieuRong = scan.nextDouble();
            System.out.println("Hãy nhập chiều dài: ");
            double chieuDai = scan.nextDouble();

            System.out.println(String.format("Chu vi hình chữ nhật là: %.2f", tinhChuVi(chieuDai, chieuRong)));
            System.out.println(String.format("Diện tích hình chữ nhật là: %.2f", tinhDienTich(chieuDai, chieuRong)));
        }catch(InputMismatchException e){
            System.out.println("Định dạng nhập vào không đúng");
        } catch (NumberFormatException e){
            System.out.println("Dữ liệu nhập vào không được để rỗng");
        } catch (ArithmeticException e){
            System.out.println(e.getMessage());
        }

    }

}
