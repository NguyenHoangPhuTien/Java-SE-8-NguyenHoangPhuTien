/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai2;

import java.util.InputMismatchException;
import java.util.Scanner;
import javax.sound.midi.SysexMessage;

/**
 *
 * @author hocvien
 */
public class TinhThucLinh {

    /**
     * @param args the command line arguments
     */
    private static int tinhTienLuong(int sanPham, int tienCong) {

        if (sanPham < 0 || tienCong < 0) {
            throw new ArithmeticException("Sản phẩm và tiền công phải là số dương");
        }
        int tienLuong = 0;
        tienLuong = sanPham * tienCong;
        return tienLuong;
    }

    private static int tinhPhuCap(int soCon) {
        if (soCon < 0) {
            throw new ArithmeticException("Số con phải là số dương");
        }
        int phuCap = 0;
        phuCap = soCon * 200000;
        return phuCap;
    }

    private static int tinhThucLinh(int tienThuong, int tienLuong, int phuCap) {
        if (tienLuong < 0 || tienThuong < 0 || phuCap < 0) {
            throw new ArithmeticException("Tiền thưởng tiền lương phụ cấp phải là số dương");
        }
        int thucLinh = 0;
        thucLinh = tienLuong + tienThuong + phuCap;
        return thucLinh;
    }

    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        System.out.println("Nhập số sản phẩm:");
        try {
            int sanPham = scan.nextInt();
            System.out.println("Nhập tiền công một sản phẩm:");
            int tienCong = scan.nextInt();
            System.out.println("Nhập tiền thưởng:");
            int tienThuong = scan.nextInt();
            System.out.println("Nhập số con:");
            int soCon = scan.nextInt();

            System.out.println("Tiền lương: " + tinhTienLuong(sanPham, tienCong));
            System.out.println("Phụ cấp: " + tinhPhuCap(soCon));
            System.out.println("Thực lĩnh: " + tinhThucLinh(tienThuong, tienThuong, soCon));
        } catch(InputMismatchException e){
            System.out.println("Định dạng nhập vào không đúng");
        } catch (NumberFormatException e){
            System.out.println("Dữ liệu nhập vào không được để rỗng");
        } catch (ArithmeticException e){
            System.out.println(e.getMessage());
        }

    }

}
