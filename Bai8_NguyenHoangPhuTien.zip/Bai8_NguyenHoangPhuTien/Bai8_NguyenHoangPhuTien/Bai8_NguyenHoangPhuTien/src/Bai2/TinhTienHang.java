/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.InputMismatchException;

/**
 *
 * @author hocvien
 */
public class TinhTienHang {

    /**
     * @param args the command line arguments
     */
    private static double tinhTien(int soLuong, double donGia) {

        if (soLuong < 0 || donGia < 0) {
            throw new ArithmeticException("Số lượng đơn giá phải là số dương");
        }
        double tien = 0;
        tien = (donGia + soLuong) / 2;
        return tien;
    }

    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader read = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Nhập số lượng: ");
        try {
            int soLuong = Integer.parseInt(read.readLine());
            System.out.println("Nhập đơn giá:");
            double donGia = Double.parseDouble(read.readLine());

            System.out.println(String.format("Thành tiền là: %.2f", tinhTien(soLuong, donGia)));
        }catch(InputMismatchException e){
            System.out.println("Định dạng nhập vào không đúng");
        } catch (NumberFormatException e){
            System.out.println("Dữ liệu nhập vào không được để rỗng");
        } catch (ArithmeticException e){
            System.out.println(e.getMessage());
        }

    }

}
