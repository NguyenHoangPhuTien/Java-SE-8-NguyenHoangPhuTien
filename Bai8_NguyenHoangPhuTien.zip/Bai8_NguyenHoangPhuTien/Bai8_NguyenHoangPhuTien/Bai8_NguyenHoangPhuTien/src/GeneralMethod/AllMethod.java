package GeneralMethod;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Asus
 */
public class AllMethod {

    /**
     * @param args the command line arguments
     */
    public static String timCapSoChiaHet(int[] mang) {

        if (mang == null) {
            throw new NullPointerException("Mảng đang có giá trị null");
        }

        String chuoi = "";
        String temp = "";
        String temp1 = "";
        for (int i = 0; i < mang.length - 1; i++) {
            for (int j = i + 1; j < mang.length; j++) {
                if (mang[j] == 0) {
                    continue;
                }
                if (mang[i] % mang[j] == 0 || mang[j] % mang[i] == 0) {
                    temp = String.format("%d & %d ", mang[i], mang[j]);
                    temp1 = String.format("%d & %d ", mang[j], mang[i]);
                    if (chuoi.indexOf(temp) < 0 && chuoi.indexOf(temp1) < 0) {
                        chuoi += String.format("%d & %d ", mang[i], mang[j]);
                    }
                }
            }
        }
        return chuoi.trim();
    }

    public static String timCacSoGapDoi(int[] mang) {

        if (mang == null) {
            throw new NullPointerException("Mảng đang có giá trị null");
        }
        String chuoi = "";
        String temp = "";
        String temp1 = "";
        for (int i = 0; i < mang.length - 1; i++) {
            for (int j = i + 1; j < mang.length; j++) {
                if (mang[i] == (mang[j] * 2) || mang[j] == (mang[i] * 2)) {
                    temp = String.format("%d & %d ", mang[i], mang[j]);
                    temp1 = String.format("%d & %d ", mang[j], mang[i]);
                    if (chuoi.indexOf(temp) < 0 && chuoi.indexOf(temp1) < 0) {
                        chuoi += String.format("%d & %d ", mang[i], mang[j]);
                    }
                }
            }
        }
        return chuoi.trim();

    }

    public static String timCacSoTheoDieuKien(int[] mang, int so) {
        if (mang == null) {
            throw new NullPointerException("Mảng đang có giá trị null");
        }
        String chuoi = "";
        String temp = "";
        String temp1 = "";
        for (int i = 0; i < mang.length - 1; i++) {
            for (int j = i + 1; j < mang.length; j++) {
                if (mang[i] + mang[j] == so) {
                    temp = String.format("%d & %d ", mang[i], mang[j]);
                    temp1 = String.format("%d & %d ", mang[j], mang[i]);
                    if (chuoi.indexOf(temp) < 0 && chuoi.indexOf(temp1) < 0) {
                        chuoi += String.format("%d & %d ", mang[i], mang[j]);
                    }
                }
            }
        }
        return chuoi;
    }

    public static int demSoPhanTuChan(int[][] mang) {

        if (mang == null) {
            throw new NullPointerException("Mảng đang có giá trị null");
        }
        int dem = 0;
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if (mang[i][j] % 2 == 0) {
                    dem++;
                }
            }
        }
        return dem;
    }

    public static int demSoPhanTuLe(int[][] mang) {

        if (mang == null) {
            throw new NullPointerException("Mảng đang có giá trị null");
        }
        int dem = 0;
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if (!(mang[i][j] % 2 == 0)) {
                    dem++;
                }
            }
        }
        return dem;
    }

    public static double tinhTrungBinhSoPhanTuLe(int[][] mang) {

        if (mang == null) {
            throw new NullPointerException("Mảng đang có giá trị null");
        }
        double trungBinh = 0;
        int dem = 0;
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if (!(mang[i][j] % 2 == 0)) {
                    trungBinh += mang[i][j];
                    dem++;
                }
            }
        }
        trungBinh = (dem == 0) ? 0 : (trungBinh / dem);
        return trungBinh;
    }

    public static double tinhTrungBinhSoPhanTuChan(int[][] mang) {

        if (mang == null) {
            throw new NullPointerException("Mảng đang có giá trị null");
        }
        int trungBinh = 0;
        int dem = 0;
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if (mang[i][j] % 2 == 0) {
                    trungBinh += mang[i][j];
                    dem++;
                }
            }
        }
        trungBinh = (dem == 0) ? 0 : (trungBinh / dem);
        return trungBinh;
    }

    public static int timPhanTuLonNhat(int[][] mang) {

        if (mang == null) {
            throw new NullPointerException("Mảng đang có giá trị null");
        }

        int soLonNhat = 0;
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if (mang[i][j] > soLonNhat) {
                    soLonNhat = mang[i][j];
                }
            }
        }
        return soLonNhat;
    }

    public static int timPhanTuNhoNhat(int[][] mang) {

        if (mang == null) {
            throw new NullPointerException("Mảng đang có giá trị null");
        }

        int soNhoNhat = mang[0][0];
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if (mang[i][j] < soNhoNhat) {
                    soNhoNhat = mang[i][j];
                }
            }
        }
        return soNhoNhat;
    }

    public static String timViTriPhanTuLonNhat(int[][] mang) {
        if (mang == null) {
            throw new NullPointerException("Mảng đang có giá trị null");
        }

        String chuoi = "";
        int soLonNhat = timPhanTuLonNhat(mang);
        chuoi = timViTriPhanTu(mang, soLonNhat);
        return chuoi.trim();
    }

    public static String timViTriPhanTu(int[][] mang, int so) {

        if (mang == null) {
            System.out.println("Mảng đang có giá trị null");
        }

        String chuoi = "";
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if (mang[i][j] == so) {
                    chuoi += String.format("dòng %d cột %d ", i, j);
                }
            }
        }
        return chuoi.trim();
    }

    public static String timViTriPhanTuNhoNhat(int[][] mang) {

        if (mang == null) {
            System.out.println("Mảng đang có giá trị null");
        }

        int soNhoNhat = timPhanTuNhoNhat(mang);
        String chuoi = timViTriPhanTu(mang, soNhoNhat);

        return chuoi.trim();
    }

    public static int tinhSoLanPhanTuTrungLap(int[][] mang, int phanTu) {

        if (mang == null) {
            throw new NullPointerException("Mảng đang có giá trị null");
        }

        int dem = 0;
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if (mang[i][j] == phanTu) {
                    dem++;
                }
            }
        }
        return dem;
    }
    public static int timSoLanTrungNhieuNhat(int[][] mang){
        
        int dem = 0;
        int tam = 0;
        for(int i = 0; i < mang.length; i++){
            for(int j = 0; j < mang[i].length; j++){
                dem = GeneralMethod.AllMethod.tinhSoLanPhanTuTrungLap(mang,mang[i][j]);
                if(dem > tam)
                    tam = dem;
            }
        }
        return tam;
    }
    public static String timSoCoSoLanTrungLapNhieuNhat(int[][] mang) {

        if (mang == null) {
            throw new NullPointerException("Mảng đang có giá trị null");
        }
        String mangTam = "";
        int soLanTrungNhieuNhat = timSoLanTrungNhieuNhat(mang);
        int dem = 0;
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                dem = tinhSoLanPhanTuTrungLap(mang, mang[i][j]);
                if (dem == soLanTrungNhieuNhat) {
                    if (!mangTam.contains(mang[i][j] + "")) {
                        mangTam += mang[i][j] + " ";
                    }
                }

            }
        }
        return mangTam.trim();
    }

    public static boolean kiemTraPhanTuAm(int[][] mang) {

        if (mang == null) {
            throw new NullPointerException("Mảng đang có giá trị null");
        }
        boolean kq = false;

        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if (mang[i][j] < 0) {
                    kq = true;
                }
            }
        }
        return kq;
    }

    public static int tinhTongDuongCheoChinh(int[][] mang) {

        if (mang == null) {
            throw new NullPointerException("Mảng đang có giá trị null");
        }
        int tong = 0;
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if (i == j) {
                    tong += mang[i][j];
                }
            }
        }
        return tong;
    }

    public static int timSoLonNhatTrenDuongCheoChinh(int[][] mang) {

        if (mang == null) {
            throw new NullPointerException("Mảng đang có giá trị null");
        }
        int soLonNhat = mang[0][0];
        for (int i = 1; i < mang.length; i++) {
            for (int j = 1; j < mang[i].length; j++) {
                if (i == j) {
                    if (mang[i][j] > soLonNhat) {
                        soLonNhat = mang[i][j];
                    }
                }
            }
        }
        return soLonNhat;
    }

    public static int timSoNhoNhatTrenDuongCheoChinh(int[][] mang) {

        if (mang == null) {
            throw new NullPointerException("Mảng đang có giá trị null");
        }
        int soNhoNhat = mang[0][0];
        for (int i = 1; i < mang.length; i++) {
            for (int j = 1; j < mang[i].length; j++) {
                if (i == j) {
                    if (mang[i][j] < soNhoNhat) {
                        soNhoNhat = mang[i][j];
                    }
                }
            }
        }
        return soNhoNhat;
    }

    public static boolean kiemTraSNT(int so) {

        if (so < 0) {
            throw new ArithmeticException("Số phải là số dương");
        }
        if (so < 2) {
            return false;
        } else if (so == 2) {
            return true;
        } else {
            int tam = (int) Math.sqrt(so);
            for (int i = 2; i <= tam; i++) {
                if (so % i == 0) {
                    return false;
                }
            }
        }
        return true;
    }

    public static String timSoNguyenTo(int[][] mang) {

        if (mang == null) {
            throw new NullPointerException("Mảng đang có giá trị null");
        }
        String chuoi = "";
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if (kiemTraSNT(mang[i][j])) {
                    if (chuoi.indexOf(mang[i][j] + "") < 0) {
                        chuoi += mang[i][j] + " ";
                    }
                }
            }
        }
        chuoi = chuoi.trim();
        return chuoi;
    }

    public static boolean kiemTraDoiXung(int[][] mang) {

        if (mang == null) {
            throw new NullPointerException("Mảng đang có giá trị null");
        }
        boolean kq = true;
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if (mang[i][j] != mang[j][i]) {
                    kq = false;
                    break;
                }

            }
        }
        return kq;
    }

    public static boolean kiemTraCotTangDan(int[][] mang, int cot) {

        if (mang == null) {
            throw new NullPointerException("Mảng đang có giá trị null");
        }

        int cotTam = mang[0].length;
        if (cot < 0) {
            throw new ArithmeticException("Cột phải là số dương");
        }
        if (cot > cotTam) {
            throw new ArithmeticException("Cột kiểm tra đang vượt quá số cột trong mảng");
        }
        boolean kq = true;
        for (int i = 0; i < mang.length - 1; i++) {
            if (mang[i][cot] > mang[i + 1][cot]) {
                kq = false;
                break;
            }
        }
        return kq;
    }

    public static boolean kiemTraCotGiamDan(int[][] mang, int cot) {
        if (mang == null) {
            throw new NullPointerException("Mảng đang có giá trị null");
        }

        int cotTam = mang[0].length;
        if (cot < 0) {
            throw new ArithmeticException("Cột phải là số dương");
        }
        if (cot > cotTam) {
            throw new ArithmeticException("Cột kiểm tra đang vượt quá số cột trong mảng");
        }
        boolean kq = true;
        for (int i = 0; i < mang.length - 1; i++) {
            if (mang[i][cot] < mang[i + 1][cot]) {
                kq = false;
                break;
            }
        }
        return kq;
    }

    public static boolean kiemTraSoCoTrongMang(int so, int[] mang) {

        if (mang == null) {
            throw new NullPointerException("Mảng đang có giá trị null");
        }
        boolean kq = false;
        for (int i = 0; i < mang.length; i++) {
            if (mang[i] == so) {
                kq = true;
                break;
            }

        }
        return kq;
    }

    public static boolean kiemTraLonNhat(int so, int[] mang) {

        if (mang == null) {
            throw new NullPointerException("Mảng đang có giá trị null");
        }
        boolean kq = true;
        for (int value : mang) {
            if (value > so) {
                kq = false;
                break;
            }
        }
        return kq;
    }

    public static String timSoLonHon(int so, int[] mang) {

        if (mang == null) {
            throw new NullPointerException("Mảng đang có giá trị null");
        }
        String chuoi = "";
        for (int value : mang) {
            if (value > so) {
                chuoi += value + " ";
            }
        }
        return chuoi.trim();
    }

    public static String layCan(int nam) {
        if (nam < 0) {
            throw new ArithmeticException("Năm phải lớn hơn hoặc bằng 0");
        }
        int tinh = nam % 10;
        String can = "";
        switch (tinh) {
            case 0:
                can = "Canh";
                break;
            case 1:
                can = "Tân";
                break;
            case 2:
                can = "Nhâm";
                break;
            case 3:
                can = "Quý";
                break;
            case 4:
                can = "Giáp";
                break;
            case 5:
                can = "Ất";
                break;
            case 6:
                can = "Bính";
                break;
            case 7:
                can = "Đinh";
                break;
            case 8:
                can = "Mậu";
                break;
            case 9:
                can = "Kỳ";
                break;

        }
        return can;
    }

    public static String tinhChi(int nam) {
        if (nam < 0) {
            throw new ArithmeticException("Năm phải lớn hơn hoặc bằng 0");
        }
        int tinh = nam % 12;
        String chi = "";
        switch (tinh) {
            case 0:
                chi = "Thân";
                break;
            case 1:
                chi = "Dậu";
                break;
            case 2:
                chi = "Tuất";
                break;
            case 3:
                chi = "Hợi";
                break;
            case 4:
                chi = "Tí";
                break;
            case 5:
                chi = "Sữu";
                break;
            case 6:
                chi = "Dần";
                break;
            case 7:
                chi = "Mão";
                break;
            case 8:
                chi = "Thìn";
                break;
            case 9:
                chi = "Tị";
                break;
            case 10:
                chi = "Ngọ";
                break;
            case 11:
                chi = "Mùi";
                break;
        }
        return chi;
    }

    public static String doiSangNhiPhan(int so) {

        String chuoi = "";
        while (so != 0) {
            String temp = String.valueOf(so % 2);
            chuoi += temp;
            so = so / 2;
        }
        chuoi = new StringBuffer(chuoi).reverse().toString();
        return chuoi.trim();
    }

    public static String doiSangNhiPhan_Advance(int so) {

        String chuoi = Integer.toBinaryString(so);
        return chuoi;
    }

    public static int doiSangThapPhan(int so) {

        int kq = Integer.parseInt(String.valueOf(so), 2);
        return kq;
    }

    public static int tinhGiaiThuaBac2(int so) {

        if (so < 0) {
            throw new ArithmeticException(" Số cần tính phải là số dương");
        }
        String chuoi = so + "!! = ";
        int i, tich = 1;
        if (so == 0) {
            chuoi = "0!! = 1 ";
        } else {
            if (so % 2 == 0) {
                for (i = 1; i <= so; i++) {
                    if (i % 2 == 0) {
                        chuoi += i + " x ";
                        tich *= i;
                    }
                }
            } else {
                for (i = 1; i <= so; i++) {
                    if (i % 2 != 0) {
                        chuoi += i + " x ";
                        tich *= i;
                    }
                }
            }

        }
        return tich;
    }

    public static int tinhGiaiThuaBac1(int so) {
        if (so < 0) {
            throw new ArithmeticException(" Số cần tính phải là số dương");
        }
        String chuoi = so + "! = ";
        int i, tich = 1;
        if (so == 0) {
            chuoi = "0! = 1";
        } else {
            for (i = 1; i <= so; i++) {
                if (i == 1) {
                    chuoi += "1";
                } else {
                    chuoi += " x " + i;
                }
                tich *= i;
            }
        }
        return tich;
    }

    public static int tinhTong(int[] mang) {

        if (mang == null) {
            throw new NullPointerException("Mảng đang có giá trị null");
        }
        int tong = 0;
        for (int value : mang) {
            tong += value;
        }

        return tong;
    }

    public static boolean kiemTraTangDan(int[] mang) {

        if (mang == null) {
            throw new NullPointerException("Mảng đang có giá trị null");
        }
        boolean kq = true;
        for (int i = 0; i < mang.length - 1; i++) {
            if (mang[i] > mang[i + 1]) {
                kq = false;
                break;
            }
        }
        return kq;
    }

    public static boolean kiemTraGiamDan(int[] mang) {

        boolean kq = true;
        if (mang == null) {
            throw new NullPointerException("Mảng đang có giá trị null");
        }
        for (int i = 0; i < mang.length - 1; i++) {
            if (mang[i] < mang[i + 1]) {
                kq = false;
                break;
            }
        }
        return kq;
    }

    public static int timSoDauTienChiaHet(int so, int[] mang) {

        if (mang == null) {
            throw new NullPointerException("Mảng đang có giá trị null");
        }
        for (int value : mang) {
            if (value % 10 == so) {
                return value;

            }
        }
        return 0;
    }

    public static String xuatMang1Chieu(int[] mang) {

        if (mang == null) {
            throw new NullPointerException("Mảng đang có giá trị null");
        }
        String chuoi = "";
        for (int value : mang) {
            chuoi += String.format(" %d ", value);
        }

        return chuoi;
    }

}
