/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8_nguyenhoangphutien.Bai8_1;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai4_2 {

    /**
     * @param args the command line arguments
     */
    private static double tinhTien(int xe, double soKM){
        
        if(xe != 4 && xe != 7){
            throw new ArithmeticException("Chỉ được nhập xe 4 hay 7 chỗ");
        }
        if(soKM < 0){
            throw new ArithmeticException("Số km phải là số không âm");
        }
        double soTien = 0;
            if (xe == 4) {
                if (soKM <= 0.8) {
                    soTien = 11000 * soKM;
                } else if (soKM > 30) {
                    soTien = 11000 + (30 - 0.8) * 124000 + (soKM - 30) * 12400;
                } else {
                    soTien = 16500 * (soKM - 0.8) + 11000;
                }
            } else if (xe == 7) {
                if (soKM <= 0.8) {
                    soTien = 11000 * soKM;
                } else if (soKM >= 31) {
                    soTien = 11000 + (30 - 0.8) * 124000 + (soKM - 30) * 14400;
                } else {
                    soTien = 17000 * (soKM - 0.8) + 11000;
                }
            }
        return soTien;
    }
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        System.out.println("Nhập loại xe ( 4 hoặc 7 chỗ):");
        try {
            int xe = scan.nextInt();

            System.out.println("Nhập số km:");
            double soKM = scan.nextDouble();
            
            System.out.println("Thành tiền: " + tinhTien(xe, soKM));
        } catch(InputMismatchException e){
            System.out.println("Định dạng nhập vào không đúng");
        } catch (NumberFormatException e){
            System.out.println("Dữ liệu nhập vào không được để rỗng");
        } catch (ArithmeticException e){
            System.out.println(e.getMessage());
        }
    }

}
