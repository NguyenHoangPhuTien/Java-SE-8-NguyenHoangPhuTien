/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8_nguyenhoangphutien.Bai8_1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.InputMismatchException;

/**
 *
 * @author Asus
 */
public class Bai4_5_Advance {

    private static int soNgayTrongThang(int thang, int nam) {
        if (thang < 1 || thang > 12) {
            throw new ArithmeticException("Tháng chỉ có từ 1 đến 12");
        }
        if (nam < 0) {
            throw new ArithmeticException("Năm phải là số nguyên dương");
        }
        int ngay = 0;
        switch (thang) {
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
                ngay = 31;
                break;
            case 2:
                if (((nam % 4 == 0) && !(nam % 100 == 0)) || (nam % 400 == 0)) {
                    ngay = 29;
                } else {
                    ngay = 28;
                }
                break;

            case 4:
            case 6:
            case 9:
            case 11:
                ngay = 30;
                break;
        }
        return ngay;
    }

    private static void layNgayTrongThang(int thang, int nam, int ngay) {

        if (thang < 1 || thang > 12) {
            throw new ArithmeticException("Tháng chỉ có từ 1 đến 12");
        }
        if (nam < 0) {
            throw new ArithmeticException("Năm phải là số nguyên dương");
        }
        if (ngay < 1 || ngay > 31) {
            throw new ArithmeticException("Ngày chỉ có từ 1 đến 31");
        }
        if (ngay == soNgayTrongThang(thang, nam)) {
            if (thang == 12) {
                System.out.println("Ngay ke tiep la ngay 1 thang 1 cua nam " + (nam + 1));

            } else {
                System.out.println("Ngay ke tiep la ngay 1 thang " + (thang + 1) + " cua nam " + nam);

            }
            System.out.println("Ngay hom truoc la ngay " + (ngay - 1) + " cua thang " + thang);

        } else if (ngay == 1) {
            if (thang == 1) {
                System.out.println("Ngay hom truoc la 31 thang 12 cua nam " + (nam - 1));
            } else {
                System.out.println("Ngay hom truoc la ngay " + soNgayTrongThang(thang - 1, nam) + " cua thang " + (thang - 1) + " cua nam " + nam);
            }
            System.out.println("ngay hom sau la ngay 2 thang " + thang + " cua nam " + nam);
        } else {
            System.out.println("Ngay hom truoc la ngay " + (ngay - 1) + " cua thang " + thang + " cua nam " + nam);
            System.out.println("Ngay hom sau la ngay " + (ngay + 1) + " cua thang " + thang + " cua nam " + nam);
        }

    }

    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        //Kiá»ƒm tra tÃ­nh há»£p lá»‡ cá»§a ngÃ y thÃ¡ng
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Nhap vao ngay: ");
        try {
            int ngay = Integer.parseInt(input.readLine());
            System.out.println("Nhap vao thang: ");
            int thang = Integer.parseInt(input.readLine());
            System.out.println("Nhap vao nam: ");
            int nam = Integer.parseInt(input.readLine());

            System.out.println("so ngay trong thang: " + soNgayTrongThang(thang, nam));
            layNgayTrongThang(thang, nam, ngay);
        }catch(InputMismatchException e){
            System.out.println("Định dạng nhập vào không đúng");
        } catch (NumberFormatException e){
            System.out.println("Dữ liệu nhập vào không được để rỗng");
        } catch (ArithmeticException e){
            System.out.println(e.getMessage());
        }
    }

}
