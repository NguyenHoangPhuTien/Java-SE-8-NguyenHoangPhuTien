/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8_nguyenhoangphutien.Bai8_1;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author Asus
 */
public class Bai4_7 {

    /**
     * @param args the command line arguments
     */
    static final int tienGiamTru = 9000000 * 12;
    static final int tienGiamTruPhuThuoc = 3600000 * 12;
    static final int thueBac1 = 5;
    static final int thueBac2 = 10;
    static final int thueBac3 = 15;
    static final int thueBac4 = 20;
    static final int thueBac5 = 25;
    static final int thueBac6 = 30;
    static final int thueBac7 = 35;
    static final double mucLuong1 = 60000000;
    static final double mucLuong2 = 96000000;
    static final double mucLuong3 = 168000000;
    static final double mucLuong4 = 240000000;
    static final double mucLuong5 = 336000000;

    private static double tinhThue(double tienChiuThue) {
        if(tienChiuThue < 0)
            throw new ArithmeticException("Tiền chịu thuế phải là số dương");
        double tien = 0;
        if (tienChiuThue <= 60000000) {
            tien = tienChiuThue / 100 * thueBac1;
        } else if (tienChiuThue <= 120000000) {
            tien = (tienChiuThue - 60000000) / 100 * thueBac2 + mucLuong1 / 100 * thueBac1;
        } else if (tienChiuThue <= 216000000) {
            tien = (tienChiuThue - 120000000) / 100 * thueBac3 + mucLuong1 / 100 * thueBac2 + mucLuong1 / 100 * thueBac1;
        } else if (tienChiuThue <= 384000000) {
            tien = (tienChiuThue - 216000000) / 100 * thueBac4 + mucLuong2 / 100 * thueBac3 + mucLuong1 / 100 * thueBac2 + mucLuong1 / 100 * thueBac1;
        } else if (tienChiuThue <= 624000000) {
            tien = (tienChiuThue - 384000000) / 100 * thueBac5 + mucLuong3 / 100 * thueBac4 + mucLuong2 / 100 * thueBac3 + mucLuong1 / 100 * thueBac2 + mucLuong1 / 100 * thueBac1;
        } else if (tienChiuThue <= 960000000) {
            tien = (tienChiuThue - 624000000) / 100 * thueBac6 + mucLuong4 / 100 * thueBac5 + mucLuong3 / 100 * thueBac4 + mucLuong2 / 100 * thueBac3 + mucLuong1 / 100 * thueBac2 + mucLuong1 / 100 * thueBac1;
        } else {
            tien = (tienChiuThue - 960000000) / 100 * thueBac7 + mucLuong5 / 100 * thueBac6 + mucLuong4 / 100 * thueBac5 + mucLuong3 / 100 * thueBac4 + mucLuong2 / 100 * thueBac3 + mucLuong1 / 100 * thueBac2 + mucLuong1 / 100 * thueBac1;
        }
        return tien;
    }

    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);

        System.out.println("Nhập mã số thuế: ");
        try {
            String maSoThue = scan.nextLine();
            System.out.println("Nhập họ tên: ");
            String hoTen = scan.nextLine();
            System.out.println("Nhập tổng thu nhập: ");
            double thuNhap = scan.nextDouble();
            System.out.println("Số người phụ thuộc: ");
            int nguoiPhuThuoc = scan.nextInt();

            double giamTru = tienGiamTru + tienGiamTruPhuThuoc * nguoiPhuThuoc;
            double tienChiuThue = thuNhap - giamTru;

            System.out.println("*******************************************");
            System.out.println("Tính thuế thu nhập cá nhân");
            System.out.println("*******************************************");
            System.out.println("");
            System.out.println("");
            System.out.println("Mã số thuế: " + maSoThue);
            System.out.println("Họ tên đối tượng nộp thuế: " + hoTen);
            System.out.println("Tổng thu nhập trong năm: " + thuNhap);
            System.out.println("Số người phụ thuộc: " + nguoiPhuThuoc);

            System.out.println("---Kết quả----------------------------------");
            System.out.println("Số tiền giảm trừ: " + giamTru);
            System.out.println("Số tiền chịu thuế: " + tienChiuThue);
            System.out.println("Tiển thuế phải nộp: " + tinhThue(tienChiuThue));
        } catch(InputMismatchException e){
            System.out.println("Định dạng nhập vào không đúng");
        } catch (NumberFormatException e){
            System.out.println("Dữ liệu nhập vào không được để rỗng");
        } catch (ArithmeticException e){
            System.out.println(e.getMessage());
        }
    }

}
