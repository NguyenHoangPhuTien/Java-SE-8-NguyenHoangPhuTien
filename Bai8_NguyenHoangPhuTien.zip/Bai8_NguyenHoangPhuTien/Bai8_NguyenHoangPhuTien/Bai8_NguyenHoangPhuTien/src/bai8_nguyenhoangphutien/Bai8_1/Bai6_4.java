/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8_nguyenhoangphutien.Bai8_1;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai6_4 {

    /**
     * @param args the command line arguments
     */
    public static String xuatMang(int[] mang) {

        if (mang == null) {
            throw new NullPointerException("Mảng đang có giá trị null");
        }
        String chuoi = "";
        for (int value : mang) {
            chuoi += String.format(" %d ", value);
        }

        return chuoi;
    }

    public static String timCapSoChiaHet(int[] mang) {

        if (mang == null) {
            throw new NullPointerException("Mảng đang có giá trị null");
        }
        
        String chuoi = "";
        String temp = "";
        String temp1 = "";
        for (int i = 0; i < mang.length - 1; i++) {
            for (int j = i + 1; j < mang.length; j++) {
                if(mang[j] == 0)
                    continue;
                if (mang[i] % mang[j] == 0 || mang[j] % mang[i] == 0) {
                    temp = String.format("%d & %d ", mang[i], mang[j]);
                    temp1 = String.format("%d & %d ", mang[j], mang[i]);
                    if(chuoi.indexOf(temp) < 0 && chuoi.indexOf(temp1) < 0)
                        chuoi += String.format("%d & %d ", mang[i], mang[j]);
                }
            }
        }
        return chuoi;
    }

    public static String timCacSoGapDoi(int[] mang) {

        if (mang == null) {
            throw new NullPointerException("Mảng đang có giá trị null");
        }
        String chuoi = "";
        String temp = "";
        String temp1 = "";
        for (int i = 0; i < mang.length - 1; i++) {
            for (int j = i + 1; j < mang.length; j++) {
                if (mang[i] == (mang[j] * 2) || mang[j] == (mang[i] * 2)) {
                    temp = String.format("%d & %d ", mang[i], mang[j]);
                    temp1 = String.format("%d & %d ", mang[j], mang[i]);
                    if(chuoi.indexOf(temp) < 0 && chuoi.indexOf(temp1) < 0)
                        chuoi += String.format("%d & %d ", mang[i], mang[j]);
                }
            }
        }
        return chuoi;

    }

   public static String timCacSoTheoDieuKien(int[] mang, int so) {
        if (mang == null) {
            throw new NullPointerException("Mảng đang có giá trị null");
        }
        String chuoi = "";
        String temp = "";
        String temp1 = "";
        for (int i = 0; i < mang.length - 1; i++) {
            for (int j = i + 1; j < mang.length; j++) {
                if (mang[i] + mang[j] == so) {
                    temp = String.format("%d & %d ", mang[i], mang[j]);
                    temp1 = String.format("%d & %d ", mang[j], mang[i]);
                    if(chuoi.indexOf(temp) < 0 && chuoi.indexOf(temp1) < 0)
                        chuoi += String.format("%d & %d ", mang[i], mang[j]);
                }
            }
        }
        return chuoi;
    }

    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);

        try {
            System.out.println("Hãy nhập chiều dài mảng: ");
            int n = scan.nextInt();

            System.out.println("Hãy nhập số cần tính: ");
            int so = scan.nextInt();

            System.out.println("Hãy nhập giá trị phần tử mảng: ");
            int[] mang = new int[n];

            for (int i = 0; i < n; i++) {
                mang[i] = scan.nextInt();
            }
            System.out.println("Mảng là: " + xuatMang(mang));

            if (timCapSoChiaHet(mang).equals("")) {
                System.out.println("Không có cặp số nào chia hết cho nhau");
            } else {
                System.out.println("Các cặp số chia hết cho nhau : " + timCapSoChiaHet(mang));
            }

            if (timCacSoGapDoi(mang).equals("")) {
                System.out.println("Không có cặp số nào gấp đôi nhau");
            } else {
                System.out.println("Các cặp số gấp đôi nhau : " + timCacSoGapDoi(mang));
            }

            if (timCacSoTheoDieuKien(mang, so).equals("")) {
                System.out.println("Không có cặp số nào thỏa điều kiện có tổng = " + so);
            } else {
                System.out.println("Các cặp số có tổng = " + so + " là: " + timCacSoTheoDieuKien(mang, so));
            }
        } catch (InputMismatchException e) {
            System.out.println("Đinh dạng nhập vào không đúng");
        } catch (NullPointerException e){
            System.out.println(e.getMessage());
        } catch (NumberFormatException e){
            System.out.println("Dữ liệu nhập vào không được để rỗng");
        }

    }

}
