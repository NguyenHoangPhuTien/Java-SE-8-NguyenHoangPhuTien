/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8_nguyenhoangphutien.Bai8_1;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai7_1 {

    /**
     * @param args the command line arguments
     */
    
    private static float tinhToan(float x , int n){
        int i;
        float s = 1;
        for(i = 1;i <= n;i++){
            s *= (Math.pow(x, 2) +1);
        }
        return s;
    }
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        
        try {
            System.out.println("Nhập n: ");
            int n = scan.nextInt();
            System.out.println("Nhập x: ");
            float x = scan.nextFloat();
            System.out.println("Kết quả của S=(x^2 + 1)^n = "+tinhToan(x, n));
        } catch (InputMismatchException e) {
            System.out.println("Nhập không đúng định dạng");
        }
       
        
    }
    
}
