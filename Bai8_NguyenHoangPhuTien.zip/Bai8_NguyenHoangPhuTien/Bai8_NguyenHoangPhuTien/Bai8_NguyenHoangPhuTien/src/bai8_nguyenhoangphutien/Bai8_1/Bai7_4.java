/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8_nguyenhoangphutien.Bai8_1;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author Asus
 */
public class Bai7_4 {

    /**
     * @param args the command line arguments
     */
    private static String layCan(int nam) {
        if(nam < 0){
            throw new ArithmeticException("Năm phải lớn hơn hoặc bằng 0");
        }
        int tinh = nam % 10;
        String can = "";
        switch (tinh) {
            case 0:
                can = "Canh";
                break;
            case 1:
                can = "Tân";
                break;
            case 2:
                can = "Nhâm";
                break;
            case 3:
                can = "Quý";
                break;
            case 4:
                can = "Giáp";
                break;
            case 5:
                can = "Ất";
                break;
            case 6:
                can = "Bính";
                break;
            case 7:
                can = "Đinh";
                break;
            case 8:
                can = "Mậu";
                break;
            case 9:
                can = "Kỳ";
                break;

        }
        return can;
    }

    private static String tinhChi(int nam) {
         if(nam < 0){
            throw new ArithmeticException("Năm phải lớn hơn hoặc bằng 0");
        }
        int tinh = nam % 12;
        String chi = "";
        switch (tinh) {
            case 0:
                chi = "Thân";
                break;
            case 1:
                chi = "Dậu";
                break;
            case 2:
                chi = "Tuất";
                break;
            case 3:
                chi = "Hợi";
                break;
            case 4:
                chi = "Tí";
                break;
            case 5:
                chi = "Sữu";
                break;
            case 6:
                chi = "Dần";
                break;
            case 7:
                chi = "Mão";
                break;
            case 8:
                chi = "Thìn";
                break;
            case 9:
                chi = "Tị";
                break;
            case 10:
                chi = "Ngọ";
                break;
            case 11:
                chi = "Mùi";
                break;
        }
        return chi;
    }

    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);

        System.out.println("Xin hãy nhập năm: ");
        try {
            int nam = scan.nextInt();

            System.out.println("Năm âm lich là: " + layCan(nam) + " " + tinhChi(nam));
        } catch (InputMismatchException e) {
            System.out.println("Định dạng nhập vào không đúng");
        } catch(ArithmeticException e){
            System.out.println(e.getMessage());
        }

    }

}
