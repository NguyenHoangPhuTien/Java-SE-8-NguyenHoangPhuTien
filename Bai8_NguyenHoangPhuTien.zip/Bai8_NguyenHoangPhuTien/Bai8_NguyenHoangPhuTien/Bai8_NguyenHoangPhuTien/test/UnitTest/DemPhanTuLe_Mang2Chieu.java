/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UnitTest;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Asus
 */
public class DemPhanTuLe_Mang2Chieu {

    public DemPhanTuLe_Mang2Chieu() {
    }

    @Test
    public void test1() {

        int[][] mang = {{4, 2, 2}, {2, 2, 2}};

        int ac = GeneralMethod.AllMethod.demSoPhanTuLe(mang);
        int ex = 0;
        assertEquals(ex, ac);
    }

    @Test
    public void test2() {

        int[][] mang = {{1, 2, 4}, {2, 2, 2}};

        int ac = GeneralMethod.AllMethod.demSoPhanTuLe(mang);
        int ex = 1;
        assertEquals(ex, ac);
    }

    @Test
    public void test3() {

        int[][] mang = {{2, 2, 3}, {2, 2, 3}};

        int ac = GeneralMethod.AllMethod.demSoPhanTuLe(mang);
        int ex = 2;
        assertEquals(ex, ac);
    }

    @Test
    public void test4() {

        int[][] mang = {{3, 3, 4}, {1, 2, 6}};

        int ac = GeneralMethod.AllMethod.demSoPhanTuLe(mang);
        int ex = 3;
        assertEquals(ex, ac);
    }

    @Test
    public void test5() {

        int[][] mang = {{1, 1, 1}, {1, 1, 1}};

        int ac = GeneralMethod.AllMethod.demSoPhanTuLe(mang);
        int ex = 6;
        assertEquals(ex, ac);
    }

    @Test
    public void test6() {

        int[][] mang = {{1, 2, 3}, {1, 2, 3}};

        int ac = GeneralMethod.AllMethod.demSoPhanTuLe(mang);
        int ex = 0;
        assertEquals(ex, ac);
    }

    @Test
    public void test7() {

        int[][] mang = {{1, 2, 4}, {1, 2, 3}};

        int ac = GeneralMethod.AllMethod.demSoPhanTuLe(mang);
        int ex = 1;
        assertEquals(ex, ac);
    }

    @Test
    public void test8() {

        int[][] mang = {{2, 2, 3}, {2, 2, 3}};

        int ac = GeneralMethod.AllMethod.demSoPhanTuLe(mang);
        int ex = 3;
        assertEquals(ex, ac);
    }

    @Test
    public void test9() {

        int[][] mang = {{2, 2, 4}, {2, 2, 6}};

        int ac = GeneralMethod.AllMethod.demSoPhanTuLe(mang);
        int ex = 6;
        assertEquals(ex, ac);
    }

    @Test
    public void test10() {

        int[][] mang = {{1, 1, 3}, {1, 1, 1}};

        int ac = GeneralMethod.AllMethod.demSoPhanTuLe(mang);
        int ex = 7;
        assertEquals(ex, ac);
    }
}
