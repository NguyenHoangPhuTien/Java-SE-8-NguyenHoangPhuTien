/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UnitTest;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Asus
 */
public class DoiSangNhiPhan {

    public DoiSangNhiPhan() {
    }

    @Test
    public void test1() {

        String ac = GeneralMethod.AllMethod.doiSangNhiPhan_Advance(0);
        String ex = "0";
        assertEquals(ex, ac);
    }

    @Test
    public void test2() {

        String ac = GeneralMethod.AllMethod.doiSangNhiPhan_Advance(1);
        String ex = "1";
        assertEquals(ex, ac);
    }

    @Test
    public void test3() {

        String ac = GeneralMethod.AllMethod.doiSangNhiPhan_Advance(10);
        String ex = "1010";
        assertEquals(ex, ac);
    }

    @Test
    public void test4() {

        String ac = GeneralMethod.AllMethod.doiSangNhiPhan_Advance(2);
        String ex = "10";
        assertEquals(ex, ac);
    }

    @Test
    public void test5() {

        String ac = GeneralMethod.AllMethod.doiSangNhiPhan_Advance(20);
        String ex = "10100";
        assertEquals(ex, ac);
    }

    @Test
    public void test6() {

        String ac = GeneralMethod.AllMethod.doiSangNhiPhan_Advance(0);
        String ex = "1";
        assertEquals(ex, ac);
    }

    @Test
    public void test7() {

        String ac = GeneralMethod.AllMethod.doiSangNhiPhan_Advance(1);
        String ex = "100";
        assertEquals(ex, ac);
    }

    @Test
    public void test8() {

        String ac = GeneralMethod.AllMethod.doiSangNhiPhan_Advance(10);
        String ex = "1110";
        assertEquals(ex, ac);
    }

    @Test
    public void test9() {

        String ac = GeneralMethod.AllMethod.doiSangNhiPhan_Advance(2);
        String ex = "100";
        assertEquals(ex, ac);
    }

    @Test
    public void test10() {

        String ac = GeneralMethod.AllMethod.doiSangNhiPhan_Advance(20);
        String ex = "1111";
        assertEquals(ex, ac);
    }
}
