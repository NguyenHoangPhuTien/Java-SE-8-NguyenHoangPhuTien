/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UnitTest;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Asus
 */
public class DoiSangThapPhan {
    
    public DoiSangThapPhan() {
    }

    @Test
    public void test1(){
        
        int ac = GeneralMethod.AllMethod.doiSangThapPhan(0);
        int ex = 0;
        assertEquals(ex, ac);
    }
    
   @Test
    public void test2(){
        
        int ac = GeneralMethod.AllMethod.doiSangThapPhan(1);
        int ex = 1;
        assertEquals(ex, ac);
    }
    
    @Test
    public void test3(){
        
        int ac = GeneralMethod.AllMethod.doiSangThapPhan(1010);
        int ex = 10;
        assertEquals(ex, ac);
    }
    
    @Test
    public void test4(){
        
        int ac = GeneralMethod.AllMethod.doiSangThapPhan(10);
        int ex = 2;
        assertEquals(ex, ac);
    }
    
    @Test
    public void test5(){
        
        int ac = GeneralMethod.AllMethod.doiSangThapPhan(1011);
        int ex = 11;
        assertEquals(ex, ac);
    }
    
    @Test
    public void test6(){
        
        int ac = GeneralMethod.AllMethod.doiSangThapPhan(0);
        int ex = 1;
        assertEquals(ex, ac);
    }
    
    @Test
    public void test7(){
        
        int ac = GeneralMethod.AllMethod.doiSangThapPhan(1);
        int ex = 0;
        assertEquals(ex, ac);
    }
    
    @Test
    public void test8(){
        
        int ac = GeneralMethod.AllMethod.doiSangThapPhan(10);
        int ex = 3;
        assertEquals(ex, ac);
    }
    
    @Test
    public void test9(){
        
        int ac = GeneralMethod.AllMethod.doiSangThapPhan(1010);
        int ex = 11;
        assertEquals(ex, ac);
    }
    
    @Test
    public void test10(){
        
        int ac = GeneralMethod.AllMethod.doiSangThapPhan(1001);
        int ex = 12;
        assertEquals(ex, ac);
    }
}
