/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UnitTest;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Asus
 */
public class KiemTraCotGiamDan_M2C {
    
    public KiemTraCotGiamDan_M2C() {
    }

    @Test
    public void test1() {

        int[][] mang = {{4,2,2}, {2,2,2} ,{1,2,3}};
        boolean ac = GeneralMethod.AllMethod.kiemTraCotGiamDan(mang, 0);

        assertTrue(ac);
    }
    
    @Test
    public void test2() {

        int[][] mang = {{3,2,2}, {2,2,2} ,{1,1,3}};
        boolean ac = GeneralMethod.AllMethod.kiemTraCotGiamDan(mang, 1);

        assertTrue(ac);
    }
    
    @Test
    public void test3() {

        int[][] mang = {{6,3,3}, {2,2,3} ,{1,2,2}};
        boolean ac = GeneralMethod.AllMethod.kiemTraCotGiamDan(mang, 2);

        assertTrue(ac);
    }
    
    @Test
    public void test4() {

        int[][] mang = {{7,2,2}, {4,2,2} ,{3,2,3}};
        boolean ac = GeneralMethod.AllMethod.kiemTraCotGiamDan(mang, 0);

        assertTrue(ac);
    }
    
    @Test
    public void test5() {

        int[][] mang = {{2,2,2}, {2,2,2} ,{1,2,3}};
        boolean ac = GeneralMethod.AllMethod.kiemTraCotGiamDan(mang, 0);

        assertTrue(ac);
    }
    
    @Test
    public void test6() {

        int[][] mang = {{1,2,2}, {2,2,2} ,{1,2,3}};
        boolean ac = GeneralMethod.AllMethod.kiemTraCotGiamDan(mang, 0);

        assertTrue(ac);
    }
    
    @Test
    public void test7() {

        int[][] mang = {{4,2,2}, {2,2,2} ,{1,3,3}};
        boolean ac = GeneralMethod.AllMethod.kiemTraCotGiamDan(mang, 1);

        assertTrue(ac);
    }
    
    @Test
    public void test8() {

        int[][] mang = {{4,2,2}, {2,2,1} ,{1,2,3}};
        boolean ac = GeneralMethod.AllMethod.kiemTraCotGiamDan(mang, 2);

        assertTrue(ac);
    }
    
    @Test
    public void test9() {

        int[][] mang = {{4,2,2}, {2,2,2} ,{1,2,3}};
        boolean ac = GeneralMethod.AllMethod.kiemTraCotGiamDan(mang, 2);

        assertTrue(ac);
    }
    
    @Test
    public void test10() {

        int[][] mang = {{4,2,2}, {5,2,2} ,{1,2,3}};
        boolean ac = GeneralMethod.AllMethod.kiemTraCotGiamDan(mang, 0);

        assertTrue(ac);
    }
}
