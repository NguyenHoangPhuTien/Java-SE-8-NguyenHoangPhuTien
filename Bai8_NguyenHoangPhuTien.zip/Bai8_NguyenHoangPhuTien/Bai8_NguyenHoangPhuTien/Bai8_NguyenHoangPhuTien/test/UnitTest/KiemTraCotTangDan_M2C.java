/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UnitTest;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Asus
 */
public class KiemTraCotTangDan_M2C {

    public KiemTraCotTangDan_M2C() {
    }

    @Test
    public void test1() {

        int[][] mang = {{1, 2, 2}, {2, 2, 2}, {2, 2, 3}};
        boolean ac = GeneralMethod.AllMethod.kiemTraCotTangDan(mang, 0);

        assertTrue(ac);
    }

    @Test
    public void test2() {

        int[][] mang = {{3, 2, 2}, {2, 2, 2}, {1, 3, 3}};
        boolean ac = GeneralMethod.AllMethod.kiemTraCotTangDan(mang, 1);

        assertTrue(ac);
    }

    @Test
    public void test3() {

        int[][] mang = {{6, 3, 2}, {2, 2, 2}, {1, 2, 3}};
        boolean ac = GeneralMethod.AllMethod.kiemTraCotTangDan(mang, 2);

        assertTrue(ac);
    }

    @Test
    public void test4() {

        int[][] mang = {{4, 2, 2}, {8, 2, 2}, {9, 2, 3}};
        boolean ac = GeneralMethod.AllMethod.kiemTraCotTangDan(mang, 0);

        assertTrue(ac);
    }

    @Test
    public void test5() {

        int[][] mang = {{2, 2, 2}, {2, 2, 2}, {3, 2, 3}};
        boolean ac = GeneralMethod.AllMethod.kiemTraCotTangDan(mang, 0);

        assertTrue(ac);
    }

    @Test
    public void test6() {

        int[][] mang = {{1, 2, 2}, {2, 2, 2}, {1, 2, 3}};
        boolean ac = GeneralMethod.AllMethod.kiemTraCotTangDan(mang, 0);

        assertTrue(ac);
    }

    @Test
    public void test7() {

        int[][] mang = {{4, 2, 2}, {2, 2, 2}, {1, 1, 3}};
        boolean ac = GeneralMethod.AllMethod.kiemTraCotTangDan(mang, 1);

        assertTrue(ac);
    }

    @Test
    public void test8() {

        int[][] mang = {{4, 2, 2}, {2, 2, 1}, {1, 2, 3}};
        boolean ac = GeneralMethod.AllMethod.kiemTraCotTangDan(mang, 2);

        assertTrue(ac);
    }

    @Test
    public void test9() {

        int[][] mang = {{4, 2, 2}, {2, 2, 2}, {1, 2, 1}};
        boolean ac = GeneralMethod.AllMethod.kiemTraCotTangDan(mang, 2);

        assertTrue(ac);
    }

    @Test
    public void test10() {

        int[][] mang = {{4, 2, 2}, {5, 2, 2}, {1, 2, 3}};
        boolean ac = GeneralMethod.AllMethod.kiemTraCotTangDan(mang, 0);

        assertTrue(ac);
    }
}
