/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UnitTest;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Asus
 */
public class KiemTraDoiXung_M2C {

    public KiemTraDoiXung_M2C() {
    }

    @Test
    public void test1() {

        int[][] mang = {{1,2,3}, {2,5,6} ,{3,6,1}};
        boolean ac = GeneralMethod.AllMethod.kiemTraDoiXung(mang);

        assertTrue(ac);
    }

   @Test
    public void test2() {

        int[][] mang = {{4,2,4}, {2,5,6} ,{4,6,1}};
        boolean ac = GeneralMethod.AllMethod.kiemTraDoiXung(mang);

        assertTrue(ac);
    }
    @Test
    public void test3() {

        int[][] mang = {{1,2,4}, {2,5,6} ,{4,6,1}};
        boolean ac = GeneralMethod.AllMethod.kiemTraDoiXung(mang);

        assertTrue(ac);
    }
    @Test
    public void test4() {

        int[][] mang = {{1,3,3}, {3,5,6} ,{3,6,1}};
        boolean ac = GeneralMethod.AllMethod.kiemTraDoiXung(mang);

        assertTrue(ac);
    }
    @Test
    public void test5() {

        int[][] mang = {{1,2,3}, {2,1,6} ,{3,6,1}};
        boolean ac = GeneralMethod.AllMethod.kiemTraDoiXung(mang);

        assertTrue(ac);
    }
    @Test
    public void test6() {

        int[][] mang = {{1,1,3}, {2,5,6} ,{3,6,1}};
        boolean ac = GeneralMethod.AllMethod.kiemTraDoiXung(mang);

        assertTrue(ac);
    }
    @Test
    public void test7() {

        int[][] mang = {{4,0,3}, {2,5,6} ,{4,6,1}};
        boolean ac = GeneralMethod.AllMethod.kiemTraDoiXung(mang);

        assertTrue(ac);
    }@Test
    public void test8() {

        int[][] mang = {{1,9,4}, {2,5,6} ,{4,6,1}};
        boolean ac = GeneralMethod.AllMethod.kiemTraDoiXung(mang);

        assertTrue(ac);
    }
    @Test
    public void test9() {

        int[][] mang = {{1,8,3}, {3,5,6} ,{3,6,1}};
        boolean ac = GeneralMethod.AllMethod.kiemTraDoiXung(mang);

        assertTrue(ac);
    }
    @Test
    public void test10() {

        int[][] mang = {{1,7,3}, {2,1,6} ,{3,6,1}};
        boolean ac = GeneralMethod.AllMethod.kiemTraDoiXung(mang);

        assertTrue(ac);
    }
    
    
}
