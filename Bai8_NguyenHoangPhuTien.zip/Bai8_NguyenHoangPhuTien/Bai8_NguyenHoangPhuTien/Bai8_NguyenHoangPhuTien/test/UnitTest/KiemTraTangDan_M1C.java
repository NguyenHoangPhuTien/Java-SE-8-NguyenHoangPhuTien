/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UnitTest;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Asus
 */
public class KiemTraTangDan_M1C {

    public KiemTraTangDan_M1C() {
    }

    @Test
    public void test1() {

        int[] mang = {1, 2, 2};
        boolean ac = GeneralMethod.AllMethod.kiemTraTangDan(mang);
        assertTrue(ac);
    }

    @Test
    public void test2() {

        int[] mang = {1, 2, 3};
        boolean ac = GeneralMethod.AllMethod.kiemTraTangDan(mang);
        assertTrue(ac);
    }

    @Test
    public void test3() {

        int[] mang = {4, 5, 9};
        boolean ac = GeneralMethod.AllMethod.kiemTraTangDan(mang);
        assertTrue(ac);
    }

    @Test
    public void test4() {

        int[] mang = {6, 8, 9};
        boolean ac = GeneralMethod.AllMethod.kiemTraTangDan(mang);
        assertTrue(ac);
    }

    @Test
    public void test5() {

        int[] mang = {0, 0, 1};
        boolean ac = GeneralMethod.AllMethod.kiemTraTangDan(mang);
        assertTrue(ac);
    }

    @Test
    public void test6() {

        int[] mang = {1, 2, 1};
        boolean ac = GeneralMethod.AllMethod.kiemTraTangDan(mang);
        assertTrue(ac);
    }

    @Test
    public void test7() {

        int[] mang = {3, 2, 3};
        boolean ac = GeneralMethod.AllMethod.kiemTraTangDan(mang);
        assertTrue(ac);
    }

    @Test
    public void test8() {

        int[] mang = {3, 3, 2};
        boolean ac = GeneralMethod.AllMethod.kiemTraTangDan(mang);
        assertTrue(ac);
    }

    @Test
    public void test9() {

        int[] mang = {4, 6, 1};
        boolean ac = GeneralMethod.AllMethod.kiemTraTangDan(mang);
        assertTrue(ac);
    }

    @Test
    public void test10() {

        int[] mang = {3, 2, 8};
        boolean ac = GeneralMethod.AllMethod.kiemTraTangDan(mang);
        assertTrue(ac);
    }

}
