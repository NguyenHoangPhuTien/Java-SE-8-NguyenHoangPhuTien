/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UnitTest;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Asus
 */
public class TimCapSoChiaHet_M1C {
    
    public TimCapSoChiaHet_M1C() {
    }

    @Test
    public void test1(){
        
         int[] mang = {1,2,3,4};

        String ac = GeneralMethod.AllMethod.timCapSoChiaHet(mang);
        String ex = "1 & 2 1 & 3 1 & 4 2 & 4";
        assertEquals(ex, ac);
    }
   
    @Test
    public void test2(){
        
         int[] mang = {1,2,3,0};

        String ac = GeneralMethod.AllMethod.timCapSoChiaHet(mang);
        String ex = "1 & 2 1 & 3";
        assertEquals(ex, ac);
    }
    
    @Test
    public void test3(){
        
         int[] mang = {1,1,3,4};

        String ac = GeneralMethod.AllMethod.timCapSoChiaHet(mang);
        String ex = "1 & 1 1 & 3 1 & 4";
        assertEquals(ex, ac);
    }
    
    @Test
    public void test4(){
        
         int[] mang = {0,2,3,4};

        String ac = GeneralMethod.AllMethod.timCapSoChiaHet(mang);
        String ex = "0 & 2 0 & 3 0 & 4 2 & 4";
        assertEquals(ex, ac);
    }
    
    
    @Test
    public void test5(){
        
         int[] mang = {7,2,3,5};

        String ac = GeneralMethod.AllMethod.timCapSoChiaHet(mang);
        String ex = "";
        assertEquals(ex, ac);
    }
    
    @Test
    public void test6(){
        
         int[] mang = {1,2,3,4};

        String ac = GeneralMethod.AllMethod.timCapSoChiaHet(mang);
        String ex = "1 & 2 1 & 3 1 & 4 2 & 4 ";
        assertEquals(ex, ac);
    }
    
    @Test
    public void test7(){
        
         int[] mang = {1,2,3,0};

        String ac = GeneralMethod.AllMethod.timCapSoChiaHet(mang);
        String ex = "1 & 2 1";
        assertEquals(ex, ac);
    }
    
    @Test
    public void test8(){
        
         int[] mang = {1,1,3,4};

        String ac = GeneralMethod.AllMethod.timCapSoChiaHet(mang);
        String ex = "1 & 1 1  3 1 & 4";
        assertEquals(ex, ac);
    }
    
    @Test
    public void test9(){
        
         int[] mang = {0,2,3,4};

        String ac = GeneralMethod.AllMethod.timCapSoChiaHet(mang);
        String ex = "";
        assertEquals(ex, ac);
    }
    
    @Test
    public void test10(){
        
         int[] mang = {0,2,3,5};

        String ac = GeneralMethod.AllMethod.timCapSoChiaHet(mang);
        String ex = "2 & 5";
        assertEquals(ex, ac);
    }
    
    
}
