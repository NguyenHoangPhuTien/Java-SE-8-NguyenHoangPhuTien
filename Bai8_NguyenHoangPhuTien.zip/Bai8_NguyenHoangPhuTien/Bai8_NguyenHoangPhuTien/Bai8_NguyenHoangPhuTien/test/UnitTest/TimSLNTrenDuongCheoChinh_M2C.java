/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UnitTest;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Asus
 */
public class TimSLNTrenDuongCheoChinh_M2C {

    public TimSLNTrenDuongCheoChinh_M2C() {
    }

    @Test
    public void test1() {

        int[][] mang = {{1,2,3}, {2,5,6} ,{3,6,1}};
        int ac = GeneralMethod.AllMethod.timSoLonNhatTrenDuongCheoChinh(mang);
        int ex = 5;
        assertEquals(ex, ac);
    }
    
    @Test
    public void test2() {

        int[][] mang = {{4,2,3}, {2,5,6} ,{4,8,2}};
        int ac = GeneralMethod.AllMethod.timSoLonNhatTrenDuongCheoChinh(mang);
        int ex = 5;
        assertEquals(ex, ac);
    }
    
    @Test
    public void test3() {

        int[][] mang = {{1,2,3}, {4,5,6} ,{7,8,9}};
        int ac = GeneralMethod.AllMethod.timSoLonNhatTrenDuongCheoChinh(mang);
        int ex = 9;
        assertEquals(ex, ac);
    }
    
    @Test
    public void test4() {

        int[][] mang = {{3,3,3}, {3,5,6} ,{3,20,10}};
        int ac = GeneralMethod.AllMethod.timSoLonNhatTrenDuongCheoChinh(mang);
        int ex = 10;
        assertEquals(ex, ac);
    }
    
    @Test
    public void test5() {

        int[][] mang = {{0,0,0}, {0,0,0} ,{0,0,0}};
        int ac = GeneralMethod.AllMethod.timSoLonNhatTrenDuongCheoChinh(mang);
        int ex = 0;
        assertEquals(ex, ac);
    }
    
    @Test
    public void test6() {

        int[][] mang = {{1,2,3}, {2,5,6} ,{3,6,1}};
        int ac = GeneralMethod.AllMethod.timSoLonNhatTrenDuongCheoChinh(mang);
        int ex = 2;
        assertEquals(ex, ac);
    }
    
    @Test
    public void test7() {

        int[][] mang = {{4,2,3}, {2,5,6} ,{4,8,2}};
        int ac = GeneralMethod.AllMethod.timSoLonNhatTrenDuongCheoChinh(mang);
        int ex = 3;
        assertEquals(ex, ac);
    }
    @Test
    public void test8() {

        int[][] mang = {{1,2,3}, {4,5,6} ,{7,8,9}};
        int ac = GeneralMethod.AllMethod.timSoLonNhatTrenDuongCheoChinh(mang);
        int ex = 7;
        assertEquals(ex, ac);
    }
    
    @Test
    public void test9() {

        int[][] mang = {{3,3,3}, {3,5,6} ,{3,20,10}};
        int ac = GeneralMethod.AllMethod.timSoLonNhatTrenDuongCheoChinh(mang);
        int ex = 20;
        assertEquals(ex, ac);
    }
    
    @Test
    public void test10() {

        int[][] mang = {{0,0,0}, {0,0,0} ,{0,0,1}};
        int ac = GeneralMethod.AllMethod.timSoLonNhatTrenDuongCheoChinh(mang);
        int ex = 0;
        assertEquals(ex, ac);
    }
    
    
}
