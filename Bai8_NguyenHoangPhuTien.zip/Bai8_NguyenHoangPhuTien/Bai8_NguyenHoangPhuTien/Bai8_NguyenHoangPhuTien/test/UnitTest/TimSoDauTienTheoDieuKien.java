/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UnitTest;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Asus
 */
public class TimSoDauTienTheoDieuKien {
    
    public TimSoDauTienTheoDieuKien() {
    }

    @Test
    public void test1(){
        
        int[] mang = {1,16,3,4};
        
        int ac = GeneralMethod.AllMethod.timSoDauTienChiaHet(6, mang);
        int ex = 16;
        assertEquals(ex, ac);
    }
    
    @Test
    public void test2(){
        
        int[] mang = {1,22,4,4};
        
        int ac = GeneralMethod.AllMethod.timSoDauTienChiaHet(2, mang);
        int ex = 22;
        assertEquals(ex, ac);
    }
    
    @Test
    public void test3(){
        
        int[] mang = {14,2,2,4};
        
        int ac = GeneralMethod.AllMethod.timSoDauTienChiaHet(4, mang);
        int ex = 14;
        assertEquals(ex, ac);
    }
    
    @Test
    public void test4(){
        
        int[] mang = {1,2,33,4};
        
        int ac = GeneralMethod.AllMethod.timSoDauTienChiaHet(3, mang);
        int ex = 33;
        assertEquals(ex, ac);
    }
    
    @Test
    public void test5(){
        
        int[] mang = {0,2,3,5};
        
        int ac = GeneralMethod.AllMethod.timSoDauTienChiaHet(6, mang);
        int ex = 0;
        assertEquals(ex, ac);
    }
    @Test
    public void test6(){
        
        int[] mang = {1,2,3,4};
        
        int ac = GeneralMethod.AllMethod.timSoDauTienChiaHet(6, mang);
        int ex = 2;
        assertEquals(ex, ac);
    }
    
    @Test
    public void test7(){
        
        int[] mang = {1,2,3,0};
        
        int ac = GeneralMethod.AllMethod.timSoDauTienChiaHet(8, mang);
        int ex = 3;
        assertEquals(ex, ac);
    }
    
    @Test
    public void test8(){
        
        int[] mang = {1,1,3,4};
        
        int ac = GeneralMethod.AllMethod.timSoDauTienChiaHet(9, mang);
        int ex = 1;
        assertEquals(ex, ac);
    }
    
    @Test
    public void test9(){
        
        int[] mang = {0,2,3,4};
        
        int ac = GeneralMethod.AllMethod.timSoDauTienChiaHet(5, mang);
        int ex = 2;
        assertEquals(ex, ac);
    }
    
    @Test
    public void test10(){
        
        int[] mang = {0,2,3,5};
        
        int ac = GeneralMethod.AllMethod.timSoDauTienChiaHet(1, mang);
        int ex = 5;
        assertEquals(ex, ac);
    }
    
    
    
}
