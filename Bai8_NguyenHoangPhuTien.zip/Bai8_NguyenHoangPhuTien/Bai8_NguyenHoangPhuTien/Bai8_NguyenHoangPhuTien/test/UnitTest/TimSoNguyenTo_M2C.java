/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UnitTest;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Asus
 */
public class TimSoNguyenTo_M2C {
    
    public TimSoNguyenTo_M2C() {
    }

    @Test
    public void test1() {

        int[][] mang = {{1, 2, 3}, {1, 2, 2}, {1, 2, 3}};
        String ac = GeneralMethod.AllMethod.timSoNguyenTo(mang);
        String ex = "2 3";
        assertEquals("Kết quả không đúng",ex, ac);
    }
    
    @Test
    public void test2() {

        int[][] mang = {{1, 2, 3}, {1, 2, 2}, {1, 2, 3}};
        String ac = GeneralMethod.AllMethod.timSoNguyenTo(mang);
        String ex = "2 3 1";
        assertEquals("Kết quả không đúng",ex, ac);
    }
    
    @Test
    public void test3() {

        int[][] mang = null;
        String ac = GeneralMethod.AllMethod.timSoNguyenTo(mang);
        String ex = "2 3 1";
        assertEquals("Kết quả không đúng",ex, ac);
    }
}
