/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UnitTest;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Asus
 */
public class TimViTriPhanTuLonNhat_Mang2Chieu {
    
    public TimViTriPhanTuLonNhat_Mang2Chieu() {
    }

    @Test
   public void test1(){
       
       int[][] mang = {{1,2,3},{1,2,3},{1,2,3}};
       
       String ac = GeneralMethod.AllMethod.timViTriPhanTuLonNhat(mang);
       String ex = "dòng 0 cột 2 dòng 1 cột 2 dòng 2 cột 2 ";
       assertEquals("Kết quả không đúng",ex, ac);
   }
   
   @Test
   public void test2(){
       
       int[][] mang = {{1,2,3},{1,2,3},{1,2,3}};
       
       String ac = GeneralMethod.AllMethod.timViTriPhanTuLonNhat(mang);
       String ex = "dòng 0 cột 2 dòng 1 cột 3 dòng 2 cột 2 ";
       assertEquals("Kết quả không đúng",ex, ac);
   }
   
   @Test
   public void test3(){
       
       int[][] mang = null;
       
      String ac = GeneralMethod.AllMethod.timViTriPhanTuLonNhat(mang);
       String ex = "dòng 0 cột 2 dòng 1 cột 2 dòng 2 cột 2 ";
       assertEquals("Kết quả không đúng",ex, ac);
   }
}
