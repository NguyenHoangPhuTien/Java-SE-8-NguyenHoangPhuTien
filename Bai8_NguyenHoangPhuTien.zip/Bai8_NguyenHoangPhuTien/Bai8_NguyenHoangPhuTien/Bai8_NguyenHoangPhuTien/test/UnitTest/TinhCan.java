/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UnitTest;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Asus
 */
public class TinhCan {
    
    public TinhCan() {
    }
    @Test
    public void test1(){
        
        String ac = GeneralMethod.AllMethod.layCan(1992);
        String ex = "Nhâm";
        assertEquals("Kết quả không đúng", ex, ac);
    }
    
    @Test
    public void test2(){
        
        String ac = GeneralMethod.AllMethod.layCan(1992);
        String ex = "Canh";
        assertEquals("Kết quả không đúng", ex, ac);
    }
    
    @Test
    public void test3(){
        
        String ac = GeneralMethod.AllMethod.layCan(-2);
        String ex = "Nhâm";
        assertEquals("Kết quả không đúng", ex, ac);
    }
}
