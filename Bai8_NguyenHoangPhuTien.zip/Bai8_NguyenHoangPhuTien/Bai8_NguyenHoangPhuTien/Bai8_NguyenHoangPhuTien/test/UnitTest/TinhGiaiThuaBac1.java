/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UnitTest;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Asus
 */
public class TinhGiaiThuaBac1 {
    
    public TinhGiaiThuaBac1() {
    }

    @Test
    public void test1(){
        
        int ac = GeneralMethod.AllMethod.tinhGiaiThuaBac1(0);
        int ex = 1;
        assertEquals("Kết quả không đúng", ex, ac);
    }
    
    @Test
    public void test2(){
        
        int ac = GeneralMethod.AllMethod.tinhGiaiThuaBac1(2);
        int ex = 2;
        assertEquals("Kết quả không đúng", ex, ac);
    }
    
    @Test
    public void test3(){
        
        int ac = GeneralMethod.AllMethod.tinhGiaiThuaBac1(2);
        int ex = 3;
        assertEquals("Kết quả không đúng", ex, ac);
    } 
    
    @Test
    public void test4(){
        
        int ac = GeneralMethod.AllMethod.tinhGiaiThuaBac1(-2);
        int ex = 2;
        assertEquals("Kết quả không đúng", ex, ac);
    } 
}
