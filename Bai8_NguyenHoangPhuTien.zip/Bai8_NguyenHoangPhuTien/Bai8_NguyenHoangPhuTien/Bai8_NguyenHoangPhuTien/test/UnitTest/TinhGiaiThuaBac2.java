/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UnitTest;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Asus
 */
public class TinhGiaiThuaBac2 {
    
    public TinhGiaiThuaBac2() {
    }

    @Test
    public void test1(){
        
        int ac = GeneralMethod.AllMethod.tinhGiaiThuaBac2(4);
        int ex = 8;
        assertEquals("Kết quả không đúng", ex, ac);
    }
    
    @Test
    public void test2(){
        
        int ac = GeneralMethod.AllMethod.tinhGiaiThuaBac2(4);
        int ex = 9;
        assertEquals("Kết quả không đúng", ex, ac);
    }
}
