/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UnitTest;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Asus
 */
public class TinhTBPhanTuLe_Mang2Chieu {
    
    public TinhTBPhanTuLe_Mang2Chieu() {
    }

     @Test
   public void test1(){
       
       int[][] mang = {{1,2,3},{1,2,3},{1,2,3}};
       
       double ac = GeneralMethod.AllMethod.tinhTrungBinhSoPhanTuLe(mang);
       double ex = 2;
       assertEquals("Kết quả không đúng",ex, ac,0.1);
   }
   
   @Test
   public void test2(){
       
       int[][] mang = {{1,2,3},{1,2,3},{1,2,3}};
       
       double ac = GeneralMethod.AllMethod.tinhTrungBinhSoPhanTuLe(mang);
       double ex = 4;
       assertEquals("Kết quả không đúng",ex, ac,0.1);
   }
   
   @Test
   public void test3(){
       
       int[][] mang = null;
       
       double ac = GeneralMethod.AllMethod.tinhTrungBinhSoPhanTuLe(mang);
       double ex = 3;
       assertEquals("Kết quả không đúng",ex, ac,0.1);
   }
}
