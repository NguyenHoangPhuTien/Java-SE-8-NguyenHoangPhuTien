/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UnitTest;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Asus
 */
public class TinhTongDuongCheoChinh_M2C {
    
    public TinhTongDuongCheoChinh_M2C() {
    }

   @Test
   public void test1(){
       
       int[][] mang = {{1,2,3},{1,2,3},{1,2,3}};
       
       int ac = GeneralMethod.AllMethod.tinhTongDuongCheoChinh(mang);
       int ex = 6;
       assertEquals("Kết quả không đúng",ex, ac);
   }
   
   @Test
   public void test2(){
       
       int[][] mang = {{1,2,3},{1,2,3},{1,2,3}};
       
       int ac = GeneralMethod.AllMethod.tinhTongDuongCheoChinh(mang);
       int ex = 5;
       assertEquals("Kết quả không đúng",ex, ac);
   }
   
   @Test
   public void test3(){
       
       int[][] mang = null;
       
       int ac = GeneralMethod.AllMethod.tinhTongDuongCheoChinh(mang);
       int ex = 5;
       assertEquals("Kết quả không đúng",ex, ac);
   }
}
