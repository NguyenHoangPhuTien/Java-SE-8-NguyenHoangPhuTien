/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UnitTest;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Asus
 */
public class kiemTraSoNguyenTo {

    public kiemTraSoNguyenTo() {
    }

    @Test
    public void test1() {

        boolean ac = GeneralMethod.AllMethod.kiemTraSNT(2);
        assertTrue(ac);
    }

    @Test
    public void test2() {

        boolean ac = GeneralMethod.AllMethod.kiemTraSNT(3);
        assertTrue(ac);
    }

    @Test
    public void test3() {

        boolean ac = GeneralMethod.AllMethod.kiemTraSNT(11);
        assertTrue(ac);
    }

    @Test
    public void test4() {

        boolean ac = GeneralMethod.AllMethod.kiemTraSNT(5);
        assertTrue(ac);
    }

    @Test
    public void test5() {

        boolean ac = GeneralMethod.AllMethod.kiemTraSNT(7);
        assertTrue(ac);
    }

    @Test
    public void test6() {

        boolean ac = GeneralMethod.AllMethod.kiemTraSNT(1);
        assertTrue(ac);
    }

    @Test
    public void test7() {

        boolean ac = GeneralMethod.AllMethod.kiemTraSNT(0);
        assertTrue(ac);
    }

    @Test
    public void test8() {

        boolean ac = GeneralMethod.AllMethod.kiemTraSNT(10);
        assertTrue(ac);
    }

    @Test
    public void test9() {

        boolean ac = GeneralMethod.AllMethod.kiemTraSNT(12);
        assertTrue(ac);
    }

    @Test
    public void test10() {

        boolean ac = GeneralMethod.AllMethod.kiemTraSNT(8);
        assertTrue(ac);
    }

}
