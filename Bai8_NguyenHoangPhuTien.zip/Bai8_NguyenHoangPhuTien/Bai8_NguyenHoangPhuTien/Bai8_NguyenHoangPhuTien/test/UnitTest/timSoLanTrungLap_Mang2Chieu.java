/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UnitTest;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Asus
 */
public class timSoLanTrungLap_Mang2Chieu {
    
    public timSoLanTrungLap_Mang2Chieu() {
    }

   @Test
   public void test1(){
       
       int[][] mang = {{1,2,3},{1,2,2}};
       int ac = GeneralMethod.AllMethod.tinhSoLanPhanTuTrungLap(mang, 2);
       int ex = 3;
       assertEquals(ex, ac);
   }
   
   @Test
   public void test2(){
       
       int[][] mang = {{1,2,3},{1,2,2}};
       int ac = GeneralMethod.AllMethod.tinhSoLanPhanTuTrungLap(mang, 1);
       int ex = 2;
       assertEquals(ex, ac);
   }
   
   @Test
   public void test3(){
       
       int[][] mang = {{1,2,3},{1,2,2}, {3,2}};
       int ac = GeneralMethod.AllMethod.tinhSoLanPhanTuTrungLap(mang, 2);
       int ex = 4;
       assertEquals(ex, ac);
   }
   
   @Test
   public void test4(){
       
       int[][] mang = {{1,2,3},{1,2,2},{0,0,0}};
       int ac = GeneralMethod.AllMethod.tinhSoLanPhanTuTrungLap(mang, 3);
       int ex = 1;
       assertEquals(ex, ac);
   }
   
   @Test
   public void test5(){
       
       int[][] mang = {{1,2,3},{1,2,2},{1,2,3,4}};
       int ac = GeneralMethod.AllMethod.tinhSoLanPhanTuTrungLap(mang, 2);
       int ex = 4;
       assertEquals(ex, ac);
   }
   
   @Test
   public void test6(){
       
       int[][] mang = {{1,2,3},{1,2,2}};
       int ac = GeneralMethod.AllMethod.tinhSoLanPhanTuTrungLap(mang, 2);
       int ex = 4;
       assertEquals(ex, ac);
   }
   
   @Test
   public void test7(){
       
       int[][] mang = {{1,2,3},{1,2,2}};
       int ac = GeneralMethod.AllMethod.tinhSoLanPhanTuTrungLap(mang, 1);
       int ex = 3;
       assertEquals(ex, ac);
   }
   @Test
   public void test8(){
       
       int[][] mang = {{1,2,3},{1,2,2}, {3,2}};
       int ac = GeneralMethod.AllMethod.tinhSoLanPhanTuTrungLap(mang, 1);
       int ex = 3;
       assertEquals(ex, ac);
   }@Test
   public void test9(){
       
       int[][] mang = {{1,2,3},{1,2,2},{}};
       int ac = GeneralMethod.AllMethod.tinhSoLanPhanTuTrungLap(mang, 2);
       int ex = 4;
       assertEquals(ex, ac);
   }
   @Test
   public void test10(){
       
       int[][] mang = {{1,2,3},{1,2,2},{1,2,3,4}};
       int ac = GeneralMethod.AllMethod.tinhSoLanPhanTuTrungLap(mang, 2);
       int ex = 3;
       assertEquals(ex, ac);
   }
   
   
}
