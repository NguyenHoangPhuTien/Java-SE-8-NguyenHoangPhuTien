/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.InputMismatchException;

/**
 *
 * @author hocvien
 */
public class DienTichvaChuViHT {

    /**
     * @param args the command line arguments
     */
    private static double tinhChuVi(double banKinh) {

        if (banKinh < 0) {
            throw new ArithmeticException("Bán kính phải là số dương");
        }
        double chuVi = 0;
        chuVi = 2 * banKinh * Math.PI;
        return chuVi;
    }

    private static double tinhDienTich(double banKinh) {

        if (banKinh < 0) {
            throw new ArithmeticException("Bán kính phải là số dương");
        }
        double dienTich = 0;
        dienTich = Math.PI * banKinh * banKinh;
        return dienTich;
    }

    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Nhập bán kính: ");
        try {
            double banKinh = Double.parseDouble(input.readLine());

            System.out.println(String.format("Chu vi là: %.2f", tinhChuVi(banKinh)));
            System.out.println(String.format("Diện tích là: %.2f", tinhDienTich(banKinh)));
        } catch(InputMismatchException e){
            System.out.println("Định dạng nhập vào không đúng");
        } catch (NumberFormatException e){
            System.out.println("Dữ liệu nhập vào không được để rỗng");
        } catch (ArithmeticException e){
            System.out.println(e.getMessage());
        }

    }

}
