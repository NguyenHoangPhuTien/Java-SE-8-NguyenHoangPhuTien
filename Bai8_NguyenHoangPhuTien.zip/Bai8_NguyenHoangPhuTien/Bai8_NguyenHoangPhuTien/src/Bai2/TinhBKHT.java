/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai2;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class TinhBKHT {

    /**
     * @param args the command line arguments
     */
    private static double tinhDienTich(double dienTich) {

        if (dienTich < 0) {
            throw new ArithmeticException("Diện tích phải là số dương");
        }
        double banKinh = 0;
        banKinh = Math.sqrt(dienTich / Math.PI);
        return banKinh;
    }

    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        try {
            System.out.println("Hãy nhập diện tích hình tròn:");
            double dienTich = scan.nextDouble();

            System.out.println(String.format("Bán kính hình tròn là: %.2f", tinhDienTich(dienTich)));
        } catch(InputMismatchException e){
            System.out.println("Định dạng nhập vào không đúng");
        } catch (NumberFormatException e){
            System.out.println("Dữ liệu nhập vào không được để rỗng");
        } catch (ArithmeticException e){
            System.out.println(e.getMessage());
        }
       
    }

}
