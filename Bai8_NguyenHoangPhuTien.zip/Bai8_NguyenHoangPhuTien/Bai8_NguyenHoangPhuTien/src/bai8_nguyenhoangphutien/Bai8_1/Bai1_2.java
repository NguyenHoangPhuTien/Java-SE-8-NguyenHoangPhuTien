/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8_nguyenhoangphutien.Bai8_1;

import java.util.Scanner;

/**
 *
 * @author Asus
 */
public class Bai1_2 {

    /**
     * @param args the command line arguments
     */
    private static void inThongTin(String hoTen, String email) {

        if(hoTen == null || email == null)
            throw new NullPointerException("Họ và tên không được để trống");
        System.out.println("********************************");
        System.out.println("Dang ki thong tien hoc vien");
        System.out.println("********************************");
        System.out.println("");
        System.out.println("");
        System.out.println("Ho ten: " + hoTen);
        System.out.println("Email: " + email);
        System.out.println("---------------------------------");
        System.out.println("----Xin chao ban " + hoTen);
        System.out.println("----Thong tin cua ban duoc ghi nhan");
    }

    public static void main(String[] args) {
        // TODO code application logic here
        String hoten = "", email = "";
        Scanner scan = new Scanner(System.in);
        try {
            System.out.println("Xin hay nhap ho ten:");
            hoten = scan.nextLine();
            System.out.println("Xin hay nhap email: ");
            email = scan.nextLine();
            inThongTin(hoten, email);
        } catch (NullPointerException e) {
            System.out.println(e.getMessage());
        }

    }

}
