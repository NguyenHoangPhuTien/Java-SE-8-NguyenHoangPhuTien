/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8_nguyenhoangphutien.Bai8_1;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author Asus
 */
public class Bai4_6 {

    /**
     * @param args the command line arguments
     */
    private static double tinhNhietDo(String loaiDo, double nhietDo) {

        if(loaiDo == null)
            throw new NullPointerException("Giá trị loai độ đang rỗng");
        if(!loaiDo.equals("F" )&& !loaiDo.equals("f") && !loaiDo.equals("C" ) && !loaiDo.equals("c"))
            throw new ArithmeticException("Giá trị loại đô chỉ có thể là C c F f");
        if(nhietDo < 0)
            throw new ArithmeticException("Giá trị nhiệt độ không thể âm");
        switch (loaiDo) {

            case "F":
            case "f":
                nhietDo = (nhietDo * 1.8) + 32;
                break;

            case "C":
            case "c":
                nhietDo = 5 * (nhietDo - 32) / 9;
                break;
        }
        return nhietDo;
    }

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        System.out.println("Hãy chọn loại độ mún xem:");
        try {
            String loaiDo = scan.nextLine();

            System.out.println("Hãy nhập nhiệt độ");
            double nhietDo = scan.nextDouble();

            System.out.println(String.format("Nhiệt độ là %.2f", tinhNhietDo(loaiDo, nhietDo)));
        } catch(InputMismatchException e){
            System.out.println("Định dạng nhập vào không đúng");
        } catch (NumberFormatException e){
            System.out.println("Dữ liệu nhập vào không được để rỗng");
        } catch (ArithmeticException e){
            System.out.println(e.getMessage());
        }
        
    }

}
