/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8_nguyenhoangphutien.Bai8_1;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author Asus
 */
public class Bai5_4 {

    /**
     * @param args the command line arguments
     */
    private static int tinhTongChan(int so) {

        if(so < 0)
            throw  new ArithmeticException("Số cần kiểm tra không đươc âm");
        int iSum = 0, i;
        for (i = 1; i <= so; i++) {
            if (i % 2 == 0) {
                iSum += i;
            }
        }
        return iSum;
    }

    private static int tinhTongLe(int so) {

        if(so < 0)
            throw  new ArithmeticException("Số cần kiểm tra không đươc âm");
        int iSum = 0, i;
        for (i = 1; i <= so; i++) {
            if (i % 2 != 0) {
                iSum += i;
            }
        }
        return iSum;
    }

    private static int tinhTich(int so) {
        if(so < 0)
            throw  new ArithmeticException("Số cần kiểm tra không đươc âm");
        int iTich = 1, i;
        if (so == 0) {
            iTich = 0;
        }
        for (i = 1; i <= so; i++) {
            iTich *= i;
        }
        return iTich;
    }

    private static int tinhTongTich(int so) {
        if(so < 0)
            throw  new ArithmeticException("Số cần kiểm tra không đươc âm");
        int iTich = 1, i;
        if (so == 0) {
            iTich = 0;
        }
        for (i = 1; i <= so; i++) {
            if (i % 3 == 0) {
                iTich *= i;
            }
        }
        return iTich;
    }

    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);

        System.out.println("Hãy nhập vào số nguyên: ");
        try {
            int so = scan.nextInt();

            System.out.println("Tổng các số chẵn là: " + tinhTongChan(so));
            System.out.println("Tổng các số le là: " + tinhTongLe(so));
            System.out.println("Tích các số là: " + tinhTich(so));
            System.out.println("Tích các số chia hết cho 3: " + tinhTongTich(so));
        } catch (InputMismatchException e) {
            System.out.println("Định dạng nhập vào không đúng");
        } catch (NumberFormatException e){
            System.out.println("Số không được rỗng");
        } catch (ArithmeticException e){
            System.out.println(e.getMessage());
        }

    }

}
