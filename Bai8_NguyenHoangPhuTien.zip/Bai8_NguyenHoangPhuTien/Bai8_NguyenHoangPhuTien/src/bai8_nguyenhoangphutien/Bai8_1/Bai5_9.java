/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8_nguyenhoangphutien.Bai8_1;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author Asus
 */
public class Bai5_9 {

    /**
     * @param args the command line arguments
     */
    private static void tinhGiaiThuaBac1(int so) {
        if (so < 0) {
            throw new ArithmeticException(" Số cần tính phải là số dương");
        }
        String chuoi = so + "! = ";
        int i, tich = 1;
        if (so == 0) {
            chuoi = "0! = 1";
        } else {
            for (i = 1; i <= so; i++) {
                if (i == 1) {
                    chuoi += "1";
                } else {
                    chuoi += " x " + i;
                }
                tich *= i;
            }
        }
        System.out.println(chuoi + " = " + tich);
    }

    private static void tinhGiaiThuaBac2(int so) {

        if (so < 0) {
            throw new ArithmeticException(" Số cần tính phải là số dương");
        }
        String chuoi = so + "!! = ";
        int i, tich = 1;
        if (so == 0) {
            chuoi = "0!! = 1 ";
        } else {
            if (so % 2 == 0) {
                for (i = 1; i <= so; i++) {
                    if (i % 2 == 0) {
                        chuoi += i + " x ";
                        tich *= i;
                    }
                }
            } else {
                for (i = 1; i <= so; i++) {
                    if (i % 2 != 0) {
                        chuoi += i + " x ";
                        tich *= i;
                    }
                }
            }

        }
        chuoi = chuoi.substring(0, chuoi.length() - 2);
        System.out.println(chuoi + " = " + tich);
    }

    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);

        System.out.println("Nhập số nguyên: ");
        try {
            int so = scan.nextInt();

            tinhGiaiThuaBac1(so);
            tinhGiaiThuaBac2(so);
        }catch(InputMismatchException e){
            System.out.println("Định dạng nhập vào không đúng");
        } catch (NumberFormatException e){
            System.out.println("Dữ liệu nhập vào không được để rỗng");
        } catch (ArithmeticException e){
            System.out.println(e.getMessage());
        }

    }

}
