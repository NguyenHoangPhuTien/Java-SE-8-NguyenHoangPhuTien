/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8_nguyenhoangphutien.Bai8_1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.InputMismatchException;
import java.util.Random;

/**
 *
 * @author hocvien
 */
public class Bai6_1 {

    /**
     * @param args the command line arguments
     */
    public static String xuatMang(int[] mang) {

        if(mang == null){
            System.out.println("Mảng đang có giá trị null");
        }
        String chuoi = "";
        for (int value : mang) {
            chuoi += String.format(" %d ", value);
        }

        return chuoi;
    }

    private static int tinhTong(int[] mang) {

        if(mang == null){
            System.out.println("Mảng đang có giá trị null");
        }
        int tong = 0;
        for (int value : mang) {
            tong += value;
        }

        return tong;
    }

    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Hãy nhập chiều dài của mảng: ");
        try {
            String tam = input.readLine();
            int n = Integer.parseInt(tam);

            int[] mang = new int[n];
            Random random = new Random();
            for (int i = 0; i < n; i++) {
                mang[i] = random.nextInt(10);
            }

            System.out.println("Mãng ngẩu nhiên: " + xuatMang(mang));
            System.out.println("Tổng cuả mảng là: " + tinhTong(mang));
        } catch(InputMismatchException e){
            System.out.println("Định dạng nhập vào không đúng");
        } catch (NumberFormatException e){
            System.out.println("Dữ liệu nhập vào không được để rỗng");
        } catch (NullPointerException e){
            System.out.println(e.getMessage());
        }

    }

}
