/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8_nguyenhoangphutien.Bai8_1;

import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author hocvien
 */
public class Bai6_2 {

    /**
     * @param args the command line arguments
     */
    public static String xuatMang(int[] mang) {

        String chuoi = "";
        for (int value : mang) {
            chuoi += String.format(" %d ", value);
        }

        return chuoi;
    }

    private static String kiemTra(int so, int[] mang) {
        
         if(mang == null){
            System.out.println("Mảng đang có giá trị null");
        }
        String chuoi = "Phần tử không xuất hiện trong mảng";
        for (int i = 0; i < mang.length; i++) {
            if (mang[i] == so) {
                chuoi = String.format("%d xuất hiện trong mảng ở vị trí %d", so, i + 1);
                break;
            }

        }
        return chuoi;
    }

    private static String kiemTraLonHon(int so, int[] mang) {
        
         if(mang == null){
            System.out.println("Mảng đang có giá trị null");
        }
        String chuoi = so + " lớn hơn tất cả phần tử trong mảng";
        for (int value : mang) {
            if (value > so) {
                chuoi = so + " không lớn hơn tất cả phần tử trong mảng";
            }
        }
        return chuoi;
    }

    private static String timSoLonHon(int so, int[] mang) {

         if(mang == null){
            System.out.println("Mảng đang có giá trị null");
        }
        String chuoi = "";
        for (int value : mang) {
            if (value > so) {
                chuoi += value + " ";
            }
        }
        chuoi = "Tất cả các số lớn hơn " + so + ": " + chuoi;
        return chuoi;
    }

    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);

        try {
            System.out.println("Hãy nhập chiều dài mảng: ");
            int n = scan.nextInt();

            System.out.println("Hãy nhập giá trị phần tử mảng: ");
            int[] mang = new int[n];
            System.out.println("");

            for (int i = 0; i < n; i++) {
                System.out.println("Nhập giá trị số thứ " + (i + 1));
                mang[i] = scan.nextInt();
            }

            System.out.println("Hãy nhập số cần kiểm tra: ");
            int so = scan.nextInt();

            System.out.println("Mảng là: " + xuatMang(mang));
            System.out.println(kiemTra(so, mang));
            System.out.println(kiemTraLonHon(so, mang));
            if (kiemTraLonHon(so, mang).equals(so + " không lớn hơn tất cả phần tử trong mảng")) {
                System.out.println(timSoLonHon(so, mang));
            }
        } catch(InputMismatchException e){
            System.out.println("Định dạng nhập vào không đúng");
        } catch (NumberFormatException e){
            System.out.println("Dữ liệu nhập vào không được để rỗng");
        } catch (NullPointerException e){
            System.out.println(e.getMessage());
        }

    }

}
