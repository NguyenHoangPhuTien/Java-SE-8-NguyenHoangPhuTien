/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexercise2_ngu;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.InputMismatchException;

/**
 *
 * @author hocvien
 */
public class Bai1_GoiCuoc {

    /**
     * @param args the command line arguments
     */
    enum EMSThuong{
        
        NTINH(8000,8000,10000,12500,15000,18000,21000,1600),
        V1(8500,12500,16500,23500,33000,40000,48500,3800),
        V2_1(9500,13500,20000,26500,38500,49500,59500,8500),
        V2_2(9500,13500,21500,28000,40500,52500,63500,8500),
        V3(10000,14000,22500,29500,43500,55500,67500,9500);
        
        private double bac1;
        private double bac2;
        private double bac3;
        private double bac4;
        private double bac5;
        private double bac6;
        private double bac7;
        private double bac8;

        private EMSThuong(double bac1, double bac2, double bac3, double bac4, double bac5, double bac6, double bac7, double bac8) {
            this.bac1 = bac1;
            this.bac2 = bac2;
            this.bac3 = bac3;
            this.bac4 = bac4;
            this.bac5 = bac5;
            this.bac6 = bac6;
            this.bac7 = bac7;
            this.bac8 = bac8;
        }

        public void setBac1(double bac1) {
            this.bac1 = bac1;
        }

        public void setBac2(double bac2) {
            this.bac2 = bac2;
        }

        public void setBac3(double bac3) {
            this.bac3 = bac3;
        }

        public void setBac4(double bac4) {
            this.bac4 = bac4;
        }

        public void setBac5(double bac5) {
            this.bac5 = bac5;
        }

        public void setBac6(double bac6) {
            this.bac6 = bac6;
        }

        public void setBac7(double bac7) {
            this.bac7 = bac7;
        }

        public void setBac8(double bac8) {
            this.bac8 = bac8;
        }

        public static EMSThuong getNTINH() {
            return NTINH;
        }

        public static EMSThuong getV1() {
            return V1;
        }

        public static EMSThuong getV2_1() {
            return V2_1;
        }

        public static EMSThuong getV2_2() {
            return V2_2;
        }

        public static EMSThuong getV3() {
            return V3;
        }

        public double getBac1() {
            return bac1;
        }

        public double getBac2() {
            return bac2;
        }

        public double getBac3() {
            return bac3;
        }

        public double getBac4() {
            return bac4;
        }

        public double getBac5() {
            return bac5;
        }

        public double getBac6() {
            return bac6;
        }

        public double getBac7() {
            return bac7;
        }

        public double getBac8() {
            return bac8;
        }
        
        public double tinhTien(double trongLuong){
           
            
            double tongTien = 0;
            
            if(trongLuong < 50)
                tongTien = this.getBac1();
            else if(trongLuong < 100)
                tongTien = this.getBac2() + this.getBac1();
            else if(trongLuong < 250)
                tongTien = this.getBac3() + this.getBac2()
                        +  this.getBac1();
            else if(trongLuong < 500)
                tongTien = this.getBac4() + this.getBac3()
                        +  this.getBac2() + this.getBac1();
            else if(trongLuong < 1000)
                tongTien = this.getBac5() + this.getBac4()
                        +  this.getBac3() + this.getBac2() + this.getBac1();
            else if(trongLuong < 1500)
                tongTien = this.getBac6() + this.getBac5()
                        + this.getBac4() + this.getBac3() + this.getBac2() + this.getBac1();
            else if(trongLuong < 2000)
                tongTien = this.getBac7() + this.getBac6()
                        + this.getBac5() + this.getBac4() 
                        + this.getBac3() + this.getBac2() + this.getBac1();
                        
            else 
                tongTien = Math.ceil((trongLuong - 2000)/500) * this.getBac8() + this.getBac7()
                        +  this.getBac6() + this.getBac5() + this.getBac4()
                        +  this.getBac3() + this.getBac2() + this.getBac1();
                        
            
            return tongTien;
        }
        
    }
    enum DVTrongNgay{
        
        NTINH(50000,5000),
        V1(70000,7000),
        V2_1(110000,12000),
        V2_2(130000,20000),;
        
        private double bac1;
        private double bac2;

        private DVTrongNgay(double bac1, double bac2) {
            this.bac1 = bac1;
            this.bac2 = bac2;
        }

        public static DVTrongNgay getNTINH() {
            return NTINH;
        }

        public static DVTrongNgay getV1() {
            return V1;
        }

        public static DVTrongNgay getV2_1() {
            return V2_1;
        }

        public static DVTrongNgay getV2_2() {
            return V2_2;
        }

        public double getBac1() {
            return bac1;
        }

        public double getBac2() {
            return bac2;
        }
       
        public double tinhTien(double trongLuong){
            
            double tongTien = 0;
            if(trongLuong < 2000)
                tongTien = this.getBac1();
            else
                tongTien = Math.ceil((trongLuong - 2000)/500) * this.getBac2()
                        + this.getBac1();
            
            return tongTien;
        }
        
    }
    
    enum HoaToc{
        
         
        NTINH(5000,5000),
        V1(70000,7000),
        V2_1(85000,10000),
        V2_2(100000,12000),
        V3(110000,15000);
        
        private double bac1;
        private double bac2;

        private HoaToc(double bac1, double bac2) {
            this.bac1 = bac1;
            this.bac2 = bac2;
        }

        public static HoaToc getNTINH() {
            return NTINH;
        }

        public static HoaToc getV1() {
            return V1;
        }

        public static HoaToc getV2_1() {
            return V2_1;
        }

        public static HoaToc getV2_2() {
            return V2_2;
        }

        public static HoaToc getV3() {
            return V3;
        }

        public double getBac1() {
            return bac1;
        }

        public double getBac2() {
            return bac2;
        }
        
        public double tinhTien(double trongLuong){
            
            double tongTien = 0;
            if(trongLuong < 2000)
                tongTien = this.getBac1();
            else
                tongTien = Math.ceil((trongLuong - 2000)/500) * this.getBac2()
                        + this.getBac1();
            
            return tongTien;
        }
    }
    
    public static double tinhTienEMSThuong(double trongLuong, int hinhThuc){
        
        if(trongLuong <= 0)
            throw new ArithmeticException("Trọng lương không hợp lệ");
        
        double tongTien = 0;
        
        switch(hinhThuc){
            
            case 1:
                tongTien = EMSThuong.NTINH.tinhTien(trongLuong);
                break;
            case 2:
                tongTien = EMSThuong.V1.tinhTien(trongLuong);
                break;
            case 3:
                tongTien = EMSThuong.V2_1.tinhTien(trongLuong);
                break;
            case 4:
                tongTien = EMSThuong.V2_2.tinhTien(trongLuong);
                break;
            case 5:
                tongTien = EMSThuong.V3.tinhTien(trongLuong);
                break;
            default:
                throw new ArithmeticException("Hình thức không hơp lệ");
        }
        return tongTien;
    }
    public static double tinhTienDVTrongNgay(double trongLuong, int hinhThuc){
        
     if(trongLuong <= 0)
            throw new ArithmeticException("Trọng lương không hợp lệ");
     
    double tongTien = 0;
    
        switch(hinhThuc){
            
            case 1:
                tongTien = DVTrongNgay.NTINH.tinhTien(trongLuong);
                break;
            case 2:
                tongTien = DVTrongNgay.V1.tinhTien(trongLuong);
                break;
            case 3:
                tongTien = DVTrongNgay.V2_1.tinhTien(trongLuong);
                break;
            case 4:
                tongTien = DVTrongNgay.V2_2.tinhTien(trongLuong);
                break;
            
            default:
                throw new ArithmeticException("Hình thức không hơp lệ");
        }
        return tongTien;
    }
    public static double tinhTienHoaToc(double trongLuong, int hinhThuc){
        
     if(trongLuong <= 0)
            throw new ArithmeticException("Trọng lương không hợp lệ");
     
    double tongTien = 0;
    
        switch(hinhThuc){
            
            case 1:
                tongTien = HoaToc.NTINH.tinhTien(trongLuong);
                break;
            case 2:
                tongTien = HoaToc.V1.tinhTien(trongLuong);
                break;
            case 3:
                tongTien = HoaToc.V2_1.tinhTien(trongLuong);
                break;
            case 4:
                tongTien = HoaToc.V2_2.tinhTien(trongLuong);
                break;
            case 5:
                tongTien = HoaToc.V3.tinhTien(trongLuong);
                break;
            default:
                throw new ArithmeticException("Hình thức không hơp lệ");
        }
        return tongTien;
    }
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        
        try {
            System.out.println("Nhập trọng lượng bưu phẩm(gr): ");
            double trongLuong = Double.parseDouble(input.readLine());
            
            System.out.println("1.Cước EMS thường");
            System.out.println("2.Cước Dịch vụ trong ngày");
            System.out.println("3.Cước hỏa tốc");
            
            System.out.println("Chọn dịch vụ(1/2/3)");
            int chon = Integer.parseInt(input.readLine());
            
            switch (chon){
                
                case 1:
                    System.out.println("1.Nội tỉnh");
                    System.out.println("2.Liên tỉnh- Vùng 1");
                    System.out.println("3.Liên tỉnh- Vùng 2 - Đà Nẳng đi tpHCM, HN và ngược lại");
                    System.out.println("4.Liên tỉnh- Vùng 2 - Hà Nội đi tpHCM và ngược lại");
                    System.out.println("5.Liên tỉnh- Vùng 3");
                    System.out.println("Hãy chọn hình thức(1/2/3/4/5): ");
                    int hinhThuc = Integer.parseInt(input.readLine());
                    
                    double tongTien = tinhTienEMSThuong(trongLuong, hinhThuc);
                    System.out.println("Tiền là: "+tongTien);
                    break;
                case 2:
                    System.err.println("");
                    System.out.println("1.Nội tỉnh");
                    System.out.println("2.Liên tỉnh- Vùng 1");
                    System.out.println("3.Liên tỉnh- Vùng 2 - Đà Nẳng đi tpHCM, HN và ngược lại");
                    System.out.println("4.Liên tỉnh- Vùng 2 - Hà Nội đi tpHCM và ngược lại");
                    System.out.println("Hãy chọn hình thức(1/2/3/4): ");
                    int hinhThuc1 = Integer.parseInt(input.readLine());
                    
                    double tongTien1 = tinhTienDVTrongNgay(trongLuong, hinhThuc1);
                    System.out.println("Tiền là: "+tongTien1);
                    break;
                case 3:
                    System.out.println("1.Nội tỉnh");
                    System.out.println("2.Liên tỉnh- Vùng 1");
                    System.out.println("3.Liên tỉnh- Vùng 2 - Đà Nẳng đi tpHCM, HN và ngược lại");
                    System.out.println("4.Liên tỉnh- Vùng 2 - Hà Nội đi tpHCM và ngược lại");
                    System.out.println("5.Liên tỉnh- Vùng 3");
                    System.out.println("Hãy chọn hình thức(1/2/3/4/5): ");
                    int hinhThuc2 = Integer.parseInt(input.readLine());
                    
                    double tongTien2 = tinhTienHoaToc(trongLuong, hinhThuc2);
                    System.out.println("Tiền là: "+tongTien2);
                    break;
                    
            }
            
            
        } catch (NumberFormatException | InputMismatchException e) {
            System.out.println(e.getMessage());
        } catch (ArithmeticException e){
            System.out.println(e.getMessage());
        }
    }
    
}
