/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexercise2_ngu;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.InputMismatchException;

/**
 *
 * @author hocvien
 */
public class Bai2_TienNuoc {

    /**
     * @param args the command line arguments
     */
    enum SinhHoat {

        GIATIEN_1(5300, 265, 530),
        GIATIEN_2(10200, 510, 1020),
        GIATIEN_3(11400, 570, 1140);
        
        private double tienNuoc;
        private double tienThue;
        private double tienBaoVe;

        private SinhHoat(double tienNuoc, double tienThue, double tienBaoVe) {
            this.tienNuoc = tienNuoc;
            this.tienThue = tienThue;
            this.tienBaoVe = tienBaoVe;
        }

        public static SinhHoat getGIATIEN_1() {
            return GIATIEN_1;
        }

        public static SinhHoat getGIATIEN_2() {
            return GIATIEN_2;
        }

        public static SinhHoat getGIATIEN_3() {
            return GIATIEN_3;
        }

        public double getTienNuoc() {
            return tienNuoc;
        }

        public double getTienThue() {
            return tienThue;
        }

        public double getTienBaoVe() {
            return tienBaoVe;
        }

    }

    enum KhongSinhHoat {

        DONVI(9600,480,960),
        COQUAN(10300,515,1030),
        KINHDOANH(16900,845,1690);

        private double giaTien;
        private double thue;
        private double baoVe;

        private KhongSinhHoat(double giaTien, double thue, double baoVe) {
            this.giaTien = giaTien;
            this.thue = thue;
            this.baoVe = baoVe;
        }

        public static KhongSinhHoat getDONVI() {
            return DONVI;
        }

        public static KhongSinhHoat getCOQUAN() {
            return COQUAN;
        }

        public static KhongSinhHoat getKINHDOANH() {
            return KINHDOANH;
        }

        public double getGiaTien() {
            return giaTien;
        }

        public double getThue() {
            return thue;
        }

        public double getBaoVe() {
            return baoVe;
        }

        public double tinhTienNuoc(double soNuoc){
            
            double tongTien = 0;
            tongTien = this.getGiaTien() * soNuoc;
             
            return tongTien;
        }
        public double tinhThue(double soNuoc){
            
            double tongTien = 0;
            tongTien = this.getThue() * soNuoc;
            
            return tongTien;
            
        }
        public double tinhBaoVe(double soNuoc){
            
            double tongTien = 0;
            tongTien = this.getBaoVe() * soNuoc;
            
            return tongTien;
        }
    }

    public static double tinhTienNuocSinhHoat(double soNuoc, int soNguoi) {

        if (soNuoc < 0 || soNguoi < 0) {
            throw new ArithmeticException("Dữ liệu không hợp lệ");
        }
        soNuoc = soNuoc / soNguoi;
       double tongTien = 0;
            if (soNuoc < 4) {
                tongTien = soNuoc * SinhHoat.GIATIEN_1.getTienNuoc();
                tongTien = tongTien * soNguoi;
            } else if (soNuoc < 6) {
                tongTien = (soNuoc - 4) * SinhHoat.GIATIEN_2.getTienNuoc()
                        + 4 * SinhHoat.GIATIEN_1.getTienNuoc();
                tongTien = tongTien * soNguoi;
            } else {
                tongTien = (soNuoc - 6) * SinhHoat.GIATIEN_3.getTienNuoc() 
                        + 2 * SinhHoat.GIATIEN_2.getTienNuoc()
                        + 4 * SinhHoat.GIATIEN_1.getTienNuoc();
                tongTien = tongTien * soNguoi;
            }
            return tongTien;
    }
    public static double tinhTienThueSinhHoat(double soNuoc, int soNguoi){
        
         if (soNuoc < 0 || soNguoi < 0) {
            throw new ArithmeticException("Dữ liệu không hợp lệ");
        }
        soNuoc = soNuoc / soNguoi;
        
        
            double tongTien = 0;
            if (soNuoc < 4) {
                tongTien = soNuoc * SinhHoat.GIATIEN_1.getTienThue();
                tongTien = tongTien * soNguoi;
            } else if (soNuoc < 6) {
                tongTien = (soNuoc - 4) * SinhHoat.GIATIEN_2.getTienThue()
                        + 4 * SinhHoat.GIATIEN_1.getTienThue();
                tongTien = tongTien * soNguoi;
            } else {
                tongTien = (soNuoc - 6) * SinhHoat.GIATIEN_3.getTienThue() 
                        + 2 * SinhHoat.GIATIEN_2.getTienThue()
                        + 4 * SinhHoat.GIATIEN_1.getTienThue();
                tongTien = tongTien * soNguoi;
            }
            return tongTien;
    }
    public static double tinhTienBaoVeSinhHoat(double soNuoc, int soNguoi){
        
         if (soNuoc < 0 || soNguoi < 0) {
            throw new ArithmeticException("Dữ liệu không hợp lệ");
        }
        soNuoc = soNuoc / soNguoi;
        
        double tongTien = 0;
            if (soNuoc < 4) {
                tongTien = soNuoc * SinhHoat.GIATIEN_1.getTienBaoVe();
                tongTien = tongTien * soNguoi;
            } else if (soNuoc < 6) {
                tongTien = (soNuoc - 4) * SinhHoat.GIATIEN_2.getTienBaoVe()
                        + 4 * SinhHoat.GIATIEN_1.getTienBaoVe();
                tongTien = tongTien * soNguoi;
            } else {
                tongTien = (soNuoc - 6) * SinhHoat.GIATIEN_3.getTienBaoVe() 
                        + 2 * SinhHoat.GIATIEN_2.getTienBaoVe()
                        + 4 * SinhHoat.GIATIEN_1.getTienBaoVe();
                tongTien = tongTien * soNguoi;
            }
            return tongTien;
    }
    
    
    public static double tinhTienNuocKhongSinhHoat(double soNuoc, int hinhThuc) {

        if (soNuoc < 0) {
            throw new ArithmeticException("Số nước không hơp lệ");
        }
        double tongTien = 0;

        switch (hinhThuc) {

            case 1:
                tongTien = KhongSinhHoat.COQUAN.tinhTienNuoc(soNuoc);
                break;
            case 2:
                tongTien = KhongSinhHoat.DONVI.tinhTienNuoc(soNuoc);
                break;
            case 3:
                tongTien = KhongSinhHoat.KINHDOANH.tinhTienNuoc(soNuoc);
                break;
            default:
                throw new ArithmeticException("Hình thức không hợp lệ");
        }
        return tongTien;
    }

    public static double tinhTienThueKhongSinhHoat(double soNuoc, int hinhThuc) {

        if (soNuoc < 0) {
            throw new ArithmeticException("Số nước không hơp lệ");
        }
        double tongTien = 0;

        switch (hinhThuc) {

            case 1:
                tongTien = KhongSinhHoat.COQUAN.tinhThue(soNuoc);
                break;
            case 2:
                tongTien = KhongSinhHoat.DONVI.tinhThue(soNuoc);
                break;
            case 3:
                tongTien = KhongSinhHoat.KINHDOANH.tinhThue(soNuoc);
                break;
            default:
                throw new ArithmeticException("Hình thức không hợp lệ");
        }
        return tongTien;
    }
    public static double tinhTienBaoVeKhongSinhHoat(double soNuoc, int hinhThuc) {

        if (soNuoc < 0) {
            throw new ArithmeticException("Số nước không hơp lệ");
        }
        double tongTien = 0;

        switch (hinhThuc) {

            case 1:
                tongTien = KhongSinhHoat.COQUAN.tinhBaoVe(soNuoc);
                break;
            case 2:
                tongTien = KhongSinhHoat.DONVI.tinhBaoVe(soNuoc);
                break;
            case 3:
                tongTien = KhongSinhHoat.KINHDOANH.tinhBaoVe(soNuoc);
                break;
            default:
                throw new ArithmeticException("Hình thức không hợp lệ");
        }
        return tongTien;
    }
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        try {
            System.out.println("Nhập số nước: ");
            double soNuoc = Double.parseDouble(input.readLine());

            System.out.println("Hình thức tính : ");
            System.out.println("1.Đối tương sinh hoạt");
            System.out.println("2.Đối tương không sinh hoạt");
            System.out.println("Chọn hình thức(1/2)");
            int hinhThuc = Integer.parseInt(input.readLine());

            switch (hinhThuc) {

                case 1:
                    System.out.println("Nhập số người: ");
                    int soNguoi = Integer.parseInt(input.readLine());
                    double tienNuoc = tinhTienNuocSinhHoat(soNuoc, soNguoi);
                    double tienThue = tinhTienThueSinhHoat(soNuoc, soNguoi);
                    double tienBaoVe = tinhTienBaoVeSinhHoat(soNuoc, soNguoi);
                    double tongTien = tienNuoc + tienBaoVe + tienThue;
                    System.out.println("Tiền nước là: "+tienNuoc);
                    System.out.println("Tiền thuế là: "+tienThue);
                    System.out.println("Tiền bảo vệ là: "+tienBaoVe);
                    System.out.println("Tổng tiền là: " + tongTien);
                    break;

                case 2:
                    System.out.println("Loại: ");
                    System.out.println("1.Đơn vị sản xuất");
                    System.out.println("2.Cơ quan đoàn thể HC sự nghiệp");
                    System.out.println("3.Đơn vị kinh doanh, dịch vụ");
                    System.out.println("Chọn hình thức(1/2/3): ");
                    int hinhThuc1 = Integer.parseInt(input.readLine());
                    double tienNuoc1 = tinhTienNuocKhongSinhHoat(soNuoc, hinhThuc);
                    double tienThue1 = tinhTienThueKhongSinhHoat(soNuoc, hinhThuc);
                    double tienBaoVe1 = tinhTienBaoVeKhongSinhHoat(soNuoc, hinhThuc);
                    double tongTien1 = tienNuoc1 + tienBaoVe1 + tienThue1;
                    System.out.println("Tiền nước là: "+tienNuoc1);
                    System.out.println("Tiền thuế là: "+tienThue1);
                    System.out.println("Tiền bảo vệ là: "+tienBaoVe1);
                    System.out.println("Tính tiền là: " + tongTien1);
                    break;
                default:
                    throw new ArithmeticException("Hình thức chọn không đúng");
            }

        } catch (NumberFormatException | InputMismatchException e) {
            System.out.println(e.getMessage());
        } catch (ArithmeticException e){
            System.out.println(e.getMessage());
        }
    }

}
