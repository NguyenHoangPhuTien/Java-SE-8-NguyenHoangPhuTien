/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexercise2_ngu;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.InputMismatchException;

/**
 *
 * @author hocvien
 */
public class Bai3_Mang2Chieu {

    /**
     * @param args the command line arguments
     */
    public static int[][] nhapMang(int[][] mang, BufferedReader input) throws IOException {
        int i, j;
        for (i = 0; i < mang.length; i++) {
            for (j = 0; j < mang[i].length; j++) {
                System.out.println(String.format("Nhập phần tử dòng %d cột %d: ",
                        i, j));
                mang[i][j] = Integer.parseInt(input.readLine());
            }
        }
        return mang;
    }

    public static void xuatMang(int[][] mang) {
        int i, j;
        String chuoi = "";
        for (i = 0; i < mang.length; i++) {
            for (j = 0; j < mang[i].length; j++) {
                chuoi += mang[i][j] + " ";

            }
            System.out.println(chuoi);
            chuoi = "";
        }
    }
    
    public static void sapXepCotTangDan(int[][] mang, int cot) {
        int n = mang[0].length;
        if (cot < 0 || cot > n) {
            throw new ArrayIndexOutOfBoundsException("Chỉ số cột không đúng");
        }

        for (int i = 0; i < mang.length - 1; i++) {
            for (int j = cot; j < mang[i].length - 1; j++) {
                if (mang[i][cot] > mang[i + 1][cot]) {
                    int tam = mang[i + 1][cot];
                    mang[i + 1][cot] = mang[i][cot];
                    mang[i][cot] = tam;
                }
            }
        }
    }

    public static int tinhTongPhanTu(int[][] mang) {
        if (mang == null) {
            throw new NullPointerException("Mảng đang có giá trị null");
        }
        int tong = 0;
        for (int i = 0; i < mang.length; i++) {
            if (i % 2 == 0) {
                for (int j = 0; j < mang[i].length; j++) {
                    if (j % 2 == 1) {
                        tong = tong + mang[i][j];
                    }
                }
            }
        }
        return tong;
    }
    public static boolean kiemTraSNT(int n){
        if(n < 0) 
            throw new ArithmeticException("Số nhập phải là số nguyên dương");
        int i;
        if (n == 1 || n == 0) {
            return false;
        }
        for (i = 2; i <= (int) Math.sqrt(n); i++) {
            if (n % i == 0) {
                return false;
            } else {
                return true;
            }
        }
        return true;
    }
    public static void thayThePhanTu(int[][] mang){
        for(int i = 0; i < mang.length; i++){
            for(int j = 0; j < mang[i].length; j++){
                if(kiemTraSNT(mang[i][j]) == true){
                    mang[i][j] = -1;
                }
                
            } 
        }
    }
    public static int tongDongDauTien(int[][] mang){
        if(mang ==  null)
            throw new NullPointerException("Mảng dang null");
        int tong = 0;
        for(int i = 0; i < mang[0].length; i++)
            tong += mang[0][i];
        return tong;
    }
     public static int tongDongCuoi(int[][] mang){
        if(mang ==  null)
            throw new NullPointerException("Mảng dang null");
        int tong = 0;
        int dongCuoi = mang.length - 1;
        for(int i = 0; i < mang[0].length; i++)
            tong += mang[dongCuoi][i];
        return tong;
    }
     public static int tongCotDauTien(int[][] mang){
        if(mang ==  null)
            throw new NullPointerException("Mảng dang null");
        int tong = 0;
        
        for(int i = 0; i < mang.length; i++)
            tong += mang[i][0];
        return tong;
    }
    public static int tongCotCuoi(int[][] mang){
        if(mang ==  null)
            throw new NullPointerException("Mảng dang null");
        int tong = 0;
        int cotCuoi = mang[0].length - 1;
        for(int i = 0; i < mang.length; i++)
            tong += mang[i][cotCuoi];
        return tong;
    }
    public static boolean kiemTraSoChinhPhuong(int so) {
       
        if(so < 0)
            throw new ArithmeticException("Số không đúng");
        boolean kq = false;
        int j = (int) Math.pow(so, 0.5) + 1;
        for (int i = 1; i < j ; i++) {
            if (so == i * i) {
                kq = true;
            }
        }
        return kq;
    }
    public static void xuatViTriSoChinhPhuong(int[][] mang){
        
        if(mang ==  null)
            throw new NullPointerException("Mảng dang null");
        for(int i = 0; i < mang.length; i++){
            for(int j = 0; j < mang[i].length; j++){
                if(kiemTraSoChinhPhuong(mang[i][j]))
                    System.out.println("dòng "+i+" cột "+j);
            }
        }
    }
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        try {
            System.out.println("Nhập dòng: ");
            int dong = Integer.parseInt(input.readLine());

            System.out.println("Nhập cột: ");
            int cot = Integer.parseInt(input.readLine());

            System.out.println("Nhập cột mún sắp xếp: ");
            int cotSapXep = Integer.parseInt(input.readLine());

            int[][] mang = new int[dong][cot];

            mang = nhapMang(mang, input);
            xuatMang(mang);
            sapXepCotTangDan(mang, cotSapXep);
            int tong = tinhTongPhanTu(mang);
            System.out.println("Tổng các số dòng chẳn cột lẻ: " + tong);
            thayThePhanTu(mang);
            System.out.println("Mảng sau khi thay thế: ");
            xuatMang(mang);
            System.out.println("Mảng nếu có số chính phương ở vị trí: ");
            xuatViTriSoChinhPhuong(mang);
            
            System.out.println("Tổng dòng đầu tiên: " + tongDongDauTien(mang));
            System.out.println("Tổng cột đầu tiên: " + tongCotDauTien(mang));
            System.out.println("Tổng dòng cuối: " + tongDongCuoi(mang));
            System.out.println("Tổng cột cuối: " + tongCotCuoi(mang));
        } catch (InputMismatchException | NumberFormatException e) {
            System.out.println(e.getMessage());
        } catch (ArrayIndexOutOfBoundsException | ArithmeticException e){
            System.out.println(e.getMessage());
        } catch (NullPointerException e){
            System.out.println(e.getMessage());
        }
    }

}
