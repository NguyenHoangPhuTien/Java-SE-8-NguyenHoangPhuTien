/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexercise2_ngu;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.InputMismatchException;

/**
 *
 * @author hocvien
 */
public class Bai4_SinhVien {

    /**
     * @param args the command line arguments
     */
    public static double tinhDiemTB(int[] mang){
        
        if(mang == null)
            throw new ArithmeticException("Mảng đang null");
        
        double tong = 0;
        for(int i = 0; i < mang.length; i++){
            tong += mang[i];
        }
        return tong/mang.length;
    }
    public static int timSoLonNhat(int[] mang){
        
        if(mang == null)
           throw new ArithmeticException("Mảng đang null");
         
        int max = mang[0];
        for(int i = 0; i < mang.length - 1; i++){
            max = Math.max(max, mang[i+1]);
        }
        return max;
    }
     public static int timSoNhoNhat(int[] mang){
        
        if(mang == null)
           throw new ArithmeticException("Mảng đang null");
         
        int min = mang[0];
        for(int i = 0; i < mang.length - 1; i++){
            min = Math.min(min, mang[i+1]);
        }
        return min;
    }
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        try {
            System.out.println("Hãy nhập số sinh viên: ");
            int soSinhVien = Integer.parseInt(input.readLine());
            if(soSinhVien == 0){
                System.out.println("Hãy nhập lại số sinh viên: ");
                soSinhVien = Integer.parseInt(input.readLine());
            }
            int[] mang = new int[soSinhVien];
            for(int i = 0; i < soSinhVien; i++){
                
                System.out.println("Nhập điểm sv thứ "+i);
                int diem = Integer.parseInt(input.readLine());
                while(diem < 0 || diem > 10){
                    System.out.println("Nhập lại điểm sv thứ "+i);
                    diem = Integer.parseInt(input.readLine());
                }
                mang[i] = diem;
                
            }
            System.out.println("Điểm trung bình: "+tinhDiemTB(mang));
            System.out.println("Điểm lớn nhất: "+timSoLonNhat(mang));
            System.out.println("Điểm nhỏ nhất: "+timSoNhoNhat(mang));
            
        } catch (InputMismatchException | NumberFormatException e) {
            System.out.println(e.getMessage());
        } catch (NullPointerException e){
            System.out.println(e.getMessage());
        }
    }
    
}
