/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexercise2_ngu;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.InputMismatchException;

/**
 *
 * @author hocvien
 */
public class Bai5_BanCo {

    /**
     * @param args the command line arguments
     */
    public static void xuatMang(String[][] mang) {
        int i, j;
        String chuoi = "";
        System.out.println("-------------------------------");
        for (i = 0; i < mang.length; i++) {
            for (j = 0; j < mang[i].length; j++) {
                chuoi += mang[i][j] + " | ";

            }
            System.out.println(chuoi);
            chuoi = "";
            System.out.println("-------------------------------");
        }
    }
    public static void taoBanCo(String[][] mang){
        if(mang ==  null)
            throw new NullPointerException("Mảng dang null");
        
        for(int i = 0; i < mang.length; i++){
            for(int j = 0; j < mang[i].length; j++){
                if(i % 2 == 0){
                    if(j % 2 == 0)
                        mang[i][j] = "W";
                    else
                        mang[i][j] = "B";
                }
                else{
                    if(j % 2 == 0)
                        mang[i][j] = "B";
                    else
                        mang[i][j] = "W";
                }
            }
        }
    }
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        try {
            System.out.println("Nhập chiều dài bàn cờ");
            int chieuDai = Integer.parseInt(input.readLine());
            
            String[][] mang = new String[chieuDai][chieuDai];
            taoBanCo(mang);
            xuatMang(mang);
        } catch (InputMismatchException | NumberFormatException | NullPointerException e) {
            System.out.println(e.getMessage());
        }
    }
    
}
