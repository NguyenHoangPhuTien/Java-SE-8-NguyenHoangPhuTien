/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexercise2_ngu;

import static bigexercise2_ngu.Bai5_BanCo.taoBanCo;
import static bigexercise2_ngu.Bai5_BanCo.xuatMang;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.InputMismatchException;

/**
 *
 * @author hocvien
 */
public class Bai6_VeHinh {

    /**
     * @param args the command line arguments
     */
    public static void veHinhD(String[][] mang) {

        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if (i >= j) {
                    System.out.print(j + 1);
                } else {
                    System.out.print(" ");
                }
            }
            System.out.println("");
        }
    }

    public static void veHinhE(String[][] mang) {

        int k = 1;
        for (int i = 0; i < mang.length; i++) {

            for (int j = 0; j < mang[i].length; j++) {
                if (j >= i) {
                    
                    System.out.print(k);
                    k++;
                } else {
                    System.out.print(" ");
                }
               
            }
            k = 1;
            System.out.println("");
        }
    }
    public static String[][] veHinhA(){
        String[][] mang = new String[11][11];
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                mang[i][j] = " ";
            }
        }
        for (int i = 0; i < mang.length; i++) {
            for (int j = i; j < mang[i].length; j++) {
                if (j < mang[i].length - i) {
                    mang[i][j] = "*";
                }
            }
        }

        return mang;
    }
    
    public static void veHinhG(String[][] mang) {
        
        for (int i = 0; i < mang.length; i++) {
            for (int j = mang[i].length; j > 0; j--) {
                if(i + j <= mang.length){
                    System.out.print(j);
                }
            }
            System.out.println("");
        }
    }
    public static void veHinhF(String[][] mang) {

        int k = mang.length ;
        for (int i = 0; i < mang.length; i++) {

            for (int j = 0; j < mang[i].length; j++) {
                if (j >= (mang[i].length - 1) - i ) {
                    System.out.print(k);
                    
                } else {
                    System.out.print(" ");
                    
                }
                k--;
            }
            k = mang.length;
            System.out.println("");
        }
    }
    public static void xuatMang(String[][] mang) {
        int i, j;
        String chuoi = "";
        for (i = 0; i < mang.length; i++) {
            for (j = 0; j < mang[i].length; j++) {
                chuoi += mang[i][j] + " ";

            }
            System.out.println(chuoi);
            chuoi = "";
        }
    }
     public static String[][] veHinhB(){
        String[][] mang = new String[11][11];
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                mang[i][j] = " ";
            }
        }
        
        for(int i=0;i<mang.length/2+1;i++){
            for(int j=mang.length/2-i;j<mang.length/2+i+1;j++){
                mang[i][j] = "*";
            }
        }
        return mang;
    }
     public static String[][] veHinhC(){
        int k = 1;
        
        String[][] B = veHinhB();
        String[][] C = B.clone();
        String[][] A = veHinhA();
        for(int i=B.length/2+1;i<B.length;i++){
            int l = 0;
            for(int j=0;j<B[i].length;j++){
                C[i][j] = A[k][l];
                l++;
            }
            k++;
        }
        return C;
    }
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        try {
            System.out.println("Nhập chiều dài hình");
            int chieuDai = Integer.parseInt(input.readLine());

            String[][] mang = new String[chieuDai][chieuDai];
            xuatMang(veHinhA());
            System.out.println("------------------");
            xuatMang(veHinhB());
            System.out.println("------------------");
            xuatMang(veHinhC());
            veHinhD(mang);
            System.out.println("------------------");
            veHinhE(mang);
            System.out.println("------------------");
            veHinhF(mang);
            System.out.println("------------------");
            veHinhG(mang);

        } catch (InputMismatchException | NumberFormatException | NullPointerException e) {
            System.out.println(e.getMessage());
        }
    }

}
