/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexercise2_ngu;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai7_ChoiGame {

    /**
     * @param args the command line arguments
     */
    public static int soDiemTrung(String tuDoan, String chu){
        
        int diem = 0;
        for(int i = 0; i < chu.length(); i++){
            if(chu.charAt(i) == tuDoan.charAt(0))
                diem++;
        }
        return diem;
    }
    public static String doiChu(String chu, String viTri) {

        int[] viTri1 = new int[viTri.split(" ").length];
        String[] viTri2 = viTri.split(" ");
        for(int k = 0; k < viTri1.length; k++){
            viTri1[k] = Integer.parseInt(viTri2[k]);
        }
        for (int j = 0; j < viTri1.length; j++) {
            for (int i = 0; i < chu.length(); i++) {
                if(i == viTri1[j])
                    chu = chu.replace(chu.charAt(i), '*');
            }
        }

        return chu;
    }
    public static String timViTriXuatHien(String tuDoan,String chuoi,String chu){
        
        for(int i = 0; i < chu.length(); i++){
            if(chu.charAt(i) == tuDoan.charAt(0))
                chuoi += i+" ";
        }
        return chuoi;
    }
    public static void main(String[] args) {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        
        try {
            String[] mang = {"program","developer","testing","coder","algorithm",
            "bug","console","user","system","aplication"};
            
            System.out.println("Hãy nhâp số từ 1 tới 10");
            int so = Integer.parseInt(input.readLine());
            
            System.out.println("Bạn chọn số " + so);
            String chuDoan = mang[so -1];
            int dem = mang[so - 1].length();
            System.out.println("Chữ có " + dem + " kí tự");
            
            int[] chuoiKiTu = new int[dem];
            String viTri = "";
            String kiTu = "";
            int luotChoi = 0;
            int diem = 0;
            while(diem == dem){
                System.out.println("Mời bạn đoán: ");
                kiTu += input.readLine();
                viTri = timViTriXuatHien(chuDoan, viTri, kiTu);
                chuDoan = doiChu(chuDoan, kiTu);
                diem += soDiemTrung(kiTu, chuDoan);
            }
            
        } catch (Exception e) {
        }
    }
    
}
