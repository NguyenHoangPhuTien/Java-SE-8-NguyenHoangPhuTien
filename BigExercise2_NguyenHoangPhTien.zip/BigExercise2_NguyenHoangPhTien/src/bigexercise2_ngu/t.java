/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexercise2_ngu;

import static bigexercise2_ngu.Bai3_Mang2Chieu.kiemTraSNT;
import static bigexercise2_ngu.Bai3_Mang2Chieu.kiemTraSoChinhPhuong;

/**
 *
 * @author hocvien
 */
public class t {

    /**
     * @param args the command line arguments
     */
    public static void sapXepCotTangDan(int[][] mang, int cot) {
        int n = mang[0].length;
        if (cot < 0 || cot > n) {
            throw new ArrayIndexOutOfBoundsException("Chỉ số cột không đúng");
        }

        for (int i = 0; i < mang.length - 1; i++) {
            for (int j = cot; j < mang[i].length - 1; j++) {
                if (mang[i][cot] > mang[i + 1][cot]) {
                    int tam = mang[i + 1][cot];
                    mang[i + 1][cot] = mang[i][cot];
                    mang[i][cot] = tam;
                }
            }
        }
    }

    public static boolean kiemTraSNT(int n) {
        if (n < 0) {
            throw new ArithmeticException("Số nhập phải là số nguyên dương");
        }
        int i;
        if (n == 1 || n == 0) {
            return false;
        }
        for (i = 2; i <= (int) Math.sqrt(n); i++) {
            if (n % i == 0) {
                return false;
            } else {
                return true;
            }
        }
        return true;
    }

    public static void xuatMang(int[][] mang) {
        int i, j;
        String chuoi = "";
        for (i = 0; i < mang.length; i++) {
            for (j = 0; j < mang[i].length; j++) {
                chuoi += mang[i][j] + " ";

            }
            System.out.println(chuoi);
            chuoi = "";
        }
    }

    public static int tinhTongPhanTu(int[][] mang) {
        int tong = 0;
        for (int i = 0; i < mang.length; i++) {
            if (i % 2 == 0) {
                for (int j = 0; j < mang[i].length; j++) {
                    if (j % 2 == 1) {
                        tong = tong + mang[i][j];
                    }
                }
            }
        }
        return tong;
    }

    public static void thayThePhanTu(int[][] mang) {
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if (kiemTraSNT(mang[i][j]) == true) {
                    mang[i][j] = -1;
                }

            }
        }
    }

    public static int tongDongDauTien(int[][] mang) {
        if (mang == null) {
            throw new NullPointerException("Mảng dang null");
        }
        int tong = 0;
        for (int i = 0; i < mang[0].length; i++) {
            tong += mang[0][i];
        }
        return tong;
    }

    public static int tongDongCuoi(int[][] mang) {
        if (mang == null) {
            throw new NullPointerException("Mảng dang null");
        }
        int tong = 0;
        int dongCuoi = mang.length - 1;
        for (int i = 0; i < mang[0].length; i++) {
            tong += mang[dongCuoi][i];
        }
        return tong;
    }

    public static int tongCotDauTien(int[][] mang) {
        if (mang == null) {
            throw new NullPointerException("Mảng dang null");
        }
        int tong = 0;

        for (int i = 0; i < mang.length; i++) {
            tong += mang[i][0];
        }
        return tong;
    }

    public static int tongCotCuoi(int[][] mang) {
        if (mang == null) {
            throw new NullPointerException("Mảng dang null");
        }
        int tong = 0;
        int cotCuoi = mang[0].length - 1;
        for (int i = 0; i < mang.length; i++) {
            tong += mang[i][cotCuoi];
        }
        return tong;
    }

    public static boolean kiemTraSoChinhPhuong(int so) {

        boolean kq = false;
        int j = (int) Math.pow(so, 0.5) + 1;
        for (int i = 1; i < j; i++) {
            if (so == i * i) {
                kq = true;
            }
        }
        return kq;
    }

    public static void xuatViTriSoChinhPhuong(int[][] mang) {

        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if (kiemTraSoChinhPhuong(mang[i][j])) {
                    System.out.println("dòng " + i + " cột " + j);
                }
            }
        }
    }

    public static double tinhDiemTB(int[] mang) {

        if (mang == null) {
            throw new ArithmeticException("Mảng đang null");
        }

        double tong = 0;
        for (int i = 0; i < mang.length; i++) {
            tong += mang[i];
        }
        return tong / mang.length;
    }

    public static int timSoLonNhat(int[] mang) {

        if (mang == null) {
            throw new ArithmeticException("Mảng đang null");
        }

        int max = mang[0];
        for (int i = 0; i < mang.length - 1; i++) {
            max = Math.max(max, mang[i + 1]);
        }
        return max;
    }

    public static int timSoNhoNhat(int[] mang) {

        if (mang == null) {
            throw new ArithmeticException("Mảng đang null");
        }

        int min = mang[0];
        for (int i = 0; i < mang.length - 1; i++) {
            min = Math.min(min, mang[i + 1]);
        }
        return min;
    }

    public static String[][] mtA() {
        String[][] mt = new String[11][11];
        for (int i = 0; i < mt.length; i++) {
            for (int j = 0; j < mt[i].length; j++) {
                mt[i][j] = " ";
            }
        }
        for (int i = 0; i < mt.length; i++) {
            for (int j = i; j < mt[i].length; j++) {
                if (j < mt[i].length - i) {
                    mt[i][j] = "#";
                }
            }
        }

        return mt;
    }

    public static void xuatMang1(String[][] mang) {
        int i, j;
        String chuoi = "";
        for (i = 0; i < mang.length; i++) {
            for (j = 0; j < mang[i].length; j++) {
                chuoi += mang[i][j] + " ";

            }
            System.out.println(chuoi);
            chuoi = "";
        }
    }

    public static int soDiemTrung(String tuDoan, String chu) {

        int diem = 0;
        for (int i = 0; i < chu.length(); i++) {
            if (chu.charAt(i) == tuDoan.charAt(0)) {
                diem++;
            }
        }
        return diem;
    }

    public static String doiChu(String chu, String viTri) {

        int[] viTri1 = new int[viTri.split(" ").length];
        String[] viTri2 = viTri.split(" ");
        for(int k = 0; k < viTri1.length; k++){
            viTri1[k] = Integer.parseInt(viTri2[k]);
        }
        for (int j = 0; j < viTri1.length; j++) {
            for (int i = 0; i < chu.length(); i++) {
                if(i == viTri1[j])
                    chu = chu.replace(chu.charAt(i), '*');
            }
        }

        return chu;
    }

    public static String timViTriXuatHien(String tuDoan,String chuoi,String chu){
        
        for(int i = 0; i < chu.length(); i++){
            if(chu.charAt(i) == tuDoan.charAt(0))
                chuoi += i+" ";
        }
        return chuoi;
    }
    public static void main(String[] args) {
        // TODO code application logic here
        String chuoi ="";
       String tam = timViTriXuatHien("e", chuoi , "developer");
       String tam1 = doiChu("developer", tam);
        System.out.println(tam1);

    }

}
